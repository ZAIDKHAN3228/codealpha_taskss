# Indus - Full Stack Premium E-Commerce Store

Indus is a production-ready, highly responsive, and beautiful Full-Stack E-Commerce store built with **Vanilla HTML5/CSS3/JavaScript** on the frontend and **Node.js (Express) & MongoDB (Mongoose)** on the backend. 

The store features high-fidelity modern UI styling, complete with glassmorphism elements, transitions, and subtle hover animations, with all pricing rendered in **Indian Rupees (INR, ₹)**.

---

## Technical Stack

- **Frontend**: HTML5, Vanilla CSS3 (Custom Variables, Light/Dark Modes, Keyframe Animations), Vanilla JS (Dynamic Component Loaders, Client-side routing helper)
- **Backend**: Node.js, Express.js
- **Database**: MongoDB (Mongoose Schema Models)
- **Authentication**: JSON Web Tokens (JWT) + BCrypt password hashing
- **File Uploads**: Multer (Local Uploads)

---

## Features

1. **Home Page**: Dynamic hero slides, list of curated product category links, list of latest featured items, and custom theme switches.
2. **Product Listing**: Advanced sidebar filter widgets (Category checkboxes, minimum/maximum price input sliders) and search inputs with instant sort selector filters.
3. **Product Details**: Multi-image slider layout, stock counts, dynamic spec mapping, quantity toggles, related product items suggestions, and custom reviews forms.
4. **Shopping Cart**: Guest-to-user cart synchronization, tax calculations, shipping margins, and coupon codes discount apply triggers.
5. **Secure Checkout**: Delivery details verification form, mock payment card selections, billing previews, and order submissions.
6. **Order Processing**: Auto-deduction of product inventory counts, calculation of bills invoice, and timeline progress tracking.
7. **User Profiles Dashboard**: Toggle profile info edits, select dashboard tabs, and review details of previous order history.
8. **Admin Panel Dashboard**: Graph metrics cards, new product addition with spec array builders & upload capabilities, CRUD product list directory table, order status dropdown progress trackers, and user roles viewer.

---

## API Documentation

### Authentication
- `POST /api/auth/register` - Create user profile and get JWT.
- `POST /api/auth/login` - Verify credentials and return token.
- `GET /api/auth/me` - Retrive currently logged-in user profile details.
- `PUT /api/auth/profile` - Edit user profile name, email, and password.
- `GET /api/auth/users` - Admin list all registered user profiles.

### Products
- `GET /api/products` - List products matching category, search, price, and sorting.
- `GET /api/products/:id` - Fetch single product specifications and customer reviews.
- `POST /api/products` - Admin create product with local file uploads.
- `PUT /api/products/:id` - Admin update product fields.
- `DELETE /api/products/:id` - Admin remove product from database.
- `POST /api/products/:id/reviews` - Post customer review score and comments.

### Shopping Cart
- `GET /api/cart` - Fetch user's cart populated with product objects.
- `POST /api/cart` - Add product or increment quantity.
- `PUT /api/cart/:id` - Update quantity count of product item.
- `DELETE /api/cart/:id` - Delete product from cart list.
- `POST /api/cart/sync` - Merge guest local storage items to user's database cart on login.

### Orders
- `POST /api/orders` - Create order, deduct stock, verify pricing, clear user cart.
- `GET /api/orders` - Admin list all customer orders.
- `GET /api/orders/myorders` - Fetch logged-in user purchase invoices.
- `GET /api/orders/stats` - Admin overview statistics of sales and categories counts.
- `GET /api/orders/:id` - Fetch details of single order invoice.
- `PUT /api/orders/:id/status` - Admin modify order delivery status tracking.

---

## Getting Started

### 1. Prerequisites
- **Node.js** (v16+) installed.
- **MongoDB** running locally on default connection URL: `mongodb://localhost:27017/`.

### 2. Installation
Navigate into the backend directory and install required dependencies:
```bash
cd backend
npm install
```

### 3. Seed Database
Run the seeder utility script to empty collection datasets and seed premium mock product files, an admin account, and a regular user account:
```bash
node seeder.js
```
*Default Credentials Seeded:*
- **Admin account**: `admin@ecommerce.com` / Password: `password123`
- **Regular user**: `john@example.com` / Password: `password123`

### 4. Running the Application
To run the server in development mode (starts Nodemon):
```bash
npm run dev
```

The Express server will start up on **`http://localhost:5000`** and serve the static Vanilla frontend pages directly from the `frontend/` directory.

Open your browser and navigate to **[http://localhost:5000](http://localhost:5000)** to view the application.
