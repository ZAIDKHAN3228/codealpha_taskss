const express = require('express');
const router = express.Router();
const {
  getCart,
  addToCart,
  updateCartItem,
  deleteCartItem,
  syncCart
} = require('../controllers/cartController');
const { protect } = require('../middleware/auth');

router.use(protect); // protect all cart routes

router.route('/')
  .get(getCart)
  .post(addToCart);

router.route('/sync')
  .post(syncCart);

router.route('/:id')
  .put(updateCartItem)
  .delete(deleteCartItem);

module.exports = router;
