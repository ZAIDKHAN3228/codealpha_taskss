const mongoose = require('mongoose');
const dotenv = require('dotenv');
const User = require('./models/User');
const Product = require('./models/Product');
const Order = require('./models/Order');
const Cart = require('./models/Cart');

dotenv.config();

const mockProducts = [
  {
    name: "Aethera Wireless ANC Headphones",
    description: "Premium active noise-cancelling wireless headphones with 40-hour battery life, high-resolution audio support, and ergonomic memory foam earcups for ultimate comfort during long listening sessions.",
    price: 24999,
    discount: 15,
    images: [
      "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800",
      "https://images.unsplash.com/photo-1546435770-a3e426bf472b?w=800",
      "https://images.unsplash.com/photo-1484704849700-f032a568e944?w=800"
    ],
    category: "Audio",
    stock: 25,
    rating: 4.8,
    numReviews: 2,
    reviews: [
      {
        name: "Alice Johnson",
        rating: 5,
        comment: "Absolutely outstanding sound quality. The noise cancelling blocks out my noisy office entirely!",
        user: new mongoose.Types.ObjectId() // Temp placeholder user ID, seeder will update this
      },
      {
        name: "Bob Smith",
        rating: 4,
        comment: "Great sound and battery life, but a bit snug on my ears after 4 hours.",
        user: new mongoose.Types.ObjectId()
      }
    ],
    specifications: {
      "Battery Life": "Up to 40 Hours (ANC On)",
      "Bluetooth Version": "Bluetooth 5.2",
      "Driver Size": "40mm Dynamic",
      "Weight": "250g",
      "Charging Port": "USB Type-C Fast Charging"
    }
  },
  {
    name: "Chronos Smartwatch Titan",
    description: "Architected from premium grade titanium, the Chronos Smartwatch offers a beautiful 1.4-inch AMOLED display, advanced GPS tracking, dynamic heart rate monitoring, SpO2 readings, and up to 10 days of battery life.",
    price: 29999,
    discount: 10,
    images: [
      "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=800",
      "https://images.unsplash.com/photo-1542496658-e33a6d0d50f6?w=800"
    ],
    category: "Wearables",
    stock: 15,
    rating: 4.7,
    numReviews: 1,
    reviews: [
      {
        name: "Carol Danvers",
        rating: 5,
        comment: "Excellent design, fits very well and the battery easily lasts a week. Heart rate sensor is highly accurate.",
        user: new mongoose.Types.ObjectId()
      }
    ],
    specifications: {
      "Material": "Grade 5 Titanium Body & Sapphire Glass",
      "Display": "1.4-inch AMOLED Always-On (454 x 454 px)",
      "Water Resistance": "5 ATM (Up to 50m)",
      "Battery Life": "Up to 10 Days typical use",
      "Sensors": "PPG Heart Rate, SpO2, Accelerometer, Gyroscope, Barometer, GPS"
    }
  },
  {
    name: "Vortex Mechanical Keyboard",
    description: "A compact 75% layout hot-swappable mechanical keyboard designed for enthusiasts. Featuring pre-lubed linear yellow switches, double-shot PBT keycaps, customized sound dampening foams, and full per-key RGB backlighting.",
    price: 9999,
    discount: 0,
    images: [
      "https://images.unsplash.com/photo-1587829741301-dc798b83add3?w=800",
      "https://images.unsplash.com/photo-1618384887929-16ec33fab9ef?w=800"
    ],
    category: "Peripherals",
    stock: 50,
    rating: 4.5,
    numReviews: 2,
    reviews: [
      {
        name: "Dave Grohl",
        rating: 5,
        comment: "Best pre-built keyboard I have ever bought. The switches are buttery smooth and sound deep and thocky.",
        user: new mongoose.Types.ObjectId()
      },
      {
        name: "Eve Green",
        rating: 4,
        comment: "Keys feel fantastic. Wish there was a wireless version at this price.",
        user: new mongoose.Types.ObjectId()
      }
    ],
    specifications: {
      "Layout": "75% Form Factor (82 keys)",
      "Switches": "Hot-swappable Linear Yellow Switches",
      "Keycaps": "Double-Shot PBT Cherry Profile",
      "Connectivity": "Wired USB-C (Detachable braided cable)",
      "Backlighting": "South-facing per-key RGB"
    }
  },
  {
    name: "Opal Minimalist Desk Lamp",
    description: "Sleek and minimalist LED desk lamp styled from sandblasted anodized aluminum. Offers stepless dimming, 3-level color temperature adjustment, a built-in auto-timer, and a integrated 10W Qi wireless charging pad at the base.",
    price: 5999,
    discount: 20,
    images: [
      "https://images.unsplash.com/photo-1507473885765-e6ed057f782c?w=800",
      "https://images.unsplash.com/photo-1513506003901-1e6a229e2d15?w=800"
    ],
    category: "Smart Home",
    stock: 30,
    rating: 4.6,
    numReviews: 1,
    reviews: [
      {
        name: "Frank Castle",
        rating: 5,
        comment: "Extremely clean look for my workspace. The phone charger on the base is very handy.",
        user: new mongoose.Types.ObjectId()
      }
    ],
    specifications: {
      "Power Rating": "12W Max",
      "Wireless Charger Base": "10W Qi Compatible",
      "Color Temperature": "2700K - 6500K (Warm to Cool White)",
      "Material": "Anodized Aluminum & High-grade Polycarbonate",
      "Brightness": "Up to 600 Lumens"
    }
  },
  {
    name: "Lumina Ultra-Short Throw Projector",
    description: "Transform any wall into a high-end 120-inch 4K home cinema. Lumina uses advanced ALPD laser technology to deliver outstandingly sharp, bright, and vibrant images even in well-lit rooms, with integrated Dolby Atmos audio.",
    price: 124999,
    discount: 5,
    images: [
      "https://images.unsplash.com/photo-1535016120720-40c646be5580?w=800",
      "https://images.unsplash.com/photo-1601944179066-29786cb9d32a?w=800"
    ],
    category: "Smart Home",
    stock: 8,
    rating: 4.9,
    numReviews: 1,
    reviews: [
      {
        name: "Grace Hopper",
        rating: 5,
        comment: "Astonishing picture quality. The throw distance is ridiculously close. Truly replaces a TV.",
        user: new mongoose.Types.ObjectId()
      }
    ],
    specifications: {
      "Resolution": "4K Ultra HD (3840 x 2160)",
      "Light Source": "ALPD Laser Light Source (25,000 hrs lifespan)",
      "Brightness": "2500 ANSI Lumens",
      "Throw Ratio": "0.233:1 (100\" display at just 9\" distance)",
      "Audio": "Built-in 30W Speakers with Dolby Audio & DTS-HD"
    }
  }
];

const seedData = async () => {
  try {
    await mongoose.connect(process.env.MONGODB_URI);
    console.log("Connected to MongoDB for seeding...");

    // Clear existing data
    await Product.deleteMany({});
    await Order.deleteMany({});
    await Cart.deleteMany({});
    await User.deleteMany({});
    console.log("Cleared existing collections.");

    // Create a default admin user
    const adminUser = await User.create({
      name: "Admin User",
      email: "admin@ecommerce.com",
      password: "password123",
      role: "admin"
    });
    console.log("Created admin user (admin@ecommerce.com / password123)");

    // Create a default regular user
    const regularUser = await User.create({
      name: "John Doe",
      email: "john@example.com",
      password: "password123",
      role: "user"
    });
    console.log("Created regular user (john@example.com / password123)");

    // Bind reviews to the created user IDs
    const seededProducts = mockProducts.map(product => {
      product.reviews = product.reviews.map((review, i) => {
        review.user = i === 0 ? regularUser._id : adminUser._id;
        return review;
      });
      return product;
    });

    await Product.insertMany(seededProducts);
    console.log("Successfully seeded mock products!");

    process.exit(0);
  } catch (error) {
    console.error(`Seeding error: ${error.message}`);
    process.exit(1);
  }
};

seedData();
