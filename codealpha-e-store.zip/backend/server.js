const express = require('express');
const dotenv = require('dotenv');
const cors = require('cors');
const path = require('path');
const connectDB = require('./config/db');

// Load environment variables
dotenv.config();

// Connect to Database
connectDB();

const app = express();

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static upload folder
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Routes
app.use('/api/auth', require('./routes/authRoutes'));
app.use('/api/products', require('./routes/productRoutes'));
app.use('/api/cart', require('./routes/cartRoutes'));
app.use('/api/orders', require('./routes/orderRoutes'));

// Serve frontend in production (optional, if we want backend to serve it)
// For simplicity, we can let backend serve the frontend directly if we serve index.html
// But standard separation is fine too. Let's serve frontend folder as static too, which makes local testing seamless!
app.use(express.static(path.join(__dirname, '../frontend')));

// Fallback for SPA-like routes if they go to HTML files
// e.g. /cart -> /cart.html
app.get('*', (req, res, next) => {
  // If request is for an API route, pass to error handler
  if (req.url.startsWith('/api')) {
    return next();
  }
  // Try to serve matching html file
  const parsedPath = path.parse(req.url);
  if (!parsedPath.ext) {
    const file = path.join(__dirname, '../frontend', `${req.url}.html`);
    res.sendFile(file, (err) => {
      if (err) {
        res.sendFile(path.join(__dirname, '../frontend/index.html'));
      }
    });
  } else {
    next();
  }
});

// Error handling middleware
app.use((err, req, res, next) => {
  const statusCode = res.statusCode === 200 ? 500 : res.statusCode;
  console.error(err.stack);
  res.status(statusCode).json({
    success: false,
    message: err.message,
    stack: process.env.NODE_ENV === 'production' ? null : err.stack
  });
});

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
  console.log(`Server running in ${process.env.NODE_ENV || 'development'} mode on port ${PORT}`);
});

module.exports = app;
