const User = require('../models/User');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const { getIsConnected } = require('../config/db');
const mockStore = require('../config/mockStore');

// Generate JWT Token
const generateToken = (id) => {
  return jwt.sign({ id }, process.env.JWT_SECRET, {
    expiresIn: '30d'
  });
};

// @desc    Register a new user
// @route   POST /api/auth/register
// @access  Public
exports.registerUser = async (req, res) => {
  try {
    const { name, email, phone, password } = req.body;

    if (!name || !email || !password) {
      return res.status(400).json({ success: false, message: 'Please provide name, email and password' });
    }

    if (!getIsConnected()) {
      // Offline fallback registration
      const emailExists = mockStore.users.find(u => u.email === email);
      if (emailExists) {
        return res.status(400).json({ success: false, message: 'User already exists with this email' });
      }

      if (phone) {
        const phoneExists = mockStore.users.find(u => u.phone === phone);
        if (phoneExists) {
          return res.status(400).json({ success: false, message: 'User already exists with this phone number' });
        }
      }

      const role = mockStore.users.length === 0 ? 'admin' : 'user';
      const newUser = {
        _id: `u_${Date.now()}`,
        name,
        email,
        phone: phone || null,
        password: bcrypt.hashSync(password, 10),
        isGoogleUser: false,
        role,
        createdAt: new Date()
      };

      mockStore.users.push(newUser);

      return res.status(201).json({
        success: true,
        _id: newUser._id,
        name: newUser.name,
        email: newUser.email,
        phone: newUser.phone,
        role: newUser.role,
        token: generateToken(newUser._id)
      });
    }

    // Standard MongoDB registration
    // Check if user exists by email
    const emailExists = await User.findOne({ email });
    if (emailExists) {
      return res.status(400).json({ success: false, message: 'User already exists with this email' });
    }

    // Check if user exists by phone
    if (phone) {
      const phoneExists = await User.findOne({ phone });
      if (phoneExists) {
        return res.status(400).json({ success: false, message: 'User already exists with this phone number' });
      }
    }

    const userCount = await User.countDocuments({});
    const role = userCount === 0 ? 'admin' : 'user';

    const user = await User.create({
      name,
      email,
      phone: phone || undefined,
      password,
      role
    });

    if (user) {
      res.status(201).json({
        success: true,
        _id: user._id,
        name: user.name,
        email: user.email,
        phone: user.phone,
        role: user.role,
        token: generateToken(user._id)
      });
    } else {
      res.status(400).json({ success: false, message: 'Invalid user data' });
    }
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Auth user & get token (supports Email OR Phone)
// @route   POST /api/auth/login
// @access  Public
exports.loginUser = async (req, res) => {
  try {
    const { email, password } = req.body; // 'email' field in request carries email or phone
    const emailOrPhone = email;

    if (!emailOrPhone || !password) {
      return res.status(400).json({ success: false, message: 'Please provide email/phone and password' });
    }

    if (!getIsConnected()) {
      // Offline fallback login
      const user = mockStore.users.find(
        u => u.email === emailOrPhone || u.phone === emailOrPhone
      );
      
      if (user && !user.isGoogleUser && bcrypt.compareSync(password, user.password)) {
        return res.json({
          success: true,
          _id: user._id,
          name: user.name,
          email: user.email,
          phone: user.phone,
          role: user.role,
          token: generateToken(user._id)
        });
      } else {
        return res.status(401).json({ success: false, message: 'Invalid credentials' });
      }
    }

    // Standard MongoDB login: Match email or phone
    const user = await User.findOne({
      $or: [{ email: emailOrPhone }, { phone: emailOrPhone }]
    }).select('+password');

    if (user && !user.isGoogleUser && (await user.matchPassword(password))) {
      res.json({
        success: true,
        _id: user._id,
        name: user.name,
        email: user.email,
        phone: user.phone,
        role: user.role,
        token: generateToken(user._id)
      });
    } else {
      res.status(401).json({ success: false, message: 'Invalid credentials' });
    }
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Google Sign Up/Login
// @route   POST /api/auth/google-login
// @access  Public
exports.googleLogin = async (req, res) => {
  try {
    const { name, email } = req.body;

    if (!email || !name) {
      return res.status(400).json({ success: false, message: 'Invalid Google profile payload' });
    }

    if (!getIsConnected()) {
      // Offline fallback Google Login
      let user = mockStore.users.find(u => u.email === email);

      if (!user) {
        // Create user
        const role = mockStore.users.length === 0 ? 'admin' : 'user';
        user = {
          _id: `u_google_${Date.now()}`,
          name,
          email,
          phone: null,
          isGoogleUser: true,
          role,
          createdAt: new Date()
        };
        mockStore.users.push(user);
      }

      return res.json({
        success: true,
        _id: user._id,
        name: user.name,
        email: user.email,
        phone: user.phone,
        role: user.role,
        token: generateToken(user._id)
      });
    }

    // Standard MongoDB Google Login
    let user = await User.findOne({ email });

    if (!user) {
      const userCount = await User.countDocuments({});
      const role = userCount === 0 ? 'admin' : 'user';

      // Create new Google Auth user
      user = await User.create({
        name,
        email,
        isGoogleUser: true,
        role
      });
    }

    res.json({
      success: true,
      _id: user._id,
      name: user.name,
      email: user.email,
      phone: user.phone,
      role: user.role,
      token: generateToken(user._id)
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Get user profile
// @route   GET /api/auth/me
// @access  Private
exports.getMe = async (req, res) => {
  try {
    if (!getIsConnected()) {
      const user = mockStore.users.find(u => u._id === req.user.id);
      if (user) {
        return res.json({
          success: true,
          _id: user._id,
          name: user.name,
          email: user.email,
          phone: user.phone,
          role: user.role
        });
      } else {
        return res.status(404).json({ success: false, message: 'User not found' });
      }
    }

    const user = await User.findById(req.user.id);
    if (user) {
      res.json({
        success: true,
        _id: user._id,
        name: user.name,
        email: user.email,
        phone: user.phone,
        role: user.role
      });
    } else {
      res.status(404).json({ success: false, message: 'User not found' });
    }
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Update user profile
// @route   PUT /api/auth/profile
// @access  Private
exports.updateProfile = async (req, res) => {
  try {
    const { name, email, phone, password } = req.body;

    if (!getIsConnected()) {
      const user = mockStore.users.find(u => u._id === req.user.id);
      if (user) {
        // If updating email/phone, check uniqueness
        if (email && email !== user.email) {
          const emailExists = mockStore.users.find(u => u.email === email);
          if (emailExists) return res.status(400).json({ success: false, message: 'Email already in use' });
          user.email = email;
        }

        if (phone && phone !== user.phone) {
          const phoneExists = mockStore.users.find(u => u.phone === phone);
          if (phoneExists) return res.status(400).json({ success: false, message: 'Phone number already in use' });
          user.phone = phone;
        }

        user.name = name || user.name;
        
        if (password && !user.isGoogleUser) {
          user.password = bcrypt.hashSync(password, 10);
        }

        return res.json({
          success: true,
          _id: user._id,
          name: user.name,
          email: user.email,
          phone: user.phone,
          role: user.role,
          token: generateToken(user._id)
        });
      } else {
        return res.status(404).json({ success: false, message: 'User not found' });
      }
    }

    const user = await User.findById(req.user.id);
    if (user) {
      // Validate uniqueness
      if (email && email !== user.email) {
        const emailExists = await User.findOne({ email });
        if (emailExists) return res.status(400).json({ success: false, message: 'Email already in use' });
        user.email = email;
      }

      if (phone && phone !== user.phone) {
        const phoneExists = await User.findOne({ phone });
        if (phoneExists) return res.status(400).json({ success: false, message: 'Phone number already in use' });
        user.phone = phone;
      }

      user.name = name || user.name;

      if (password && !user.isGoogleUser) {
        user.password = password;
      }

      const updatedUser = await user.save();

      res.json({
        success: true,
        _id: updatedUser._id,
        name: updatedUser.name,
        email: updatedUser.email,
        phone: updatedUser.phone,
        role: updatedUser.role,
        token: generateToken(updatedUser._id)
      });
    } else {
      res.status(404).json({ success: false, message: 'User not found' });
    }
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Get all users (admin only)
// @route   GET /api/auth/users
// @access  Private/Admin
exports.getUsers = async (req, res) => {
  try {
    if (!getIsConnected()) {
      return res.json({ success: true, users: mockStore.users });
    }

    const users = await User.find({});
    res.json({ success: true, users });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};
