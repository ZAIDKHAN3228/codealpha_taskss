const Order = require('../models/Order');
const Product = require('../models/Product');
const Cart = require('../models/Cart');
const { getIsConnected } = require('../config/db');
const mockStore = require('../config/mockStore');

// @desc    Create a new order
// @route   POST /api/orders
// @access  Private
exports.createOrder = async (req, res) => {
  try {
    const { products, shippingAddress, paymentMethod } = req.body;
    const userId = req.user._id.toString();

    if (!products || products.length === 0) {
      return res.status(400).json({ success: false, message: 'No products in order' });
    }

    if (!shippingAddress || !paymentMethod) {
      return res.status(400).json({ success: false, message: 'Please provide shipping address and payment method' });
    }

    if (!getIsConnected()) {
      // Offline fallback order creation
      let calculatedTotal = 0;
      const orderItems = [];

      // Validate stock
      for (const item of products) {
        const product = mockStore.products.find(p => p._id === item.product);
        if (!product) {
          return res.status(404).json({ success: false, message: `Product not found: ${item.name || item.product}` });
        }

        if (product.stock < item.quantity) {
          return res.status(400).json({
            success: false,
            message: `Insufficient stock for product: ${product.name}. Available: ${product.stock}, Ordered: ${item.quantity}`
          });
        }

        const finalPrice = product.price * (1 - (product.discount || 0) / 100);
        calculatedTotal += finalPrice * item.quantity;

        orderItems.push({
          product: product._id,
          name: product.name,
          price: Number(finalPrice.toFixed(2)),
          quantity: item.quantity,
          image: product.images[0] || ''
        });

        // Deduct mock stock
        product.stock -= item.quantity;
      }

      const taxAmount = Number((calculatedTotal * 0.08).toFixed(2));
      const shippingAmount = calculatedTotal >= 15000 ? 0 : 999;
      const totalAmount = Number((calculatedTotal + taxAmount + shippingAmount).toFixed(2));

      const newOrder = {
        _id: `o_${Date.now()}`,
        user: {
          _id: req.user._id,
          name: req.user.name,
          email: req.user.email
        },
        products: orderItems,
        shippingAddress,
        paymentMethod,
        orderStatus: 'Pending',
        taxAmount,
        shippingAmount,
        totalAmount,
        orderDate: new Date()
      };

      mockStore.orders.push(newOrder);

      // Clear mock cart
      mockStore.carts[userId] = { user: userId, products: [], total: 0, updatedAt: Date.now() };

      return res.status(201).json({ success: true, order: newOrder });
    }

    // Standard MongoDB creation
    let calculatedTotal = 0;
    const orderItems = [];

    // Verify stock and calculate total
    for (const item of products) {
      const product = await Product.findById(item.product);
      if (!product) {
        return res.status(404).json({ success: false, message: `Product not found: ${item.name || item.product}` });
      }

      if (product.stock < item.quantity) {
        return res.status(400).json({
          success: false,
          message: `Insufficient stock for product: ${product.name}. Available: ${product.stock}, Ordered: ${item.quantity}`
        });
      }

      // Calculate item price with discount
      const finalPrice = product.price * (1 - (product.discount || 0) / 100);
      calculatedTotal += finalPrice * item.quantity;

      // Add to items list
      orderItems.push({
        product: product._id,
        name: product.name,
        price: Number(finalPrice.toFixed(2)),
        quantity: item.quantity,
        image: product.images[0] || ''
      });

      // Deduct stock
      product.stock -= item.quantity;
      await product.save();
    }

    // Calculations: Tax (8%), Shipping ($15 flat, or free if items total is > $150)
    const taxAmount = Number((calculatedTotal * 0.08).toFixed(2));
    const shippingAmount = calculatedTotal >= 15000 ? 0 : 999;
    const totalAmount = Number((calculatedTotal + taxAmount + shippingAmount).toFixed(2));

    // Save order
    const order = new Order({
      user: req.user._id,
      products: orderItems,
      shippingAddress,
      paymentMethod,
      taxAmount,
      shippingAmount,
      totalAmount
    });

    const createdOrder = await order.save();

    // Clear database cart
    await Cart.findOneAndUpdate({ user: req.user._id }, { products: [], total: 0 });

    res.status(201).json({ success: true, order: createdOrder });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Get logged in user orders
// @route   GET /api/orders/myorders
// @access  Private
exports.getMyOrders = async (req, res) => {
  try {
    const userId = req.user._id.toString();

    if (!getIsConnected()) {
      const orders = mockStore.orders
        .filter(o => o.user._id.toString() === userId)
        .sort((a, b) => new Date(b.orderDate) - new Date(a.orderDate));
      return res.json({ success: true, orders });
    }

    const orders = await Order.find({ user: req.user._id }).sort({ orderDate: -1 });
    res.json({ success: true, orders });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Get order by ID
// @route   GET /api/orders/:id
// @access  Private
exports.getOrderById = async (req, res) => {
  try {
    const orderId = req.params.id;
    const userId = req.user._id.toString();

    if (!getIsConnected()) {
      const order = mockStore.orders.find(o => o._id === orderId);

      if (!order) {
        return res.status(404).json({ success: false, message: 'Order not found' });
      }

      // Check owner or admin
      if (order.user._id.toString() !== userId && req.user.role !== 'admin') {
        return res.status(403).json({ success: false, message: 'Not authorized to view this order' });
      }

      return res.json({ success: true, order });
    }

    const order = await Order.findById(orderId).populate('user', 'name email');

    if (!order) {
      return res.status(404).json({ success: false, message: 'Order not found' });
    }

    // Check if user is owner of the order OR admin
    if (order.user._id.toString() !== req.user._id.toString() && req.user.role !== 'admin') {
      return res.status(403).json({ success: false, message: 'Not authorized to view this order' });
    }

    res.json({ success: true, order });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Get all orders (Admin only)
// @route   GET /api/orders
// @access  Private/Admin
exports.getOrders = async (req, res) => {
  try {
    if (!getIsConnected()) {
      const orders = [...mockStore.orders].sort((a, b) => new Date(b.orderDate) - new Date(a.orderDate));
      return res.json({ success: true, orders });
    }

    const orders = await Order.find({}).populate('user', 'id name email').sort({ orderDate: -1 });
    res.json({ success: true, orders });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Update order status (Admin only)
// @route   PUT /api/orders/:id/status
// @access  Private/Admin
exports.updateOrderStatus = async (req, res) => {
  try {
    const { status } = req.body;
    const orderId = req.params.id;

    if (!['Pending', 'Processing', 'Shipped', 'Delivered', 'Cancelled'].includes(status)) {
      return res.status(400).json({ success: false, message: 'Invalid order status' });
    }

    if (!getIsConnected()) {
      const order = mockStore.orders.find(o => o._id === orderId);
      if (order) {
        order.orderStatus = status;
        return res.json({ success: true, order });
      } else {
        return res.status(404).json({ success: false, message: 'Order not found' });
      }
    }

    const order = await Order.findById(orderId);

    if (order) {
      order.orderStatus = status;
      const updatedOrder = await order.save();
      res.json({ success: true, order: updatedOrder });
    } else {
      res.status(404).json({ success: false, message: 'Order not found' });
    }
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Get dashboard statistics (Admin only)
// @route   GET /api/orders/stats
// @access  Private/Admin
exports.getDashboardStats = async (req, res) => {
  try {
    if (!getIsConnected()) {
      const ordersCount = mockStore.orders.length;
      const productsCount = mockStore.products.length;
      
      const activeOrders = mockStore.orders.filter(o => o.orderStatus !== 'Cancelled');
      const totalSales = activeOrders.reduce((sum, order) => sum + order.totalAmount, 0);

      const categoriesSales = {};
      activeOrders.forEach(order => {
        order.products.forEach(item => {
          const prod = mockStore.products.find(p => p._id === item.product);
          const cat = prod ? prod.category : 'Unknown';
          categoriesSales[cat] = (categoriesSales[cat] || 0) + (item.price * item.quantity);
        });
      });

      const latestOrders = [...mockStore.orders]
        .sort((a, b) => new Date(b.orderDate) - new Date(a.orderDate))
        .slice(0, 5);

      return res.json({
        success: true,
        stats: {
          ordersCount,
          productsCount,
          totalSales: Number(totalSales.toFixed(2)),
          categoriesSales,
          latestOrders
        }
      });
    }

    const ordersCount = await Order.countDocuments({});
    const productsCount = await Product.countDocuments({});
    
    // Total Sales sum
    const orders = await Order.find({ orderStatus: { $ne: 'Cancelled' } });
    const totalSales = orders.reduce((sum, order) => sum + order.totalAmount, 0);

    // Sales by Category
    const categoriesSales = {};
    for (const order of orders) {
      for (const item of order.products) {
        const prod = await Product.findById(item.product);
        const cat = prod ? prod.category : 'Unknown';
        categoriesSales[cat] = (categoriesSales[cat] || 0) + (item.price * item.quantity);
      }
    }

    // Latest Orders
    const latestOrders = await Order.find({})
      .populate('user', 'name')
      .sort({ orderDate: -1 })
      .limit(5);

    res.json({
      success: true,
      stats: {
        ordersCount,
        productsCount,
        totalSales: Number(totalSales.toFixed(2)),
        categoriesSales,
        latestOrders
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};
