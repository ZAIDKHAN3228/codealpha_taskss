const Product = require('../models/Product');
const { getIsConnected } = require('../config/db');
const mockStore = require('../config/mockStore');

// @desc    Get all products (with search, filter, sorting, and pagination)
// @route   GET /api/products
// @access  Public
exports.getProducts = async (req, res) => {
  try {
    const { search, category, minPrice, maxPrice, sort, page = 1, limit = 100 } = req.query;

    if (!getIsConnected()) {
      // Offline fallback products list
      let products = [...mockStore.products];

      // Filter by search
      if (search) {
        products = products.filter(p => p.name.toLowerCase().includes(search.toLowerCase()));
      }

      // Filter by category
      if (category) {
        products = products.filter(p => p.category.toLowerCase() === category.toLowerCase());
      }

      // Filter by price ranges
      if (minPrice) {
        products = products.filter(p => p.price >= Number(minPrice));
      }
      if (maxPrice) {
        products = products.filter(p => p.price <= Number(maxPrice));
      }

      // Sort
      if (sort === 'low') {
        products.sort((a, b) => a.price - b.price);
      } else if (sort === 'high') {
        products.sort((a, b) => b.price - a.price);
      } else {
        products.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
      }

      const count = products.length;
      const paginated = products.slice((Number(page) - 1) * Number(limit), Number(page) * Number(limit));

      return res.json({
        success: true,
        products: paginated,
        page: Number(page),
        pages: Math.ceil(count / Number(limit)),
        totalProducts: count
      });
    }

    const query = {};

    // Search query
    if (search) {
      query.name = { $regex: search, $options: 'i' };
    }

    // Category query
    if (category) {
      query.category = category;
    }

    // Price query
    if (minPrice || maxPrice) {
      query.price = {};
      if (minPrice) query.price.$gte = Number(minPrice);
      if (maxPrice) query.price.$lte = Number(maxPrice);
    }

    // Sort query
    let sortBy = {};
    if (sort === 'low') {
      sortBy = { price: 1 };
    } else if (sort === 'high') {
      sortBy = { price: -1 };
    } else if (sort === 'newest') {
      sortBy = { createdAt: -1 };
    } else {
      sortBy = { createdAt: -1 }; // default sorting
    }

    const count = await Product.countDocuments(query);
    const products = await Product.find(query)
      .sort(sortBy)
      .limit(Number(limit))
      .skip((Number(page) - 1) * Number(limit));

    res.json({
      success: true,
      products,
      page: Number(page),
      pages: Math.ceil(count / Number(limit)),
      totalProducts: count
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Get product by ID
// @route   GET /api/products/:id
// @access  Public
exports.getProductById = async (req, res) => {
  try {
    const productId = req.params.id;

    if (!getIsConnected()) {
      const product = mockStore.products.find(p => p._id === productId);
      if (product) {
        return res.json({ success: true, product });
      } else {
        return res.status(404).json({ success: false, message: 'Product not found' });
      }
    }

    const product = await Product.findById(productId);

    if (product) {
      res.json({ success: true, product });
    } else {
      res.status(404).json({ success: false, message: 'Product not found' });
    }
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Create a product (Admin only)
// @route   POST /api/products
// @access  Private/Admin
exports.createProduct = async (req, res) => {
  try {
    const { name, description, price, discount, category, stock, specifications } = req.body;

    let images = [];
    if (req.files && req.files.length > 0) {
      images = req.files.map(file => `/uploads/${file.filename}`);
    } else if (req.body.images) {
      images = Array.isArray(req.body.images) ? req.body.images : [req.body.images];
    }

    // Parse specifications
    let parsedSpecs = {};
    if (specifications) {
      parsedSpecs = typeof specifications === 'string' ? JSON.parse(specifications) : specifications;
    }

    if (!getIsConnected()) {
      const newProduct = {
        _id: `p_${Date.now()}`,
        name,
        description,
        price: Number(price),
        discount: discount ? Number(discount) : 0,
        images: images.length > 0 ? images : ["https://images.unsplash.com/photo-1531403009284-440f080d1e12?w=800"],
        category,
        stock: Number(stock),
        specifications: parsedSpecs,
        rating: 0,
        numReviews: 0,
        reviews: [],
        createdAt: new Date()
      };

      mockStore.products.push(newProduct);
      return res.status(201).json({ success: true, product: newProduct });
    }

    const product = new Product({
      name,
      description,
      price: Number(price),
      discount: discount ? Number(discount) : 0,
      images,
      category,
      stock: Number(stock),
      specifications: parsedSpecs,
      rating: 0,
      numReviews: 0
    });

    const createdProduct = await product.save();
    res.status(201).json({ success: true, product: createdProduct });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Update a product (Admin only)
// @route   PUT /api/products/:id
// @access  Private/Admin
exports.updateProduct = async (req, res) => {
  try {
    const { name, description, price, discount, category, stock, specifications } = req.body;
    const productId = req.params.id;

    let images = [];
    if (req.files && req.files.length > 0) {
      images = req.files.map(file => `/uploads/${file.filename}`);
    } else if (req.body.images) {
      images = Array.isArray(req.body.images) ? req.body.images : [req.body.images];
    }

    // Parse specifications
    let parsedSpecs = {};
    if (specifications) {
      parsedSpecs = typeof specifications === 'string' ? JSON.parse(specifications) : specifications;
    }

    if (!getIsConnected()) {
      const product = mockStore.products.find(p => p._id === productId);
      if (product) {
        product.name = name || product.name;
        product.description = description || product.description;
        product.price = price !== undefined ? Number(price) : product.price;
        product.discount = discount !== undefined ? Number(discount) : product.discount;
        product.category = category || product.category;
        product.stock = stock !== undefined ? Number(stock) : product.stock;
        
        if (specifications) {
          product.specifications = parsedSpecs;
        }

        if (images.length > 0) {
          product.images = images;
        }

        return res.json({ success: true, product });
      } else {
        return res.status(404).json({ success: false, message: 'Product not found' });
      }
    }

    const product = await Product.findById(productId);

    if (product) {
      product.name = name || product.name;
      product.description = description || product.description;
      product.price = price !== undefined ? Number(price) : product.price;
      product.discount = discount !== undefined ? Number(discount) : product.discount;
      product.category = category || product.category;
      product.stock = stock !== undefined ? Number(stock) : product.stock;
      
      if (specifications) {
        product.specifications = parsedSpecs;
      }

      if (req.files && req.files.length > 0) {
        product.images = req.files.map(file => `/uploads/${file.filename}`);
      } else if (req.body.images) {
        product.images = Array.isArray(req.body.images) ? req.body.images : [req.body.images];
      }

      const updatedProduct = await product.save();
      res.json({ success: true, product: updatedProduct });
    } else {
      res.status(404).json({ success: false, message: 'Product not found' });
    }
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Delete a product (Admin only)
// @route   DELETE /api/products/:id
// @access  Private/Admin
exports.deleteProduct = async (req, res) => {
  try {
    const productId = req.params.id;

    if (!getIsConnected()) {
      const index = mockStore.products.findIndex(p => p._id === productId);
      if (index > -1) {
        mockStore.products.splice(index, 1);
        return res.json({ success: true, message: 'Product removed' });
      } else {
        return res.status(404).json({ success: false, message: 'Product not found' });
      }
    }

    const product = await Product.findById(productId);

    if (product) {
      await Product.deleteOne({ _id: productId });
      res.json({ success: true, message: 'Product removed' });
    } else {
      res.status(404).json({ success: false, message: 'Product not found' });
    }
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Create a product review
// @route   POST /api/products/:id/reviews
// @access  Private
exports.createProductReview = async (req, res) => {
  try {
    const { rating, comment } = req.body;
    const productId = req.params.id;

    if (!getIsConnected()) {
      const product = mockStore.products.find(p => p._id === productId);
      if (product) {
        const alreadyReviewed = product.reviews.find(
          (r) => r.user.toString() === req.user._id.toString()
        );

        if (alreadyReviewed) {
          return res.status(400).json({ success: false, message: 'Product already reviewed' });
        }

        const review = {
          _id: `r_${Date.now()}`,
          name: req.user.name,
          rating: Number(rating),
          comment,
          user: req.user._id,
          createdAt: new Date()
        };

        product.reviews.push(review);
        product.numReviews = product.reviews.length;
        
        // Calculate average rating
        product.rating =
          product.reviews.reduce((acc, item) => item.rating + acc, 0) /
          product.reviews.length;

        return res.status(201).json({ success: true, message: 'Review added' });
      } else {
        return res.status(404).json({ success: false, message: 'Product not found' });
      }
    }

    const product = await Product.findById(productId);

    if (product) {
      const alreadyReviewed = product.reviews.find(
        (r) => r.user.toString() === req.user._id.toString()
      );

      if (alreadyReviewed) {
        return res.status(400).json({ success: false, message: 'Product already reviewed' });
      }

      const review = {
        name: req.user.name,
        rating: Number(rating),
        comment,
        user: req.user._id
      };

      product.reviews.push(review);
      product.numReviews = product.reviews.length;
      
      // Calculate average rating
      product.rating =
        product.reviews.reduce((acc, item) => item.rating + acc, 0) /
        product.reviews.length;

      await product.save();
      res.status(201).json({ success: true, message: 'Review added' });
    } else {
      res.status(404).json({ success: false, message: 'Product not found' });
    }
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};
