const Cart = require('../models/Cart');
const Product = require('../models/Product');
const { getIsConnected } = require('../config/db');
const mockStore = require('../config/mockStore');

// Helper to recalculate total (DB version)
const calculateCartTotal = async (cart) => {
  let total = 0;
  for (const item of cart.products) {
    const product = await Product.findById(item.product);
    if (product) {
      const finalPrice = product.price * (1 - (product.discount || 0) / 100);
      total += finalPrice * item.quantity;
    }
  }
  cart.total = Number(total.toFixed(2));
  cart.updatedAt = Date.now();
  await cart.save();
};

// Helper to recalculate total (Mock in-memory version)
const calculateMockCartTotal = (cart) => {
  let total = 0;
  cart.products.forEach(item => {
    const product = mockStore.products.find(p => p._id === item.product._id);
    if (product) {
      const finalPrice = product.price * (1 - (product.discount || 0) / 100);
      total += finalPrice * item.quantity;
    }
  });
  cart.total = Number(total.toFixed(2));
  cart.updatedAt = Date.now();
};

// Helper to populate a mock cart
const getPopulatedMockCart = (userId) => {
  let cart = mockStore.carts[userId];
  if (!cart) {
    cart = { user: userId, products: [], total: 0, updatedAt: Date.now() };
    mockStore.carts[userId] = cart;
  }

  // Populate products
  const populatedProducts = cart.products.map(item => {
    const productObj = mockStore.products.find(p => p._id === item.product);
    return {
      _id: `ci_${Date.now()}_${Math.random()}`,
      product: productObj || { _id: item.product, name: 'Unknown' },
      quantity: item.quantity
    };
  });

  const populatedCart = { ...cart, products: populatedProducts };
  calculateMockCartTotal(populatedCart);
  cart.total = populatedCart.total;

  return populatedCart;
};

// @desc    Get current user's cart
// @route   GET /api/cart
// @access  Private
exports.getCart = async (req, res) => {
  try {
    const userId = req.user._id.toString();

    if (!getIsConnected()) {
      const cart = getPopulatedMockCart(userId);
      return res.json({ success: true, cart });
    }

    let cart = await Cart.findOne({ user: req.user._id }).populate('products.product');

    if (!cart) {
      cart = await Cart.create({ user: req.user._id, products: [], total: 0 });
    }

    res.json({ success: true, cart });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Add item to cart or update quantity if exists
// @route   POST /api/cart
// @access  Private
exports.addToCart = async (req, res) => {
  try {
    const { productId, quantity = 1 } = req.body;
    const userId = req.user._id.toString();

    if (!getIsConnected()) {
      const product = mockStore.products.find(p => p._id === productId);
      if (!product) {
        return res.status(404).json({ success: false, message: 'Product not found' });
      }

      let cart = mockStore.carts[userId];
      if (!cart) {
        cart = { user: userId, products: [], total: 0, updatedAt: Date.now() };
        mockStore.carts[userId] = cart;
      }

      const itemIndex = cart.products.findIndex(p => p.product === productId);
      if (itemIndex > -1) {
        cart.products[itemIndex].quantity += Number(quantity);
      } else {
        cart.products.push({ product: productId, quantity: Number(quantity) });
      }

      const populatedCart = getPopulatedMockCart(userId);
      return res.json({ success: true, cart: populatedCart });
    }

    const product = await Product.findById(productId);
    if (!product) {
      return res.status(404).json({ success: false, message: 'Product not found' });
    }

    let cart = await Cart.findOne({ user: req.user._id });
    if (!cart) {
      cart = new Cart({ user: req.user._id, products: [], total: 0 });
    }

    // Check if product already in cart
    const itemIndex = cart.products.findIndex(p => p.product.toString() === productId);

    if (itemIndex > -1) {
      // product exists in cart, update quantity
      cart.products[itemIndex].quantity += Number(quantity);
    } else {
      // product does not exist in cart, add new item
      cart.products.push({ product: productId, quantity: Number(quantity) });
    }

    await calculateCartTotal(cart);
    
    // Populate product data before sending response
    const populatedCart = await Cart.findById(cart._id).populate('products.product');

    res.json({ success: true, cart: populatedCart });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Update cart item quantity
// @route   PUT /api/cart/:id
// @access  Private
exports.updateCartItem = async (req, res) => {
  try {
    const { quantity } = req.body;
    const productId = req.params.id; // item ID or product ID
    const userId = req.user._id.toString();

    if (!getIsConnected()) {
      let cart = mockStore.carts[userId];
      if (!cart) {
        return res.status(404).json({ success: false, message: 'Cart not found' });
      }

      const itemIndex = cart.products.findIndex(p => p.product === productId);
      if (itemIndex > -1) {
        cart.products[itemIndex].quantity = Number(quantity);
        if (cart.products[itemIndex].quantity <= 0) {
          cart.products.splice(itemIndex, 1);
        }
      } else {
        return res.status(404).json({ success: false, message: 'Item not found in cart' });
      }

      const populatedCart = getPopulatedMockCart(userId);
      return res.json({ success: true, cart: populatedCart });
    }

    const cart = await Cart.findOne({ user: req.user._id });
    if (!cart) {
      return res.status(404).json({ success: false, message: 'Cart not found' });
    }

    const itemIndex = cart.products.findIndex(p => p.product.toString() === productId);

    if (itemIndex > -1) {
      cart.products[itemIndex].quantity = Number(quantity);
      if (cart.products[itemIndex].quantity <= 0) {
        cart.products.splice(itemIndex, 1);
      }
    } else {
      return res.status(404).json({ success: false, message: 'Item not found in cart' });
    }

    await calculateCartTotal(cart);
    const populatedCart = await Cart.findById(cart._id).populate('products.product');

    res.json({ success: true, cart: populatedCart });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Delete cart item
// @route   DELETE /api/cart/:id
// @access  Private
exports.deleteCartItem = async (req, res) => {
  try {
    const productId = req.params.id;
    const userId = req.user._id.toString();

    if (!getIsConnected()) {
      let cart = mockStore.carts[userId];
      if (!cart) {
        return res.status(404).json({ success: false, message: 'Cart not found' });
      }

      cart.products = cart.products.filter(p => p.product !== productId);
      const populatedCart = getPopulatedMockCart(userId);
      return res.json({ success: true, cart: populatedCart });
    }

    const cart = await Cart.findOne({ user: req.user._id });
    if (!cart) {
      return res.status(404).json({ success: false, message: 'Cart not found' });
    }

    cart.products = cart.products.filter(p => p.product.toString() !== productId);

    await calculateCartTotal(cart);
    const populatedCart = await Cart.findById(cart._id).populate('products.product');

    res.json({ success: true, cart: populatedCart });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// @desc    Sync local cart with database cart
// @route   POST /api/cart/sync
// @access  Private
exports.syncCart = async (req, res) => {
  try {
    const { localProducts } = req.body;
    const userId = req.user._id.toString();

    if (!Array.isArray(localProducts)) {
      return res.status(400).json({ success: false, message: 'Invalid local products data' });
    }

    if (!getIsConnected()) {
      let cart = mockStore.carts[userId];
      if (!cart) {
        cart = { user: userId, products: [], total: 0, updatedAt: Date.now() };
        mockStore.carts[userId] = cart;
      }

      localProducts.forEach(localItem => {
        const dbItemIndex = cart.products.findIndex(p => p.product === localItem.product);
        if (dbItemIndex > -1) {
          cart.products[dbItemIndex].quantity += Number(localItem.quantity);
        } else {
          cart.products.push({
            product: localItem.product,
            quantity: Number(localItem.quantity)
          });
        }
      });

      const populatedCart = getPopulatedMockCart(userId);
      return res.json({ success: true, cart: populatedCart });
    }

    let cart = await Cart.findOne({ user: req.user._id });
    if (!cart) {
      cart = new Cart({ user: req.user._id, products: [], total: 0 });
    }

    // Merge logic: Add or update
    for (const localItem of localProducts) {
      const dbItemIndex = cart.products.findIndex(
        p => p.product.toString() === localItem.product
      );

      if (dbItemIndex > -1) {
        cart.products[dbItemIndex].quantity += Number(localItem.quantity);
      } else {
        cart.products.push({
          product: localItem.product,
          quantity: Number(localItem.quantity)
        });
      }
    }

    await calculateCartTotal(cart);
    const populatedCart = await Cart.findById(cart._id).populate('products.product');

    res.json({ success: true, cart: populatedCart });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};
