// E-Commerce API Wrapper
const API_BASE = 'http://localhost:5000/api';

const API = {
  // Token handlers
  getToken() {
    return localStorage.getItem('token');
  },
  
  setToken(token) {
    localStorage.setItem('token', token);
  },
  
  removeToken() {
    localStorage.removeItem('token');
  },

  getUser() {
    const userStr = localStorage.getItem('user');
    return userStr ? JSON.parse(userStr) : null;
  },

  setUser(user) {
    localStorage.setItem('user', JSON.stringify(user));
  },

  removeUser() {
    localStorage.removeItem('user');
  },

  // Base fetch logic with Authorization headers
  async request(endpoint, options = {}) {
    const token = this.getToken();
    const headers = {
      ...options.headers
    };

    // Auto-detect if body is FormData (for image uploads), else set JSON headers
    if (options.body && !(options.body instanceof FormData)) {
      headers['Content-Type'] = 'application/json';
      options.body = JSON.stringify(options.body);
    }

    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }

    const config = {
      ...options,
      headers
    };

    try {
      const response = await fetch(`${API_BASE}${endpoint}`, config);
      const data = await response.json();

      if (!response.ok) {
        // If JWT expired/invalid, logout user
        if (response.status === 401 && token) {
          this.logout();
          window.location.href = '/login.html?expired=true';
        }
        throw new Error(data.message || 'Something went wrong');
      }

      return data;
    } catch (error) {
      console.error(`API Error in ${endpoint}:`, error);
      throw error;
    }
  },

  // Auth Operations
  auth: {
    async register(name, email, phone, password) {
      const data = await API.request('/auth/register', {
        method: 'POST',
        body: { name, email, phone, password }
      });
      if (data.token) {
        API.setToken(data.token);
        API.setUser({ _id: data._id, name: data.name, email: data.email, role: data.role });
      }
      return data;
    },

    async login(email, password) {
      const data = await API.request('/auth/login', {
        method: 'POST',
        body: { email, password }
      });
      if (data.token) {
        API.setToken(data.token);
        API.setUser({ _id: data._id, name: data.name, email: data.email, role: data.role });
      }
      return data;
    },

    async googleLogin(name, email) {
      const data = await API.request('/auth/google-login', {
        method: 'POST',
        body: { name, email }
      });
      if (data.token) {
        API.setToken(data.token);
        API.setUser({ _id: data._id, name: data.name, email: data.email, role: data.role });
      }
      return data;
    },

    async getMe() {
      return await API.request('/auth/me');
    },

    async updateProfile(profileData) {
      const data = await API.request('/auth/profile', {
        method: 'PUT',
        body: profileData
      });
      if (data.token) {
        API.setToken(data.token);
        API.setUser({ _id: data._id, name: data.name, email: data.email, role: data.role });
      }
      return data;
    },

    async getUsers() {
      return await API.request('/auth/users');
    }
  },

  // Products Operations
  products: {
    async getAll(params = {}) {
      const queryString = new URLSearchParams(params).toString();
      return await API.request(`/products?${queryString}`);
    },

    async getById(id) {
      return await API.request(`/products/${id}`);
    },

    async create(productFormData) {
      return await API.request('/products', {
        method: 'POST',
        body: productFormData // FormData instance
      });
    },

    async update(id, productFormData) {
      return await API.request(`/products/${id}`, {
        method: 'PUT',
        body: productFormData // FormData instance
      });
    },

    async delete(id) {
      return await API.request(`/products/${id}`, {
        method: 'DELETE'
      });
    },

    async addReview(id, reviewData) {
      return await API.request(`/products/${id}/reviews`, {
        method: 'POST',
        body: reviewData
      });
    }
  },

  // Database Cart Operations (used when user is logged in)
  cart: {
    async get() {
      return await API.request('/cart');
    },

    async add(productId, quantity = 1) {
      return await API.request('/cart', {
        method: 'POST',
        body: { productId, quantity }
      });
    },

    async update(productId, quantity) {
      return await API.request(`/cart/${productId}`, {
        method: 'PUT',
        body: { quantity }
      });
    },

    async remove(productId) {
      return await API.request(`/cart/${productId}`, {
        method: 'DELETE'
      });
    },

    async sync(localProducts) {
      return await API.request('/cart/sync', {
        method: 'POST',
        body: { localProducts }
      });
    }
  },

  // Orders Operations
  orders: {
    async create(orderData) {
      return await API.request('/orders', {
        method: 'POST',
        body: orderData
      });
    },

    async getMyOrders() {
      return await API.request('/orders/myorders');
    },

    async getById(id) {
      return await API.request(`/orders/${id}`);
    },

    async getAll() {
      return await API.request('/orders');
    },

    async updateStatus(id, status) {
      return await API.request(`/orders/${id}/status`, {
        method: 'PUT',
        body: { status }
      });
    },

    async getStats() {
      return await API.request('/orders/stats');
    }
  },

  // Local Helpers
  logout() {
    this.removeToken();
    this.removeUser();
    // clear cart when logging out (local)
    localStorage.removeItem('cart');
  },

  isLoggedIn() {
    return !!this.getToken();
  },

  isAdmin() {
    const user = this.getUser();
    return user && user.role === 'admin';
  }
};
