// Global UI Components and Helpers
document.addEventListener('DOMContentLoaded', () => {
  initTheme();
  renderHeader();
  renderFooter();
  updateCartBadge();
  setupDropdowns();
  checkSessionMessages();
});

// Theme Management
function initTheme() {
  const currentTheme = localStorage.getItem('theme') || 'light';
  document.documentElement.setAttribute('data-theme', currentTheme);
}

function toggleTheme() {
  const currentTheme = document.documentElement.getAttribute('data-theme');
  const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
  document.documentElement.setAttribute('data-theme', newTheme);
  localStorage.setItem('theme', newTheme);
  
  // Update toggle icons if they exist on page
  updateThemeIcons(newTheme);
}

function updateThemeIcons(theme) {
  const icons = document.querySelectorAll('.theme-toggle-icon');
  icons.forEach(icon => {
    if (theme === 'dark') {
      // moon icon or sun icon
      icon.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="4"/><path d="M12 2v2"/><path d="M12 20v2"/><path d="M4.93 4.93l1.41 1.41"/><path d="M17.66 17.66l1.41 1.41"/><path d="M2 12h2"/><path d="M20 12h2"/><path d="M6.34 17.66l-1.41 1.41"/><path d="M19.07 4.93l-1.41 1.41"/></svg>`;
    } else {
      icon.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"/></svg>`;
    }
  });
}

// Render Global Header
function renderHeader() {
  const headerEl = document.getElementById('global-header');
  if (!headerEl) return;

  const isLoggedIn = API.isLoggedIn();
  const isAdmin = API.isAdmin();
  const user = API.getUser();
  const currentPath = window.location.pathname;

  headerEl.className = 'header';
  
  let userMenuHTML = '';
  if (isLoggedIn) {
    userMenuHTML = `
      <div class="user-menu" id="user-menu">
        <div class="user-menu-trigger">
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
          <span>${user ? user.name.split(' ')[0] : 'Account'}</span>
        </div>
        <div class="user-dropdown">
          ${isAdmin ? `<a href="/admin.html" class="user-dropdown-item"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="18" height="18" x="3" y="3" rx="2"/><path d="M9 3v18"/><path d="M15 3v18"/><path d="M3 9h18"/><path d="M3 15h18"/></svg>Admin Panel</a>` : ''}
          <a href="/orders.html" class="user-dropdown-item"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="16" height="20" x="4" y="2" rx="2"/><line x1="8" x2="16" y1="6" y2="6"/><line x1="8" x2="16" y1="10" y2="10"/><line x1="8" x2="16" y1="14" y2="14"/></svg>My Orders</a>
          <div class="user-dropdown-divider"></div>
          <div class="user-dropdown-item" id="logout-btn"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" x2="9" y1="12" y2="12"/></svg>Logout</div>
        </div>
      </div>
    `;
  } else {
    userMenuHTML = `
      <a href="/login.html" class="btn btn-secondary btn-sm" style="padding: 8px 16px;">Login</a>
      <a href="/register.html" class="btn btn-primary btn-sm" style="padding: 8px 16px;">Sign Up</a>
    `;
  }

  const currentTheme = localStorage.getItem('theme') || 'light';
  const themeIcon = currentTheme === 'dark' 
    ? `<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="4"/><path d="M12 2v2"/><path d="M12 20v2"/><path d="M4.93 4.93l1.41 1.41"/><path d="M17.66 17.66l1.41 1.41"/><path d="M2 12h2"/><path d="M20 12h2"/><path d="M6.34 17.66l-1.41 1.41"/><path d="M19.07 4.93l-1.41 1.41"/></svg>`
    : `<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"/></svg>`;

  headerEl.innerHTML = `
    <div class="container navbar">
      <a href="/index.html" class="logo">
        <svg width="24" height="24" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5" fill="none">
          <circle cx="9" cy="21" r="1"></circle>
          <circle cx="20" cy="21" r="1"></circle>
          <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path>
        </svg>
        <span>INDUS</span>
      </a>
      
      <nav class="nav-links" id="nav-links">
        <a href="/index.html" class="nav-link ${currentPath.endsWith('index.html') || currentPath === '/' ? 'active' : ''}">Home</a>
        <a href="/products.html" class="nav-link ${currentPath.endsWith('products.html') ? 'active' : ''}">Shop</a>
        ${isAdmin ? `<a href="/admin.html" class="nav-link ${currentPath.endsWith('admin.html') ? 'active' : ''}">Admin</a>` : ''}
      </nav>
      
      <div class="nav-actions">
        <button class="nav-btn theme-toggle-icon" id="theme-toggle">${themeIcon}</button>
        
        <a href="/cart.html" class="nav-btn">
          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="8" cy="21" r="1"/><circle cx="19" cy="21" r="1"/><path d="M2.05 2.05h2l2.66 12.42a2 2 0 0 0 2 1.58h9.78a2 2 0 0 0 1.95-1.57l1.65-7.43H5.12"/></svg>
          <span class="badge" id="cart-badge" style="display: none;">0</span>
        </a>

        ${userMenuHTML}

        <button class="nav-btn menu-toggle" id="menu-toggle">
          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="4" x2="20" y1="12" y2="12"/><line x1="4" x2="20" y1="6" y2="6"/><line x1="4" x2="20" y1="18" y2="18"/></svg>
        </button>
      </div>
    </div>
  `;

  // Bind Header Listeners
  document.getElementById('theme-toggle').addEventListener('click', toggleTheme);
  
  const mToggle = document.getElementById('menu-toggle');
  if (mToggle) {
    mToggle.addEventListener('click', () => {
      document.getElementById('nav-links').classList.toggle('mobile-active');
    });
  }

  const logoutBtn = document.getElementById('logout-btn');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', () => {
      API.logout();
      showToast('Logged out successfully', 'success');
      setTimeout(() => {
        window.location.href = '/index.html';
      }, 1000);
    });
  }
}

// Render Global Footer
function renderFooter() {
  const footerEl = document.getElementById('global-footer');
  if (!footerEl) return;

  footerEl.className = 'footer';
  footerEl.innerHTML = `
    <div class="container">
      <div class="footer-grid">
        <div class="footer-column">
          <a href="/index.html" class="logo" style="margin-bottom: 20px;">
            <svg width="24" height="24" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5" fill="none">
              <circle cx="9" cy="21" r="1"></circle>
              <circle cx="20" cy="21" r="1"></circle>
              <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path>
            </svg>
            <span>INDUS</span>
          </a>
          <p>Experience high-end consumer technology products with premium, state-of-the-art designs and uncompromised build quality.</p>
          <div class="social-links">
            <a href="#" class="social-icon"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/></svg></a>
            <a href="#" class="social-icon"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="20" height="20" x="2" y="2" rx="5" ry="5"/><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/><line x1="17.5" x2="17.51" y1="6.5" y2="6.5"/></svg></a>
            <a href="#" class="social-icon"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 4s-.7 2.1-2 3.4c1.6 10-9.4 17.3-18 11.6 2.2.1 4.4-.6 6-2C3 15.5.5 9.6 3 5c2.2 2.6 5.6 4.1 9 4-.9-4.2 4-6.6 7-3.8 1.1 0 3-1.2 3-1.2z"/></svg></a>
          </div>
        </div>
        
        <div class="footer-column">
          <h3>Shopping</h3>
          <div class="footer-links">
            <a href="/products.html">All Products</a>
            <a href="/products.html?category=Audio">Audio Gear</a>
            <a href="/products.html?category=Wearables">Smart Wearables</a>
            <a href="/products.html?category=Smart Home">Smart Home</a>
          </div>
        </div>

        <div class="footer-column">
          <h3>Support</h3>
          <div class="footer-links">
            <a href="#">Contact Us</a>
            <a href="#">FAQs</a>
            <a href="#">Shipping & Returns</a>
            <a href="#">Privacy Policy</a>
          </div>
        </div>

        <div class="footer-column">
          <h3>Newsletter</h3>
          <p>Subscribe to receive news, premium updates, and exclusive discount codes.</p>
          <div style="display: flex; gap: 8px;">
            <input type="email" placeholder="Your email address" class="form-control" style="padding: 10px 14px;">
            <button class="btn btn-primary" style="padding: 10px 18px;">
              <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="22" x2="11" y1="2" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
            </button>
          </div>
        </div>
      </div>
      
      <div class="footer-bottom">
        <p>&copy; 2026 Indus Premium Store. All rights reserved.</p>
        <p>Made with ❤️ by Zaid</p>
      </div>
    </div>
  `;
}

// Update Cart Badge Count
function updateCartBadge() {
  const badge = document.getElementById('cart-badge');
  if (!badge) return;

  let totalItems = 0;
  
  if (API.isLoggedIn()) {
    // If logged in, we sync DB cart count to local storage cart to ensure visual consistency
    const localCart = getLocalCart();
    totalItems = localCart.reduce((sum, item) => sum + item.quantity, 0);
  } else {
    // Guest cart count
    const localCart = getLocalCart();
    totalItems = localCart.reduce((sum, item) => sum + item.quantity, 0);
  }

  if (totalItems > 0) {
    badge.innerText = totalItems;
    badge.style.display = 'flex';
  } else {
    badge.style.display = 'none';
  }
}

// Get Cart from LocalStorage helper
function getLocalCart() {
  const cartStr = localStorage.getItem('cart');
  return cartStr ? JSON.parse(cartStr) : [];
}

// Save Cart to LocalStorage helper
function saveLocalCart(cart) {
  localStorage.setItem('cart', JSON.stringify(cart));
  updateCartBadge();
}

// Setup User Dropdown Menu Toggling
function setupDropdowns() {
  document.addEventListener('click', (e) => {
    const userMenu = document.getElementById('user-menu');
    if (!userMenu) return;

    const trigger = userMenu.querySelector('.user-menu-trigger');
    
    if (trigger.contains(e.target)) {
      userMenu.classList.toggle('active');
    } else if (!userMenu.contains(e.target)) {
      userMenu.classList.remove('active');
    }
  });
}

// Check for parameters or login success triggers
function checkSessionMessages() {
  const params = new URLSearchParams(window.location.search);
  if (params.get('expired') === 'true') {
    showToast('Your session has expired. Please log in again.', 'warning');
    // Remove query param without reload
    window.history.replaceState({}, document.title, window.location.pathname);
  }
}

// Dynamic Toast Notifications System
function showToast(message, type = 'success') {
  let container = document.querySelector('.toast-container');
  if (!container) {
    container = document.createElement('div');
    container.className = 'toast-container';
    document.body.appendChild(container);
  }

  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  
  let icon = '';
  if (type === 'success') {
    icon = `<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="var(--success)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>`;
  } else if (type === 'error') {
    icon = `<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="var(--danger)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="15" x2="9" y1="9" y2="15"/><line x1="9" x2="15" y1="9" y2="15"/></svg>`;
  } else {
    icon = `<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="var(--warning)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" x2="12" y1="8" y2="12"/><line x1="12" x2="12.01" y1="16" y2="16"/></svg>`;
  }

  toast.innerHTML = `
    ${icon}
    <div class="toast-message">${message}</div>
  `;

  container.appendChild(toast);
  
  // Trigger animation frame
  setTimeout(() => {
    toast.classList.add('active');
  }, 10);

  // Auto-remove after 4 seconds
  setTimeout(() => {
    toast.classList.remove('active');
    setTimeout(() => {
      toast.remove();
    }, 300);
  }, 4000);
}
