// Products Page Script
document.addEventListener('DOMContentLoaded', () => {
  initFiltersFromUrl();
  loadProducts();
  
  // Event Listeners
  document.getElementById('apply-filters-btn').addEventListener('click', loadProducts);
  document.getElementById('clear-filters-btn').addEventListener('click', clearFilters);
  document.getElementById('sort-select').addEventListener('change', loadProducts);
  
  // Real-time search (with Enter key)
  document.getElementById('search-input').addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
      loadProducts();
    }
  });
});

// Initialize UI filters based on URL Query parameters
function initFiltersFromUrl() {
  const params = new URLSearchParams(window.location.search);
  
  // Set Category
  const categoryParam = params.get('category');
  if (categoryParam) {
    const checkbox = document.querySelector(`input[name="category"][value="${categoryParam}"]`);
    if (checkbox) checkbox.checked = true;
  }

  // Set Search
  const searchParam = params.get('search');
  if (searchParam) {
    document.getElementById('search-input').value = searchParam;
  }
}

// Fetch products based on filters and render
async function loadProducts() {
  const loader = document.getElementById('products-loader');
  const grid = document.getElementById('products-grid');
  const countText = document.getElementById('products-count-text');

  if (!loader || !grid) return;

  loader.style.display = 'flex';
  grid.style.display = 'none';

  // Gather filter inputs
  const search = document.getElementById('search-input').value;
  const sort = document.getElementById('sort-select').value;
  const minPrice = document.getElementById('price-min').value;
  const maxPrice = document.getElementById('price-max').value;

  // Selected categories array
  const categories = [];
  document.querySelectorAll('input[name="category"]:checked').forEach(cb => {
    categories.push(cb.value);
  });

  const queryParams = {};
  if (search) queryParams.search = search;
  if (sort) queryParams.sort = sort;
  if (minPrice) queryParams.minPrice = minPrice;
  if (maxPrice) queryParams.maxPrice = maxPrice;
  
  // Since REST API filter handles one category at a time (or category string),
  // let's pass the first category if only one selected.
  // In a robust implementation, if multiple categories are selected, we load them sequentially or filter client-side.
  // For standard REST endpoint `/api/products?category=Audio`, let's pass categories[0] if exists.
  if (categories.length > 0) {
    queryParams.category = categories[0];
  }

  try {
    const data = await API.products.getAll(queryParams);
    let products = data.products;

    // Optional client-side filtering if user checked multiple categories
    if (categories.length > 1) {
      products = products.filter(p => categories.includes(p.category));
    }

    grid.innerHTML = '';

    if (products && products.length > 0) {
      products.forEach(product => {
        grid.appendChild(createProductCard(product));
      });
      
      countText.innerText = `Showing ${products.length} products`;
      loader.style.display = 'none';
      grid.style.display = 'grid';
    } else {
      countText.innerText = 'Showing 0 products';
      loader.style.display = 'none';
      grid.innerHTML = '<div style="grid-column: 1/-1; text-align: center; padding: 40px; color: var(--text-secondary);">No products match your filters.</div>';
      grid.style.display = 'block';
    }
  } catch (error) {
    console.error(error);
    loader.innerHTML = '<p style="color: var(--danger); text-align: center; width: 100%;">Failed to load products.</p>';
  }
}

// Clear all filter fields
function clearFilters() {
  document.getElementById('search-input').value = '';
  document.getElementById('price-min').value = '';
  document.getElementById('price-max').value = '';
  
  document.querySelectorAll('input[name="category"]').forEach(cb => {
    cb.checked = false;
  });

  loadProducts();
}

// Product Card Builder
function createProductCard(product) {
  const card = document.createElement('div');
  card.className = 'product-card';

  const hasDiscount = product.discount > 0;
  const finalPrice = hasDiscount 
    ? (product.price * (1 - product.discount / 100)).toFixed(2)
    : product.price.toFixed(2);

  const discountBadge = hasDiscount 
    ? `<div class="product-badge">-${product.discount}%</div>`
    : '';

  const ratingStars = '★'.repeat(Math.round(product.rating)) + '☆'.repeat(5 - Math.round(product.rating));
  const imageSrc = product.images[0] || 'https://images.unsplash.com/photo-1531403009284-440f080d1e12?w=800';

  const wishlist = JSON.parse(localStorage.getItem('wishlist') || '[]');
  const isWishlisted = wishlist.includes(product._id) ? 'active' : '';

  card.innerHTML = `
    ${discountBadge}
    <button class="product-wishlist-btn ${isWishlisted}" onclick="toggleWishlist('${product._id}', this)">
      <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></svg>
    </button>
    
    <div class="product-card-img-container">
      <img src="${imageSrc}" alt="${product.name}">
      <div class="product-card-actions">
        <a href="product.html?id=${product._id}" class="btn btn-secondary btn-sm">Quick View</a>
        <button class="btn btn-primary btn-sm" onclick="handleAddToCart('${product._id}')">Add to Cart</button>
      </div>
    </div>

    <div class="product-card-info">
      <span class="product-card-category">${product.category}</span>
      <a href="product.html?id=${product._id}"><h3 class="product-card-title">${product.name}</h3></a>
      
      <div class="product-card-rating">
        ${ratingStars}
        <span>(${product.numReviews || 0})</span>
      </div>

      <div class="product-card-price-container">
        <span class="product-card-price">₹${finalPrice}</span>
        ${hasDiscount ? `<span class="product-card-original-price">₹${product.price.toFixed(2)}</span>` : ''}
      </div>
    </div>
  `;

  return card;
}

// Add to Cart Action
async function handleAddToCart(productId) {
  try {
    const isLoggedIn = API.isLoggedIn();
    
    if (isLoggedIn) {
      await API.cart.add(productId, 1);
    }
    
    let localCart = getLocalCart();
    const itemIndex = localCart.findIndex(item => item.product === productId);
    
    if (itemIndex > -1) {
      localCart[itemIndex].quantity += 1;
    } else {
      localCart.push({ product: productId, quantity: 1 });
    }
    
    saveLocalCart(localCart);
    showToast('Product added to cart', 'success');
  } catch (error) {
    showToast(error.message || 'Could not add to cart', 'error');
  }
}

// Toggle Wishlist Action
function toggleWishlist(productId, btn) {
  btn.classList.toggle('active');
  const isWishlisted = btn.classList.contains('active');
  
  let wishlist = JSON.parse(localStorage.getItem('wishlist') || '[]');
  
  if (isWishlisted) {
    if (!wishlist.includes(productId)) wishlist.push(productId);
    showToast('Added to wishlist', 'success');
  } else {
    wishlist = wishlist.filter(id => id !== productId);
    showToast('Removed from wishlist', 'warning');
  }
  
  localStorage.setItem('wishlist', JSON.stringify(wishlist));
}
