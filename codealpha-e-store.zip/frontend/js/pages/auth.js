// Authentication Pages (Login/Register) Script
document.addEventListener('DOMContentLoaded', () => {
  const loginForm = document.getElementById('login-form');
  const registerForm = document.getElementById('register-form');
  const googleLoginBtn = document.getElementById('google-login-btn');

  // Inject Google OAuth Modal CSS Styles
  injectGoogleOAuthStyles();

  if (loginForm) {
    loginForm.addEventListener('submit', handleLogin);
  }

  if (registerForm) {
    registerForm.addEventListener('submit', handleRegister);
  }

  if (googleLoginBtn) {
    googleLoginBtn.addEventListener('click', handleGoogleLoginClick);
  }
});

// Submit Login Form
async function handleLogin(e) {
  e.preventDefault();

  const emailOrPhone = document.getElementById('login-email').value.trim();
  const password = document.getElementById('login-password').value;
  const loginBtn = document.getElementById('login-btn');

  if (!emailOrPhone || !password) {
    showToast('Please fill out all fields', 'warning');
    return;
  }

  try {
    loginBtn.disabled = true;
    loginBtn.innerHTML = '<div class="spinner" style="margin: 0 auto;"></div>';

    const res = await API.auth.login(emailOrPhone, password);
    showToast(`Welcome back, ${res.name}!`, 'success');

    // Sync LocalStorage cart items to Database cart
    await syncGuestCartWithDB();

    // Redirect
    handleRedirect();
  } catch (error) {
    showToast(error.message || 'Login failed. Check email/phone or password.', 'error');
  } finally {
    loginBtn.disabled = false;
    loginBtn.innerText = 'Log In';
  }
}

// Submit Registration Form
async function handleRegister(e) {
  e.preventDefault();

  const name = document.getElementById('reg-name').value.trim();
  const email = document.getElementById('reg-email').value.trim();
  const phone = document.getElementById('reg-phone').value.trim();
  const password = document.getElementById('reg-password').value;
  const confirmPassword = document.getElementById('reg-confirm-password').value;
  const registerBtn = document.getElementById('register-btn');

  if (!name || !email || !password || !confirmPassword) {
    showToast('Please fill out all required fields', 'warning');
    return;
  }

  if (password.length < 6) {
    showToast('Password must be at least 6 characters long', 'warning');
    return;
  }

  if (password !== confirmPassword) {
    showToast('Passwords do not match', 'error');
    return;
  }

  try {
    registerBtn.disabled = true;
    registerBtn.innerHTML = '<div class="spinner" style="margin: 0 auto;"></div>';

    const res = await API.auth.register(name, email, phone, password);
    showToast(`Account created! Welcome, ${res.name}`, 'success');

    // Sync guest cart
    await syncGuestCartWithDB();

    // Redirect
    handleRedirect();
  } catch (error) {
    showToast(error.message || 'Registration failed.', 'error');
  } finally {
    registerBtn.disabled = false;
    registerBtn.innerText = 'Create Account';
  }
}

// Google Login Click Handler
function handleGoogleLoginClick() {
  showGoogleOAuthModal();
}

// Show Google OAuth Account Selection Modal
function showGoogleOAuthModal() {
  // Remove existing modal if any
  const oldModal = document.getElementById('google-oauth-modal');
  if (oldModal) oldModal.remove();

  const modal = document.createElement('div');
  modal.id = 'google-oauth-modal';
  modal.className = 'google-oauth-overlay';

  // Mock Google Accounts on Device list
  const mockGoogleAccounts = [
    { name: 'Zaid Tech', email: 'zaid.tech@gmail.com', color: '#EA4335' },
    { name: 'John Doe', email: 'john.doe@gmail.com', color: '#4285F4' },
    { name: 'Indus Developer', email: 'developer.indus@gmail.com', color: '#34A853' }
  ];

  let accountListHtml = '';
  mockGoogleAccounts.forEach(acc => {
    const initial = acc.name.charAt(0);
    accountListHtml += `
      <div class="google-account-item" onclick="loginWithSelectedGoogleAccount('${acc.name}', '${acc.email}')">
        <div class="google-account-avatar" style="background-color: ${acc.color};">
          ${initial}
        </div>
        <div class="google-account-info">
          <div class="google-account-name">${acc.name}</div>
          <div class="google-account-email">${acc.email}</div>
        </div>
      </div>
    `;
  });

  modal.innerHTML = `
    <div class="google-oauth-card">
      <div class="google-oauth-logo">
        <svg width="32" height="32" viewBox="0 0 24 24">
          <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
          <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
          <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"/>
          <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
        </svg>
      </div>
      <h3 class="google-oauth-title">Choose an account</h3>
      <p class="google-oauth-subtitle">to continue to Indus Premium Store</p>
      
      <!-- Account Selection View -->
      <div id="google-accounts-view">
        <div class="google-account-list">
          ${accountListHtml}
        </div>
        
        <button class="google-oauth-footer-btn" onclick="toggleManualGoogleInput(true)">
          Use another account
        </button>
      </div>

      <!-- Manual Input View (Hidden Initially) -->
      <div id="google-manual-view" style="display: none; text-align: left;">
        <div class="form-group" style="margin-bottom: 16px;">
          <label class="form-label" style="font-size: 0.8rem;">Enter Google Email</label>
          <input type="email" id="google-manual-email" class="form-control" placeholder="username@gmail.com" style="padding: 10px 14px;">
        </div>
        
        <div style="display: flex; justify-content: space-between; align-items: center;">
          <button class="google-oauth-footer-btn" onclick="toggleManualGoogleInput(false)" style="padding-left: 0;">
            Back to accounts
          </button>
          
          <button class="btn btn-primary btn-sm" onclick="loginWithManualGoogleAccount()">
            Continue
          </button>
        </div>
      </div>

      <!-- Close Button -->
      <button class="google-oauth-close-btn" onclick="closeGoogleOAuthModal()" aria-label="Close modal">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <line x1="18" y1="6" x2="6" y2="18"></line>
          <line x1="6" y1="6" x2="18" y2="18"></line>
        </svg>
      </button>
    </div>
  `;

  document.body.appendChild(modal);

  // Trigger smooth fade-in
  setTimeout(() => {
    modal.classList.add('active');
  }, 10);

  // Close when clicking outside of cards
  modal.addEventListener('click', (e) => {
    if (e.target === modal) {
      closeGoogleOAuthModal();
    }
  });
}

// Close OAuth Modal Helper
window.closeGoogleOAuthModal = function() {
  const modal = document.getElementById('google-oauth-modal');
  if (modal) {
    modal.classList.remove('active');
    setTimeout(() => {
      modal.remove();
    }, 300);
  }
}

// Switch between list of accounts and custom email typing
window.toggleManualGoogleInput = function(showManual) {
  const accountsView = document.getElementById('google-accounts-view');
  const manualView = document.getElementById('google-manual-view');
  
  if (showManual) {
    accountsView.style.display = 'none';
    manualView.style.display = 'block';
    document.getElementById('google-manual-email').focus();
  } else {
    accountsView.style.display = 'block';
    manualView.style.display = 'none';
  }
}

// Handler for clicked google profile
window.loginWithSelectedGoogleAccount = async function(name, email) {
  closeGoogleOAuthModal();
  
  const googleLoginBtn = document.getElementById('google-login-btn');
  const originalText = googleLoginBtn.innerText;

  try {
    googleLoginBtn.disabled = true;
    googleLoginBtn.innerHTML = '<div class="spinner" style="margin: 0 auto;"></div>';

    const res = await API.auth.googleLogin(name, email);
    showToast(`Successfully signed in via Google as ${res.name}`, 'success');

    // Sync guest cart
    await syncGuestCartWithDB();

    // Redirect
    handleRedirect();
  } catch (error) {
    showToast(error.message || 'Google authentication failed.', 'error');
    googleLoginBtn.disabled = false;
    googleLoginBtn.innerText = originalText;
  }
}

// Handler for manual custom email submission
window.loginWithManualGoogleAccount = async function() {
  const emailInput = document.getElementById('google-manual-email');
  const email = emailInput.value.trim();

  if (!email) {
    showToast('Please enter an email address', 'warning');
    return;
  }

  if (!/^\S+@\S+\.\S+$/.test(email)) {
    showToast('Please enter a valid email address', 'warning');
    return;
  }

  // Derive name
  const emailPrefix = email.split('@')[0];
  const derivedName = emailPrefix
    .split(/[\._-]/)
    .map(word => word.charAt(0).toUpperCase() + word.slice(1))
    .join(' ') || 'Google User';

  loginWithSelectedGoogleAccount(derivedName, email);
}

// Sync guest localstorage items to user cart in DB
async function syncGuestCartWithDB() {
  const localCart = getLocalCart();
  if (localCart && localCart.length > 0) {
    try {
      // Map local storage items to server expected format
      const formattedItems = localCart.map(item => ({
        product: item.product,
        quantity: item.quantity
      }));
      
      const res = await API.cart.sync(formattedItems);
      
      // Update local storage with the complete synchronized cart returned from DB
      const syncedItems = res.cart.products.map(item => ({
        product: item.product._id,
        quantity: item.quantity
      }));
      
      saveLocalCart(syncedItems);
    } catch (error) {
      console.error('Failed to sync guest cart with database:', error);
    }
  } else {
    // If local cart is empty, pull current database cart to local storage to align badge counts
    try {
      const res = await API.cart.get();
      if (res.cart && res.cart.products.length > 0) {
        const syncedItems = res.cart.products.map(item => ({
          product: item.product._id,
          quantity: item.quantity
        }));
        saveLocalCart(syncedItems);
      }
    } catch (error) {
      console.error('Failed to retrieve user cart on login:', error);
    }
  }
}

// Redirect Helper
function handleRedirect() {
  const params = new URLSearchParams(window.location.search);
  const redirect = params.get('redirect');

  setTimeout(() => {
    if (redirect) {
      window.location.href = redirect;
    } else {
      // If user is admin, go to admin panel, else go home
      const user = API.getUser();
      if (user && user.role === 'admin') {
        window.location.href = 'admin.html';
      } else {
        window.location.href = 'index.html';
      }
    }
  }, 1000);
}

// CSS style injector helper
function injectGoogleOAuthStyles() {
  const styleId = 'google-oauth-modal-styles';
  if (document.getElementById(styleId)) return;

  const style = document.createElement('style');
  style.id = styleId;
  style.textContent = `
    .google-oauth-overlay {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0, 0, 0, 0.6);
      backdrop-filter: blur(8px);
      display: flex;
      justify-content: center;
      align-items: center;
      z-index: 10000;
      opacity: 0;
      transition: opacity 0.25s ease;
    }
    .google-oauth-overlay.active {
      opacity: 1;
    }
    .google-oauth-card {
      position: relative;
      background: var(--bg-card);
      border: 1px solid var(--border);
      border-radius: 16px;
      width: 100%;
      max-width: 380px;
      padding: 32px 24px;
      box-shadow: 0 20px 40px rgba(0, 0, 0, 0.4);
      text-align: center;
      transform: scale(0.9);
      transition: transform 0.25s ease;
    }
    .google-oauth-overlay.active .google-oauth-card {
      transform: scale(1);
    }
    .google-oauth-logo {
      margin-bottom: 16px;
      display: flex;
      justify-content: center;
    }
    .google-oauth-title {
      font-size: 1.3rem;
      font-weight: 600;
      color: var(--text-primary);
      margin-bottom: 6px;
    }
    .google-oauth-subtitle {
      font-size: 0.9rem;
      color: var(--text-secondary);
      margin-bottom: 24px;
    }
    .google-account-list {
      display: flex;
      flex-direction: column;
      gap: 12px;
      margin-bottom: 20px;
      text-align: left;
      max-height: 240px;
      overflow-y: auto;
    }
    .google-account-item {
      display: flex;
      align-items: center;
      gap: 14px;
      padding: 12px;
      border: 1px solid var(--border);
      border-radius: 10px;
      cursor: pointer;
      background: transparent;
      transition: background 0.2s, border-color 0.2s;
    }
    .google-account-item:hover {
      background: rgba(255, 255, 255, 0.05);
      border-color: var(--primary);
    }
    .google-account-avatar {
      width: 36px;
      height: 36px;
      border-radius: 50%;
      color: white;
      display: flex;
      align-items: center;
      justify-content: center;
      font-weight: 600;
      font-size: 1rem;
    }
    .google-account-info {
      flex: 1;
      min-width: 0;
    }
    .google-account-name {
      font-size: 0.95rem;
      font-weight: 600;
      color: var(--text-primary);
      text-overflow: ellipsis;
      overflow: hidden;
      white-space: nowrap;
    }
    .google-account-email {
      font-size: 0.8rem;
      color: var(--text-secondary);
      text-overflow: ellipsis;
      overflow: hidden;
      white-space: nowrap;
    }
    .google-oauth-footer-btn {
      font-size: 0.9rem;
      color: var(--primary);
      background: none;
      border: none;
      cursor: pointer;
      font-weight: 500;
      padding: 8px;
      transition: opacity 0.2s;
    }
    .google-oauth-footer-btn:hover {
      opacity: 0.8;
      text-decoration: underline;
    }
    .google-oauth-close-btn {
      position: absolute;
      top: 16px;
      right: 16px;
      background: none;
      border: none;
      color: var(--text-secondary);
      cursor: pointer;
      padding: 4px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: background 0.2s, color 0.2s;
    }
    .google-oauth-close-btn:hover {
      background: rgba(255, 255, 255, 0.08);
      color: var(--text-primary);
    }
  `;
  document.head.appendChild(style);
}
