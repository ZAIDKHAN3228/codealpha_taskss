// Home Page Script
document.addEventListener('DOMContentLoaded', () => {
  loadFeaturedProducts();
});

async function loadFeaturedProducts() {
  const loader = document.getElementById('featured-loader');
  const grid = document.getElementById('featured-products-grid');
  
  if (!loader || !grid) return;

  try {
    const data = await API.products.getAll({ limit: 4 });
    const products = data.products;

    if (products && products.length > 0) {
      grid.innerHTML = '';
      
      products.forEach(product => {
        grid.appendChild(createProductCard(product));
      });

      // Update keyboard promotional link if keyboard is loaded
      const keyboard = products.find(p => p.name.toLowerCase().includes('keyboard'));
      const promoBtn = document.getElementById('promo-buy-btn');
      if (keyboard && promoBtn) {
        promoBtn.href = `product.html?id=${keyboard._id}`;
      }

      loader.style.display = 'none';
      grid.style.display = 'grid';
    } else {
      loader.innerHTML = '<p class="section-subtitle">No featured products found.</p>';
    }
  } catch (error) {
    console.error(error);
    loader.innerHTML = '<p class="section-subtitle" style="color: var(--danger);">Failed to load products. Make sure the server and MongoDB are running.</p>';
  }
}

// Global Product Card Creation Helper
function createProductCard(product) {
  const card = document.createElement('div');
  card.className = 'product-card';

  const hasDiscount = product.discount > 0;
  const finalPrice = hasDiscount 
    ? (product.price * (1 - product.discount / 100)).toFixed(2)
    : product.price.toFixed(2);

  const discountBadge = hasDiscount 
    ? `<div class="product-badge">-${product.discount}%</div>`
    : '';

  const ratingStars = '★'.repeat(Math.round(product.rating)) + '☆'.repeat(5 - Math.round(product.rating));

  const imageSrc = product.images[0] || 'https://images.unsplash.com/photo-1531403009284-440f080d1e12?w=800';

  card.innerHTML = `
    ${discountBadge}
    <button class="product-wishlist-btn" onclick="toggleWishlist('${product._id}', this)">
      <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></svg>
    </button>
    
    <div class="product-card-img-container">
      <img src="${imageSrc}" alt="${product.name}">
      <div class="product-card-actions">
        <a href="product.html?id=${product._id}" class="btn btn-secondary btn-sm">Quick View</a>
        <button class="btn btn-primary btn-sm" onclick="handleAddToCart('${product._id}')">Add to Cart</button>
      </div>
    </div>

    <div class="product-card-info">
      <span class="product-card-category">${product.category}</span>
      <a href="product.html?id=${product._id}"><h3 class="product-card-title">${product.name}</h3></a>
      
      <div class="product-card-rating">
        ${ratingStars}
        <span>(${product.numReviews || 0})</span>
      </div>

      <div class="product-card-price-container">
        <span class="product-card-price">₹${finalPrice}</span>
        ${hasDiscount ? `<span class="product-card-original-price">₹${product.price.toFixed(2)}</span>` : ''}
      </div>
    </div>
  `;

  return card;
}

// Add to Cart handler (synchronous redirect and storage handling)
async function handleAddToCart(productId) {
  try {
    const isLoggedIn = API.isLoggedIn();
    
    if (isLoggedIn) {
      // API call to sync cart
      await API.cart.add(productId, 1);
    }
    
    // Always sync with LocalStorage
    let localCart = getLocalCart();
    const itemIndex = localCart.findIndex(item => item.product === productId);
    
    if (itemIndex > -1) {
      localCart[itemIndex].quantity += 1;
    } else {
      localCart.push({ product: productId, quantity: 1 });
    }
    
    saveLocalCart(localCart);
    showToast('Product added to cart', 'success');
  } catch (error) {
    showToast(error.message || 'Could not add to cart', 'error');
  }
}

// Wishlist handling simulation
function toggleWishlist(productId, btn) {
  btn.classList.toggle('active');
  const isWishlisted = btn.classList.contains('active');
  
  let wishlist = JSON.parse(localStorage.getItem('wishlist') || '[]');
  
  if (isWishlisted) {
    if (!wishlist.includes(productId)) wishlist.push(productId);
    showToast('Added to wishlist', 'success');
  } else {
    wishlist = wishlist.filter(id => id !== productId);
    showToast('Removed from wishlist', 'warning');
  }
  
  localStorage.setItem('wishlist', JSON.stringify(wishlist));
}
