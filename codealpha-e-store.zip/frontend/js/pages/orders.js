// Customer Dashboard Script
document.addEventListener('DOMContentLoaded', () => {
  if (!API.isLoggedIn()) {
    window.location.href = 'login.html?redirect=orders.html';
    return;
  }

  setupTabs();
  loadOrders();
  loadUserProfile();

  document.getElementById('profile-form').addEventListener('submit', handleUpdateProfile);
});

// Setup tab switches
function setupTabs() {
  const tabs = document.querySelectorAll('.dashboard-sidebar-item');
  const panes = document.querySelectorAll('.tab-pane');

  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      tabs.forEach(t => t.classList.remove('active'));
      panes.forEach(p => p.style.display = 'none');

      tab.classList.add('active');
      const targetPane = document.getElementById(`tab-${tab.getAttribute('data-tab')}`);
      if (targetPane) targetPane.style.display = 'block';
    });
  });
}

// Fetch user profile and prefill fields
async function loadUserProfile() {
  try {
    const res = await API.auth.getMe();
    if (res.success) {
      document.getElementById('prof-name').value = res.name;
      document.getElementById('prof-email').value = res.email;
    }
  } catch (error) {
    console.error('Failed to load profile:', error);
  }
}

// Fetch user orders list and render
async function loadOrders() {
  const loader = document.getElementById('dashboard-loader');
  const main = document.getElementById('dashboard-main');
  const container = document.getElementById('orders-list-container');

  try {
    const data = await API.orders.getMyOrders();
    const orders = data.orders;

    container.innerHTML = '';

    if (orders && orders.length > 0) {
      orders.forEach(order => {
        container.appendChild(createOrderCard(order));
      });
    } else {
      container.innerHTML = `
        <div style="text-align: center; padding: 40px; border: 1px dashed var(--border); border-radius: var(--radius-lg);">
          <p style="color: var(--text-secondary); margin-bottom: 16px;">You haven't placed any orders yet.</p>
          <a href="products.html" class="btn btn-secondary btn-sm">Shop Collection</a>
        </div>
      `;
    }

    loader.style.display = 'none';
    main.style.display = 'grid';
  } catch (error) {
    console.error(error);
    loader.innerHTML = '<p class="section-subtitle" style="color: var(--danger);">Failed to load order history.</p>';
  }
}

// Create Order Card dynamically
function createOrderCard(order) {
  const card = document.createElement('div');
  card.className = 'order-card';

  const dateStr = new Date(order.orderDate).toLocaleDateString(undefined, {
    year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit'
  });

  const statusClass = `status-${order.orderStatus.toLowerCase()}`;

  let itemsHtml = '';
  order.products.forEach(item => {
    const imageSrc = item.image || 'https://images.unsplash.com/photo-1531403009284-440f080d1e12?w=800';
    itemsHtml += `
      <div class="order-item-row">
        <div class="order-item-img">
          <img src="${imageSrc}" alt="${item.name}">
        </div>
        <div class="order-item-info">
          <p class="order-item-name">${item.name}</p>
          <span class="order-item-qty">Quantity: ${item.quantity} | Price: ₹${item.price.toFixed(2)}</span>
        </div>
        <div style="font-weight: 600;">₹${(item.price * item.quantity).toFixed(2)}</div>
      </div>
    `;
  });

  card.innerHTML = `
    <div class="order-card-header">
      <div class="order-header-cell">
        <span>Order Placed</span>
        <p>${dateStr}</p>
      </div>
      <div class="order-header-cell">
        <span>Order ID</span>
        <p style="font-family: monospace; font-size: 0.8rem;">${order._id}</p>
      </div>
      <div class="order-header-cell">
        <span>Total Amount</span>
        <p style="color: var(--primary); font-weight: 700;">₹${order.totalAmount.toFixed(2)}</p>
      </div>
      <div class="order-header-cell" style="text-align: right;">
        <span>Status</span>
        <span class="order-status-badge ${statusClass}">${order.orderStatus}</span>
      </div>
    </div>
    
    <div class="order-card-body">
      <div style="margin-bottom: 20px; border-bottom: 1px solid var(--border); padding-bottom: 16px;">
        <h4 style="font-size: 0.95rem; margin-bottom: 8px; color: var(--text-secondary);">Shipping Details</h4>
        <p style="font-size: 0.9rem;"><strong>Name:</strong> ${order.shippingAddress.fullName} | <strong>Phone:</strong> ${order.shippingAddress.phone}</p>
        <p style="font-size: 0.9rem;"><strong>Address:</strong> ${order.shippingAddress.address}, ${order.shippingAddress.city}, ${order.shippingAddress.state} ${order.shippingAddress.zipCode}</p>
      </div>

      <div>
        <h4 style="font-size: 0.95rem; margin-bottom: 12px; color: var(--text-secondary);">Items Ordered</h4>
        ${itemsHtml}
      </div>
    </div>
  `;

  return card;
}

// Handle Update Profile settings
async function handleUpdateProfile(e) {
  e.preventDefault();

  const name = document.getElementById('prof-name').value.trim();
  const email = document.getElementById('prof-email').value.trim();
  const password = document.getElementById('prof-password').value;
  const updateBtn = document.getElementById('update-profile-btn');

  if (!name || !email) {
    showToast('Name and Email cannot be empty', 'warning');
    return;
  }

  try {
    updateBtn.disabled = true;
    updateBtn.innerHTML = '<div class="spinner" style="margin: 0 auto;"></div>';

    const payload = { name, email };
    if (password) payload.password = password;

    const res = await API.auth.updateProfile(payload);
    showToast('Profile updated successfully!', 'success');
    
    // Clear password input
    document.getElementById('prof-password').value = '';
    
    // Re-load navbar content dynamically (updates the user name)
    renderHeader();
  } catch (error) {
    showToast(error.message || 'Failed to update profile info.', 'error');
  } finally {
    updateBtn.disabled = false;
    updateBtn.innerText = 'Update Profile';
  }
}
