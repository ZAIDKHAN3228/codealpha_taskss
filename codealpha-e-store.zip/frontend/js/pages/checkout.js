// Checkout Page Script
let orderProducts = [];
let paymentMethod = 'Credit Card';
let subtotal = 0;
let tax = 0;
let shipping = 0;
let totalAmount = 0;

document.addEventListener('DOMContentLoaded', () => {
  if (!API.isLoggedIn()) {
    document.getElementById('checkout-login-prompt').style.display = 'block';
    return;
  }

  document.getElementById('checkout-main-layout').style.display = 'grid';
  loadCheckoutSummary();
  prefillUserInfo();
  setupPaymentMethods();
  
  document.getElementById('place-order-btn').addEventListener('click', handlePlaceOrder);
});

// Load summary details from DB cart
async function loadCheckoutSummary() {
  const summaryList = document.getElementById('checkout-items-list');
  const btn = document.getElementById('place-order-btn');

  try {
    const data = await API.cart.get();
    const cart = data.cart;

    if (!cart || cart.products.length === 0) {
      summaryList.innerHTML = '<p style="color: var(--text-secondary);">Your cart is empty. Cannot checkout.</p>';
      btn.disabled = true;
      return;
    }

    summaryList.innerHTML = '';
    orderProducts = [];
    subtotal = 0;

    cart.products.forEach(item => {
      const product = item.product;
      const price = product.price * (1 - (product.discount || 0) / 100);
      const itemSubtotal = price * item.quantity;
      subtotal += itemSubtotal;

      // Add to ordering array
      orderProducts.push({
        product: product._id,
        name: product.name,
        price: Number(price.toFixed(2)),
        quantity: item.quantity
      });

      // Render mini row
      const row = document.createElement('div');
      row.style.display = 'flex';
      row.style.justify = 'space-between';
      row.style.fontSize = '0.9rem';
      row.style.marginBottom = '12px';
      row.innerHTML = `
        <span style="color: var(--text-secondary); max-width: 200px; text-overflow: ellipsis; overflow: hidden; white-space: nowrap;">
          ${product.name} <strong style="color: var(--text-primary);">x ${item.quantity}</strong>
        </span>
        <span style="font-weight: 600;">₹${itemSubtotal.toFixed(2)}</span>
      `;
      summaryList.appendChild(row);
    });

    // Calculations
    tax = subtotal * 0.08;
    shipping = subtotal >= 15000 ? 0 : 999;
    totalAmount = subtotal + tax + shipping;

    // Render totals
    document.getElementById('chk-subtotal').innerText = `₹${subtotal.toFixed(2)}`;
    document.getElementById('chk-tax').innerText = `₹${tax.toFixed(2)}`;
    document.getElementById('chk-shipping').innerText = shipping === 0 ? 'FREE' : `₹${shipping.toFixed(2)}`;
    document.getElementById('chk-grand-total').innerText = `₹${totalAmount.toFixed(2)}`;
    btn.innerText = `Place Order (₹${totalAmount.toFixed(2)})`;
    btn.disabled = false;
  } catch (error) {
    console.error(error);
    showToast('Failed to load checkout details.', 'error');
  }
}

// Pre-fill fields using user profile information
async function prefillUserInfo() {
  try {
    const user = API.getUser();
    if (user) {
      document.getElementById('ship-name').value = user.name || '';
      document.getElementById('ship-email').value = user.email || '';
    }
  } catch (error) {
    console.error(error);
  }
}

// Payment method card toggles
function setupPaymentMethods() {
  const options = document.querySelectorAll('.payment-method-option');
  options.forEach(option => {
    option.addEventListener('click', () => {
      // Clear selections
      options.forEach(opt => {
        opt.classList.remove('selected');
        opt.querySelector('svg').setAttribute('stroke', 'var(--text-secondary)');
      });

      // Select clicked
      option.classList.add('selected');
      option.querySelector('svg').setAttribute('stroke', 'var(--primary)');
      paymentMethod = option.getAttribute('data-value');
    });
  });
}

// Place Order Action Handler
async function handlePlaceOrder(e) {
  e.preventDefault();

  const fullName = document.getElementById('ship-name').value.trim();
  const email = document.getElementById('ship-email').value.trim();
  const phone = document.getElementById('ship-phone').value.trim();
  const address = document.getElementById('ship-address').value.trim();
  const city = document.getElementById('ship-city').value.trim();
  const state = document.getElementById('ship-state').value.trim();
  const zipCode = document.getElementById('ship-zip').value.trim();

  // Validate fields
  if (!fullName || !email || !phone || !address || !city || !state || !zipCode) {
    showToast('Please fill out all address details fields.', 'warning');
    return;
  }

  const shippingAddress = { fullName, email, phone, address, city, state, zipCode };
  const placeBtn = document.getElementById('place-order-btn');

  try {
    placeBtn.disabled = true;
    placeBtn.innerHTML = '<div class="spinner" style="margin: 0 auto;"></div>';

    const orderData = {
      products: orderProducts,
      shippingAddress,
      paymentMethod
    };

    const res = await API.orders.create(orderData);

    if (res.success) {
      // Clear LocalStorage cart and update UI header badge count
      localStorage.removeItem('cart');
      updateCartBadge();

      // Update success modal details
      document.getElementById('success-order-id').innerText = res.order._id;
      document.getElementById('success-order-total').innerText = `₹${res.order.totalAmount.toFixed(2)}`;

      // Show success modal popup
      document.getElementById('success-modal').classList.add('active');
      showToast('Order placed successfully!', 'success');
    }
  } catch (error) {
    showToast(error.message || 'Failed to place order. Check product stock levels.', 'error');
  } finally {
    placeBtn.disabled = false;
    placeBtn.innerText = `Place Order (₹${totalAmount.toFixed(2)})`;
  }
}
