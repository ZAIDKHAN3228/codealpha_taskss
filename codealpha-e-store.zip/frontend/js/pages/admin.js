// Admin Dashboard Script
let allProducts = [];
let specRowIndex = 0;

document.addEventListener('DOMContentLoaded', () => {
  // Access control
  if (!API.isLoggedIn() || !API.isAdmin()) {
    showToast('Unauthorized access. Admin privileges required.', 'error');
    setTimeout(() => {
      window.location.href = 'index.html';
    }, 1500);
    return;
  }

  document.getElementById('admin-dashboard-container').style.display = 'block';
  document.getElementById('admin-loader').style.display = 'none';

  setupTabs();
  loadDashboardData();

  // Product Modal Triggers
  document.getElementById('add-product-btn').addEventListener('click', () => openProductModal());
  document.getElementById('product-modal-close-btn').addEventListener('click', closeProductModal);
  document.getElementById('add-spec-row-btn').addEventListener('click', () => addSpecInputRow('', ''));
  document.getElementById('product-form').addEventListener('submit', handleSaveProduct);
});

// Setup sidebar tab switching
function setupTabs() {
  const tabs = document.querySelectorAll('.dashboard-sidebar-item');
  const panes = document.querySelectorAll('.tab-pane');

  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      tabs.forEach(t => t.classList.remove('active'));
      panes.forEach(p => p.style.display = 'none');

      tab.classList.add('active');
      const targetPane = document.getElementById(`tab-${tab.getAttribute('data-tab')}`);
      if (targetPane) targetPane.style.display = 'block';

      // Refresh data depending on active tab
      const tabName = tab.getAttribute('data-tab');
      if (tabName === 'products') loadProductsTable();
      if (tabName === 'orders') loadOrdersTable();
      if (tabName === 'users') loadUsersTable();
    });
  });
}

// Load statistics and default tab
async function loadDashboardData() {
  try {
    const data = await API.orders.getStats();
    if (data.success) {
      document.getElementById('stat-orders-count').innerText = data.stats.ordersCount;
      document.getElementById('stat-products-count').innerText = data.stats.productsCount;
      document.getElementById('stat-total-sales').innerText = `₹${data.stats.totalSales.toFixed(2)}`;
    }

    // Default load products table
    loadProductsTable();
  } catch (error) {
    console.error('Failed to load dashboard metrics stats:', error);
  }
}

// Load products directory table
async function loadProductsTable() {
  const tbody = document.getElementById('admin-products-table-body');
  tbody.innerHTML = '<tr><td colspan="6" style="text-align: center;"><div class="spinner" style="margin: 20px auto;"></div></td></tr>';

  try {
    const data = await API.products.getAll();
    allProducts = data.products;

    tbody.innerHTML = '';
    if (allProducts && allProducts.length > 0) {
      allProducts.forEach(prod => {
        const tr = document.createElement('tr');
        const imgUrl = prod.images[0] || 'https://images.unsplash.com/photo-1531403009284-440f080d1e12?w=800';
        
        tr.innerHTML = `
          <td><img src="${imgUrl}" class="admin-table-img" alt="${prod.name}"></td>
          <td style="font-weight: 600;">${prod.name}</td>
          <td>${prod.category}</td>
          <td style="font-weight: 600; color: var(--primary);">₹${prod.price.toFixed(2)}</td>
          <td>${prod.stock}</td>
          <td>
            <div class="admin-table-actions">
              <button class="btn btn-secondary btn-sm" onclick="editProduct('${prod._id}')">Edit</button>
              <button class="btn btn-primary btn-sm" style="background-color: var(--danger);" onclick="deleteProduct('${prod._id}')">Delete</button>
            </div>
          </td>
        `;
        tbody.appendChild(tr);
      });
    } else {
      tbody.innerHTML = '<tr><td colspan="6" style="text-align: center;">No products listed yet.</td></tr>';
    }
  } catch (error) {
    console.error(error);
    tbody.innerHTML = '<tr><td colspan="6" style="text-align: center; color: var(--danger);">Failed to load products list.</td></tr>';
  }
}

// Load orders manager table
async function loadOrdersTable() {
  const tbody = document.getElementById('admin-orders-table-body');
  tbody.innerHTML = '<tr><td colspan="6" style="text-align: center;"><div class="spinner" style="margin: 20px auto;"></div></td></tr>';

  try {
    const data = await API.orders.getAll();
    const orders = data.orders;

    tbody.innerHTML = '';
    if (orders && orders.length > 0) {
      orders.forEach(order => {
        const tr = document.createElement('tr');
        const dateStr = new Date(order.orderDate).toLocaleDateString(undefined, {
          month: 'short', day: 'numeric', year: 'numeric'
        });

        tr.innerHTML = `
          <td style="font-family: monospace; font-size: 0.85rem;">${order._id}</td>
          <td>
            <strong>${order.shippingAddress.fullName}</strong>
            <span style="display: block; font-size: 0.8rem; color: var(--text-muted);">${order.shippingAddress.email}</span>
          </td>
          <td>${dateStr}</td>
          <td style="font-weight: 600; color: var(--primary);">₹${order.totalAmount.toFixed(2)}</td>
          <td>
            <select class="form-control" style="padding: 6px 12px; width: 140px;" onchange="updateOrderStatus('${order._id}', this.value)">
              <option value="Pending" ${order.orderStatus === 'Pending' ? 'selected' : ''}>Pending</option>
              <option value="Processing" ${order.orderStatus === 'Processing' ? 'selected' : ''}>Processing</option>
              <option value="Shipped" ${order.orderStatus === 'Shipped' ? 'selected' : ''}>Shipped</option>
              <option value="Delivered" ${order.orderStatus === 'Delivered' ? 'selected' : ''}>Delivered</option>
              <option value="Cancelled" ${order.orderStatus === 'Cancelled' ? 'selected' : ''}>Cancelled</option>
            </select>
          </td>
          <td>
            <button class="btn btn-secondary btn-sm" onclick="viewOrderDetails('${order._id}')">View Details</button>
          </td>
        `;
        tbody.appendChild(tr);
      });
    } else {
      tbody.innerHTML = '<tr><td colspan="6" style="text-align: center;">No customer orders found.</td></tr>';
    }
  } catch (error) {
    console.error(error);
    tbody.innerHTML = '<tr><td colspan="6" style="text-align: center; color: var(--danger);">Failed to load orders history.</td></tr>';
  }
}

// Load users management directory
async function loadUsersTable() {
  const tbody = document.getElementById('admin-users-table-body');
  tbody.innerHTML = '<tr><td colspan="5" style="text-align: center;"><div class="spinner" style="margin: 20px auto;"></div></td></tr>';

  try {
    const data = await API.auth.getUsers();
    const users = data.users;

    tbody.innerHTML = '';
    if (users && users.length > 0) {
      users.forEach(u => {
        const tr = document.createElement('tr');
        const dateStr = new Date(u.createdAt).toLocaleDateString();

        tr.innerHTML = `
          <td style="font-family: monospace; font-size: 0.85rem;">${u._id}</td>
          <td style="font-weight: 600;">${u.name}</td>
          <td>${u.email}</td>
          <td>
            <span class="order-status-badge ${u.role === 'admin' ? 'status-delivered' : 'status-processing'}">
              ${u.role.toUpperCase()}
            </span>
          </td>
          <td>${dateStr}</td>
        `;
        tbody.appendChild(tr);
      });
    } else {
      tbody.innerHTML = '<tr><td colspan="5" style="text-align: center;">No users registered yet.</td></tr>';
    }
  } catch (error) {
    console.error(error);
    tbody.innerHTML = '<tr><td colspan="5" style="text-align: center; color: var(--danger);">Failed to load users database directory.</td></tr>';
  }
}

// Update order status on dropdown change
async function updateOrderStatus(orderId, newStatus) {
  try {
    await API.orders.updateStatus(orderId, newStatus);
    showToast(`Order status updated to ${newStatus}`, 'success');
    loadDashboardData(); // update sales statistics
  } catch (error) {
    showToast(error.message || 'Could not update status', 'error');
  }
}

// View order detail invoice modal helper
async function viewOrderDetails(orderId) {
  try {
    const data = await API.orders.getById(orderId);
    const order = data.order;
    if (order) {
      // Prompt modal summary list
      let itemsSummary = '';
      order.products.forEach(p => {
        itemsSummary += `\n- ${p.name} (x${p.quantity}) - ₹${p.price.toFixed(2)}`;
      });

      alert(`Order Invoice ID: ${order._id}\nTotal Amount: ₹${order.totalAmount.toFixed(2)}\nPayment: ${order.paymentMethod}\nStatus: ${order.orderStatus}\nShipping: ${order.shippingAddress.fullName}\nAddress: ${order.shippingAddress.address}, ${order.shippingAddress.city}\nItems Purchased:${itemsSummary}`);
    }
  } catch (error) {
    showToast('Failed to retrieve order details', 'error');
  }
}

// Open modal for Adding / Editing Product
function openProductModal(product = null) {
  const modal = document.getElementById('product-modal');
  const title = document.getElementById('product-modal-title');
  const form = document.getElementById('product-form');
  
  form.reset();
  document.getElementById('specs-list-adders').innerHTML = '';
  specRowIndex = 0;

  if (product) {
    title.innerText = 'Edit Product Details';
    document.getElementById('prod-id-val').value = product._id;
    document.getElementById('prod-name-val').value = product.name;
    document.getElementById('prod-price-val').value = product.price;
    document.getElementById('prod-discount-val').value = product.discount || 0;
    document.getElementById('prod-category-val').value = product.category;
    document.getElementById('prod-stock-val').value = product.stock;
    document.getElementById('prod-desc-val').value = product.description;
    document.getElementById('prod-url-val').value = product.images.join(', ');

    // Fill specifications
    if (product.specifications && Object.keys(product.specifications).length > 0) {
      Object.entries(product.specifications).forEach(([key, val]) => {
        addSpecInputRow(key, val);
      });
    }
  } else {
    title.innerText = 'Add New Product';
    document.getElementById('prod-id-val').value = '';
    addSpecInputRow('', ''); // add one blank specs row by default
  }

  modal.classList.add('active');
}

function closeProductModal() {
  document.getElementById('product-modal').classList.remove('active');
}

// Append new Specifications entry Row inputs
function addSpecInputRow(key = '', val = '') {
  const container = document.getElementById('specs-list-adders');
  const rowId = `spec-row-${specRowIndex++}`;

  const row = document.createElement('div');
  row.id = rowId;
  row.style.display = 'flex';
  row.style.gap = '8px';
  row.style.alignItems = 'center';
  
  row.innerHTML = `
    <input type="text" class="form-control spec-key-input" placeholder="e.g. Battery Life" value="${key}" style="flex: 1;" required>
    <input type="text" class="form-control spec-val-input" placeholder="e.g. 40 Hours" value="${val}" style="flex: 1;" required>
    <button type="button" class="btn btn-secondary btn-sm" onclick="document.getElementById('${rowId}').remove()" style="padding: 10px; color: var(--danger); border-color: var(--danger);">&times;</button>
  `;

  container.appendChild(row);
}

// Edit product button triggers
function editProduct(id) {
  const prod = allProducts.find(p => p._id === id);
  if (prod) {
    openProductModal(prod);
  }
}

// Delete product button triggers
async function deleteProduct(id) {
  if (confirm('Are you sure you want to delete this product? This action cannot be undone.')) {
    try {
      await API.products.delete(id);
      showToast('Product successfully deleted', 'warning');
      loadDashboardData(); // Reloads table and stats
    } catch (error) {
      showToast(error.message || 'Failed to delete product', 'error');
    }
  }
}

// Save Product form submissions
async function handleSaveProduct(e) {
  e.preventDefault();

  const id = document.getElementById('prod-id-val').value;
  const name = document.getElementById('prod-name-val').value.trim();
  const price = document.getElementById('prod-price-val').value;
  const discount = document.getElementById('prod-discount-val').value || 0;
  const category = document.getElementById('prod-category-val').value;
  const stock = document.getElementById('prod-stock-val').value;
  const description = document.getElementById('prod-desc-val').value.trim();
  const imageUrls = document.getElementById('prod-url-val').value.trim();
  const imageFiles = document.getElementById('prod-image-val').files;

  // Compile specifications object
  const specs = {};
  document.querySelectorAll('#specs-list-adders div').forEach(row => {
    const key = row.querySelector('.spec-key-input').value.trim();
    const val = row.querySelector('.spec-val-input').value.trim();
    if (key && val) {
      specs[key] = val;
    }
  });

  const formData = new FormData();
  formData.append('name', name);
  formData.append('price', price);
  formData.append('discount', discount);
  formData.append('category', category);
  formData.append('stock', stock);
  formData.append('description', description);
  formData.append('specifications', JSON.stringify(specs));

  // Add imageUrls
  if (imageUrls) {
    const urls = imageUrls.split(',').map(url => url.trim());
    urls.forEach(url => {
      formData.append('images', url);
    });
  }

  // Add files
  if (imageFiles && imageFiles.length > 0) {
    for (let i = 0; i < imageFiles.length; i++) {
      formData.append('images', imageFiles[i]);
    }
  }

  const saveBtn = document.getElementById('save-product-btn');

  try {
    saveBtn.disabled = true;
    saveBtn.innerHTML = '<div class="spinner" style="margin: 0 auto;"></div>';

    let res;
    if (id) {
      res = await API.products.update(id, formData);
      showToast('Product updated successfully', 'success');
    } else {
      res = await API.products.create(formData);
      showToast('Product created successfully', 'success');
    }

    if (res.success) {
      closeProductModal();
      loadDashboardData(); // Refresh table & metrics
    }
  } catch (error) {
    showToast(error.message || 'Failed to save product details.', 'error');
  } finally {
    saveBtn.disabled = false;
    saveBtn.innerText = 'Save Product';
  }
}
