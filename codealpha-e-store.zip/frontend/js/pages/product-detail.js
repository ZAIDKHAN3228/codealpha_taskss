// Product Detail Page Script
let currentProduct = null;
let selectedRating = 0;

document.addEventListener('DOMContentLoaded', () => {
  const params = new URLSearchParams(window.location.search);
  const productId = params.get('id');

  if (!productId) {
    window.location.href = 'products.html';
    return;
  }

  loadProductDetails(productId);
  setupQuantityPicker();
  setupReviewForm();
});

// Load details from API
async function loadProductDetails(id) {
  const loader = document.getElementById('detail-loader');
  const container = document.getElementById('detail-container');

  try {
    const data = await API.getProductById(id); // Wait, in api.js we declared `API.products.getById(id)` not `API.getProductById`. Let's use `API.products.getById(id)`!
    currentProduct = data.product;

    if (currentProduct) {
      renderDetails();
      loadRelatedProducts();
      
      loader.style.display = 'none';
      container.style.display = 'block';
    } else {
      loader.innerHTML = '<p class="section-subtitle">Product not found.</p>';
    }
  } catch (error) {
    console.error(error);
    loader.innerHTML = '<p class="section-subtitle" style="color: var(--danger);">Failed to load product details.</p>';
  }
}

// Render dynamic fields into DOM
function renderDetails() {
  // Title & Category
  document.getElementById('product-title').innerText = currentProduct.name;
  document.getElementById('product-category').innerText = currentProduct.category;
  
  // Description
  document.getElementById('product-description').innerText = currentProduct.description;

  // Prices & Badges
  const hasDiscount = currentProduct.discount > 0;
  const finalPrice = hasDiscount 
    ? (currentProduct.price * (1 - currentProduct.discount / 100)).toFixed(2)
    : currentProduct.price.toFixed(2);

  document.getElementById('product-price').innerText = `₹${finalPrice}`;
  
  const originalPriceEl = document.getElementById('product-original-price');
  const discountBadgeEl = document.getElementById('product-discount-badge');

  if (hasDiscount) {
    originalPriceEl.innerText = `₹${currentProduct.price.toFixed(2)}`;
    originalPriceEl.style.display = 'inline';
    discountBadgeEl.innerText = `-${currentProduct.discount}%`;
    discountBadgeEl.style.display = 'inline';
  } else {
    originalPriceEl.style.display = 'none';
    discountBadgeEl.style.display = 'none';
  }

  // Stock Status
  const stockEl = document.getElementById('product-stock-status');
  const addBtn = document.getElementById('add-to-cart-btn');
  const buyBtn = document.getElementById('buy-now-btn');
  
  if (currentProduct.stock > 0) {
    stockEl.innerText = `In Stock (${currentProduct.stock} available)`;
    stockEl.className = 'stock-status in-stock';
    addBtn.disabled = false;
    buyBtn.disabled = false;
  } else {
    stockEl.innerText = 'Out of Stock';
    stockEl.className = 'stock-status out-of-stock';
    addBtn.disabled = true;
    buyBtn.disabled = true;
  }

  // Rating Stars
  const ratingStarsEl = document.getElementById('product-rating-stars');
  const starsString = '★'.repeat(Math.round(currentProduct.rating)) + '☆'.repeat(5 - Math.round(currentProduct.rating));
  ratingStarsEl.innerHTML = `${starsString} <span style="color: var(--text-secondary); font-size:0.9rem;">(${currentProduct.numReviews || 0} reviews)</span>`;

  // Gallery Images
  const mainImg = document.getElementById('main-product-img');
  mainImg.src = currentProduct.images[0] || 'https://images.unsplash.com/photo-1531403009284-440f080d1e12?w=800';
  mainImg.alt = currentProduct.name;

  const thumbsContainer = document.getElementById('product-thumbnails-container');
  thumbsContainer.innerHTML = '';
  
  if (currentProduct.images && currentProduct.images.length > 0) {
    currentProduct.images.forEach((imgUrl, i) => {
      const thumb = document.createElement('div');
      thumb.className = `thumbnail-img ${i === 0 ? 'active' : ''}`;
      thumb.innerHTML = `<img src="${imgUrl}" alt="Thumbnail ${i+1}">`;
      thumb.addEventListener('click', () => {
        // Toggle main image
        mainImg.src = imgUrl;
        // Toggle active thumbnail styling
        document.querySelectorAll('.thumbnail-img').forEach(t => t.classList.remove('active'));
        thumb.classList.add('active');
      });
      thumbsContainer.appendChild(thumb);
    });
  }

  // Specifications
  const specsContainer = document.getElementById('product-specs-container');
  specsContainer.innerHTML = '';
  if (currentProduct.specifications && Object.keys(currentProduct.specifications).length > 0) {
    Object.entries(currentProduct.specifications).forEach(([key, val]) => {
      const specRow = document.createElement('div');
      specRow.className = 'spec-item';
      specRow.innerHTML = `
        <span class="spec-key">${key}</span>
        <span class="spec-value">${val}</span>
      `;
      specsContainer.appendChild(specRow);
    });
  } else {
    specsContainer.innerHTML = '<p class="spec-item" style="color: var(--text-muted);">No technical specifications listed.</p>';
  }

  // Action Buttons
  addBtn.onclick = () => addToCartAction(false);
  buyBtn.onclick = () => addToCartAction(true);

  // Load Reviews list
  renderReviews();
}

// Related Products loading
async function loadRelatedProducts() {
  const grid = document.getElementById('related-products-grid');
  if (!grid) return;

  try {
    const data = await API.products.getAll({ category: currentProduct.category });
    // Filter out current product
    const related = data.products.filter(p => p._id !== currentProduct._id).slice(0, 3);
    
    grid.innerHTML = '';
    if (related.length > 0) {
      related.forEach(prod => {
        grid.appendChild(createProductCard(prod));
      });
    } else {
      grid.innerHTML = '<p style="color: var(--text-secondary);">No related products in this category.</p>';
    }
  } catch (error) {
    console.error(error);
  }
}

// Create Card helper matching listing page
function createProductCard(product) {
  const card = document.createElement('div');
  card.className = 'product-card';

  const hasDiscount = product.discount > 0;
  const finalPrice = hasDiscount 
    ? (product.price * (1 - product.discount / 100)).toFixed(2)
    : product.price.toFixed(2);

  const discountBadge = hasDiscount 
    ? `<div class="product-badge">-${product.discount}%</div>`
    : '';

  const ratingStars = '★'.repeat(Math.round(product.rating)) + '☆'.repeat(5 - Math.round(product.rating));
  const imageSrc = product.images[0] || 'https://images.unsplash.com/photo-1531403009284-440f080d1e12?w=800';

  card.innerHTML = `
    ${discountBadge}
    <div class="product-card-img-container">
      <img src="${imageSrc}" alt="${product.name}">
      <div class="product-card-actions">
        <a href="product.html?id=${product._id}" class="btn btn-secondary btn-sm" style="flex: 1;">View Details</a>
      </div>
    </div>
    <div class="product-card-info">
      <span class="product-card-category">${product.category}</span>
      <a href="product.html?id=${product._id}"><h3 class="product-card-title">${product.name}</h3></a>
      <div class="product-card-rating">
        ${ratingStars}
        <span>(${product.numReviews || 0})</span>
      </div>
      <div class="product-card-price-container">
        <span class="product-card-price">₹${finalPrice}</span>
      </div>
    </div>
  `;
  return card;
}

// Add to Cart / Buy Now actions
async function addToCartAction(redirectCheckout = false) {
  const qtyInput = document.getElementById('qty-input');
  const quantity = Number(qtyInput.value);

  if (quantity > currentProduct.stock) {
    showToast(`Cannot add more than stock count (${currentProduct.stock})`, 'error');
    return;
  }

  try {
    const isLoggedIn = API.isLoggedIn();
    if (isLoggedIn) {
      await API.cart.add(currentProduct._id, quantity);
    }

    // Always sync with LocalStorage
    let localCart = getLocalCart();
    const itemIndex = localCart.findIndex(item => item.product === currentProduct._id);
    if (itemIndex > -1) {
      localCart[itemIndex].quantity += quantity;
    } else {
      localCart.push({ product: currentProduct._id, quantity });
    }
    saveLocalCart(localCart);

    showToast(`${quantity} items added to cart`, 'success');

    if (redirectCheckout) {
      setTimeout(() => {
        window.location.href = 'checkout.html';
      }, 800);
    }
  } catch (error) {
    showToast(error.message || 'Error updating cart', 'error');
  }
}

// Quantity pickers minus/plus bindings
function setupQuantityPicker() {
  const qtyInput = document.getElementById('qty-input');
  const minusBtn = document.getElementById('qty-minus');
  const plusBtn = document.getElementById('qty-plus');

  minusBtn.addEventListener('click', () => {
    let val = Number(qtyInput.value);
    if (val > 1) {
      qtyInput.value = val - 1;
    }
  });

  plusBtn.addEventListener('click', () => {
    let val = Number(qtyInput.value);
    if (currentProduct && val < currentProduct.stock) {
      qtyInput.value = val + 1;
    } else {
      showToast('Cannot purchase more than available stock', 'warning');
    }
  });
}

// Render product reviews
function renderReviews() {
  const listContainer = document.getElementById('reviews-list-container');
  listContainer.innerHTML = '';

  if (currentProduct.reviews && currentProduct.reviews.length > 0) {
    currentProduct.reviews.forEach(review => {
      const reviewRow = document.createElement('div');
      reviewRow.className = 'review-item';
      const starsString = '★'.repeat(review.rating) + '☆'.repeat(5 - review.rating);
      
      const formattedDate = new Date(review.createdAt).toLocaleDateString(undefined, {
        year: 'numeric', month: 'long', day: 'numeric'
      });

      reviewRow.innerHTML = `
        <div class="review-header">
          <span class="review-user">${review.name}</span>
          <span class="review-rating">${starsString}</span>
        </div>
        <p class="review-date">Reviewed on ${formattedDate}</p>
        <p class="review-comment">${review.comment}</p>
      `;
      listContainer.appendChild(reviewRow);
    });
  } else {
    listContainer.innerHTML = '<p style="color: var(--text-muted);">No reviews written for this product yet.</p>';
  }
}

// Review stars interaction and submit form
function setupReviewForm() {
  const isLoggedIn = API.isLoggedIn();
  const fields = document.getElementById('review-form-fields');
  const prompt = document.getElementById('review-login-prompt');

  if (isLoggedIn) {
    fields.style.display = 'block';
    prompt.style.display = 'none';

    // Stars rating click handler
    const stars = document.querySelectorAll('#rating-picker-stars .rating-star');
    stars.forEach(star => {
      star.addEventListener('click', () => {
        selectedRating = Number(star.getAttribute('data-value'));
        
        // Update gold classes
        stars.forEach(s => {
          if (Number(s.getAttribute('data-value')) <= selectedRating) {
            s.classList.add('selected');
          } else {
            s.classList.remove('selected');
          }
        });
      });
    });

    // Submit review click
    document.getElementById('submit-review-btn').addEventListener('click', submitReview);
  } else {
    fields.style.display = 'none';
    prompt.style.display = 'block';
  }
}

// Post review form to API
async function submitReview() {
  const comment = document.getElementById('review-comment-input').value.trim();

  if (selectedRating === 0) {
    showToast('Please select a rating score', 'warning');
    return;
  }

  if (!comment) {
    showToast('Please write a comment', 'warning');
    return;
  }

  try {
    await API.products.addReview(currentProduct._id, {
      rating: selectedRating,
      comment
    });

    showToast('Review submitted successfully!', 'success');
    
    // Clear inputs
    document.getElementById('review-comment-input').value = '';
    selectedRating = 0;
    document.querySelectorAll('#rating-picker-stars .rating-star').forEach(s => s.classList.remove('selected'));

    // Reload product details to show new review
    loadProductDetails(currentProduct._id);
  } catch (error) {
    showToast(error.message || 'Failed to submit review. Have you already reviewed this product?', 'error');
  }
}
