// Cart Page Script
let cartItems = []; // Array of populated items { product: productObj, quantity }
let couponApplied = false;
let discountPercent = 0;

document.addEventListener('DOMContentLoaded', () => {
  loadCart();
  
  document.getElementById('apply-coupon-btn').addEventListener('click', applyCoupon);
  document.getElementById('checkout-btn').addEventListener('click', () => {
    window.location.href = 'checkout.html';
  });
});

// Load cart items from LocalStorage/Database and populate details
async function loadCart() {
  const loader = document.getElementById('cart-loader');
  const emptyMsg = document.getElementById('empty-cart-message');
  const gridLayout = document.getElementById('cart-grid-layout');

  if (!loader) return;

  loader.style.display = 'flex';
  emptyMsg.style.display = 'none';
  gridLayout.style.display = 'none';

  const localCart = getLocalCart();

  if (localCart.length === 0) {
    loader.style.display = 'none';
    emptyMsg.style.display = 'block';
    return;
  }

  try {
    cartItems = [];

    // If logged in, fetch from API. If guest, fetch details one by one.
    if (API.isLoggedIn()) {
      const data = await API.cart.get();
      // Ensure local storage is up to date with DB cart items
      // Convert database items to local representation first
      const dbItems = data.cart.products.map(item => ({
        product: item.product._id,
        quantity: item.quantity
      }));
      // Save to local storage to keep them in sync
      saveLocalCart(dbItems);

      // Save populated items
      cartItems = data.cart.products.map(item => ({
        product: item.product,
        quantity: item.quantity
      }));
    } else {
      // Guest: Resolve products details by ID
      for (const item of localCart) {
        try {
          const detail = await API.products.getById(item.product);
          if (detail.product) {
            cartItems.push({
              product: detail.product,
              quantity: item.quantity
            });
          }
        } catch (err) {
          console.error(`Could not fetch details for item: ${item.product}`, err);
        }
      }
    }

    if (cartItems.length > 0) {
      renderCart();
      loader.style.display = 'none';
      gridLayout.style.display = 'grid';
    } else {
      loader.style.display = 'none';
      emptyMsg.style.display = 'block';
    }
  } catch (error) {
    console.error(error);
    loader.innerHTML = '<p class="section-subtitle" style="color: var(--danger);">Failed to load cart.</p>';
  }
}

// Render cart items lists and totals calculation
function renderCart() {
  const container = document.getElementById('cart-items-list');
  container.innerHTML = '';

  let subtotal = 0;

  cartItems.forEach(item => {
    const product = item.product;
    const hasDiscount = product.discount > 0;
    const finalPrice = hasDiscount 
      ? product.price * (1 - product.discount / 100)
      : product.price;

    const itemSubtotal = finalPrice * item.quantity;
    subtotal += itemSubtotal;

    const itemRow = document.createElement('div');
    itemRow.className = 'cart-item';
    
    const imageSrc = product.images[0] || 'https://images.unsplash.com/photo-1531403009284-440f080d1e12?w=800';

    itemRow.innerHTML = `
      <div class="cart-item-img">
        <img src="${imageSrc}" alt="${product.name}">
      </div>
      <div class="cart-item-details">
        <h4 class="cart-item-name">${product.name}</h4>
        <p class="cart-item-category">${product.category}</p>
        <span class="cart-item-price">₹${finalPrice.toFixed(2)}</span>
      </div>
      
      <div class="quantity-picker" style="margin-right: 24px;">
        <button class="quantity-btn" onclick="updateItemQuantity('${product._id}', ${item.quantity - 1})">-</button>
        <input type="number" class="quantity-input" value="${item.quantity}" readonly>
        <button class="quantity-btn" onclick="updateItemQuantity('${product._id}', ${item.quantity + 1})">+</button>
      </div>

      <div style="font-weight: 700; width: 80px; text-align: right; margin-right: 24px;">
        ₹${itemSubtotal.toFixed(2)}
      </div>

      <button class="cart-item-remove" onclick="removeCartItem('${product._id}')">
        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/><line x1="10" x2="10" y1="11" y2="17"/><line x1="14" x2="14" y1="11" y2="17"/></svg>
      </button>
    `;

    container.appendChild(itemRow);
  });

  // Calculate totals
  const tax = subtotal * 0.08;
  const shipping = subtotal >= 15000 ? 0 : 999;
  
  let couponDiscount = 0;
  if (couponApplied) {
    couponDiscount = subtotal * (discountPercent / 100);
    document.getElementById('coupon-row').style.display = 'flex';
    document.getElementById('coupon-discount').innerText = `-₹${couponDiscount.toFixed(2)}`;
  } else {
    document.getElementById('coupon-row').style.display = 'none';
  }

  const grandTotal = subtotal + tax + shipping - couponDiscount;

  // Render values
  document.getElementById('cart-subtotal').innerText = `₹${subtotal.toFixed(2)}`;
  document.getElementById('cart-tax').innerText = `₹${tax.toFixed(2)}`;
  document.getElementById('cart-shipping').innerText = shipping === 0 ? 'FREE' : `₹${shipping.toFixed(2)}`;
  document.getElementById('cart-grand-total').innerText = `₹${grandTotal.toFixed(2)}`;
}

// Adjust quantity click handler
async function updateItemQuantity(productId, newQty) {
  if (newQty <= 0) {
    removeCartItem(productId);
    return;
  }

  const item = cartItems.find(i => i.product._id === productId);
  if (item && newQty > item.product.stock) {
    showToast(`Only ${item.product.stock} items left in stock`, 'warning');
    return;
  }

  try {
    if (API.isLoggedIn()) {
      await API.cart.update(productId, newQty);
    }
    
    // Sync local storage
    let localCart = getLocalCart();
    const itemIndex = localCart.findIndex(i => i.product === productId);
    if (itemIndex > -1) {
      localCart[itemIndex].quantity = newQty;
      saveLocalCart(localCart);
    }

    // Sync state
    const stateItem = cartItems.find(i => i.product._id === productId);
    if (stateItem) stateItem.quantity = newQty;

    renderCart();
  } catch (error) {
    showToast('Failed to update quantity', 'error');
  }
}

// Delete cart item handler
async function removeCartItem(productId) {
  try {
    if (API.isLoggedIn()) {
      await API.cart.remove(productId);
    }

    // Sync local storage
    let localCart = getLocalCart();
    localCart = localCart.filter(i => i.product !== productId);
    saveLocalCart(localCart);

    // Sync state
    cartItems = cartItems.filter(i => i.product._id !== productId);

    if (cartItems.length > 0) {
      renderCart();
    } else {
      document.getElementById('cart-grid-layout').style.display = 'none';
      document.getElementById('empty-cart-message').style.display = 'block';
    }
    showToast('Item removed from cart', 'warning');
  } catch (error) {
    showToast('Failed to remove item', 'error');
  }
}

// Promo Coupon Codes Application
function applyCoupon() {
  const code = document.getElementById('coupon-input').value.trim().toUpperCase();

  if (!code) {
    showToast('Please enter a coupon code', 'warning');
    return;
  }

  if (code === 'DISCOUNT10' || code === 'WELCOME10') {
    couponApplied = true;
    discountPercent = 10;
    showToast('Coupon code applied: 10% discount!', 'success');
    renderCart();
  } else {
    couponApplied = false;
    discountPercent = 0;
    showToast('Invalid coupon code', 'error');
    renderCart();
  }
}
