const express = require('express');
const router = express.Router();
const { getUsers, getUserById, updateUser, deleteUser, getUserDashboard } = require('../controllers/userController');
const auth = require('../middleware/auth');
const upload = require('../middleware/upload');

const profileUploadFields = upload.fields([
  { name: 'profileImage', maxCount: 1 },
  { name: 'coverImage', maxCount: 1 }
]);

router.get('/', auth, getUsers);
router.get('/:id', auth, getUserById);
router.put('/:id', auth, profileUploadFields, updateUser);
router.delete('/:id', auth, deleteUser);
router.get('/:id/dashboard', auth, getUserDashboard);

module.exports = router;
