const express = require('express');
const router = express.Router();
const { getPosts, createPost, updatePost, deletePost, likePost, unlikePost, generateCaption } = require('../controllers/postController');
const auth = require('../middleware/auth');
const upload = require('../middleware/upload');

router.get('/', auth, getPosts);
router.post('/', auth, upload.array('images', 10), createPost);
router.put('/:id', auth, updatePost);
router.delete('/:id', auth, deletePost);

// Like operations
router.post('/:id/like', auth, likePost);
router.delete('/:id/unlike', auth, unlikePost);

// AI Caption Generation
router.post('/generate-caption', auth, upload.single('image'), generateCaption);

module.exports = router;
