const express = require('express');
const router = express.Router();
const { register, login, logout, googleConfig, googleLogin } = require('../controllers/authController');

router.post('/register', register);
router.post('/login', login);
router.post('/logout', logout);

// Google Sign-In routes
router.get('/google/config', googleConfig);
router.post('/google', googleLogin);

module.exports = router;
