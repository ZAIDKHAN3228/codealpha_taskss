const express = require('express');
const router = express.Router();
const { getReels, createReel } = require('../controllers/postController');
const auth = require('../middleware/auth');
const upload = require('../middleware/upload');

router.get('/', auth, getReels);
router.post('/', auth, upload.single('video'), createReel);

module.exports = router;
