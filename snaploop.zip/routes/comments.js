const express = require('express');
const router = express.Router();
const { addComment, updateComment, deleteComment } = require('../controllers/commentController');
const auth = require('../middleware/auth');

router.post('/', auth, addComment);
router.put('/:id', auth, updateComment);
router.delete('/:id', auth, deleteComment);

module.exports = router;
