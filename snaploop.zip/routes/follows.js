const express = require('express');
const router = express.Router();
const { followUser, unfollowUser } = require('../controllers/followController');
const auth = require('../middleware/auth');

router.post('/follow/:id', auth, followUser);
router.delete('/unfollow/:id', auth, unfollowUser);

module.exports = router;
