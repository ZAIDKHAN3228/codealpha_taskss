const mongoose = require('mongoose');
const fs = require('fs');
const path = require('path');

let mongod = null;
let cachedConnection = null;

// File path for persistence in ephemeral environments (like Vercel)
const DB_FILE = '/tmp/snaploop_db.json';

// Global cache for mock database collections
global.mockCollections = global.mockCollections || {};
global.useMockDB = false;

const loadMockDB = () => {
  try {
    if (fs.existsSync(DB_FILE)) {
      const data = fs.readFileSync(DB_FILE, 'utf8');
      global.mockCollections = JSON.parse(data);
      console.log('Mock DB loaded from persistence file:', DB_FILE);
    }
  } catch (err) {
    console.error('Failed to load mock DB:', err.message);
  }
};

const saveMockDB = () => {
  try {
    const dir = path.dirname(DB_FILE);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    fs.writeFileSync(DB_FILE, JSON.stringify(global.mockCollections, null, 2), 'utf8');
  } catch (err) {
    console.error('Failed to save mock DB:', err.message);
  }
};

class MockQuery {
  constructor(results) {
    this.results = results;
  }
  populate() { return this; }
  select() { return this; }
  sort() { return this; }
  limit(n) {
    if (Array.isArray(this.results)) {
      this.results = this.results.slice(0, n);
    }
    return this;
  }
  skip(n) {
    if (Array.isArray(this.results)) {
      this.results = this.results.slice(n);
    }
    return this;
  }
  exec() {
    return Promise.resolve(this.results);
  }
  then(resolve, reject) {
    return Promise.resolve(this.results).then(resolve, reject);
  }
  catch(reject) {
    return Promise.resolve(this.results).catch(reject);
  }
}

const matchQuery = (doc, query) => {
  if (!query || Object.keys(query).length === 0) return true;
  for (const key in query) {
    if (key === '$or') {
      const orArray = query.$or;
      if (!Array.isArray(orArray) || orArray.length === 0) continue;
      const matchSome = orArray.some(q => matchQuery(doc, q));
      if (!matchSome) return false;
    } else {
      const val = query[key];
      const docVal = doc[key];
      if (val && typeof val === 'object') {
        if ('$ne' in val) {
          if (String(docVal) === String(val.$ne)) return false;
        } else if ('$in' in val) {
          if (!Array.isArray(val.$in)) return false;
          const matchIn = val.$in.some(item => String(item) === String(docVal));
          if (!matchIn) return false;
        } else if ('$nin' in val) {
          if (!Array.isArray(val.$nin)) return false;
          const matchNin = val.$nin.every(item => String(item) !== String(docVal));
          if (!matchNin) return false;
        }
      } else {
        if (String(docVal) !== String(val)) return false;
      }
    }
  }
  return true;
};

const applyUpdate = (doc, update) => {
  if (update.$addToSet) {
    for (const key in update.$addToSet) {
      doc[key] = doc[key] || [];
      const val = String(update.$addToSet[key]);
      if (!doc[key].some(item => String(item) === val)) {
        doc[key].push(update.$addToSet[key]);
      }
    }
  }
  if (update.$pull) {
    for (const key in update.$pull) {
      if (Array.isArray(doc[key])) {
        const val = String(update.$pull[key]);
        doc[key] = doc[key].filter(item => String(item) !== val);
      }
    }
  }
  const setFields = update.$set || {};
  for (const key in update) {
    if (!key.startsWith('$')) {
      setFields[key] = update[key];
    }
  }
  for (const key in setFields) {
    doc[key] = setFields[key];
  }
};

const initializeDefaultFields = (doc, modelName) => {
  if (!doc) return doc;
  
  if (modelName === 'User') {
    doc.followers = doc.followers || [];
    doc.following = doc.following || [];
    doc.bio = doc.bio || '';
    doc.profileImage = doc.profileImage || '';
    doc.coverImage = doc.coverImage || '';
    doc.location = doc.location || '';
    doc.website = doc.website || '';
  } else if (modelName === 'Post') {
    doc.likes = doc.likes || [];
    doc.comments = doc.comments || [];
    doc.images = doc.images || [];
  } else if (modelName === 'Notification') {
    doc.read = doc.read !== undefined ? doc.read : false;
  }
  return doc;
};

const wrapDocument = (doc, modelName) => {
  if (!doc) return doc;
  initializeDefaultFields(doc, modelName);
  if (doc.save) return doc;
  
  doc.save = async function() {
    doc.updatedAt = new Date();
    saveMockDB();
    return doc;
  };
  doc.toJSON = function() { return doc; };
  doc.toObject = function() { return doc; };
  doc.set = function(key, val) { doc[key] = val; };
  doc.get = function(key) { return doc[key]; };
  return doc;
};

const mockModel = (ModelClass, name) => {
  if (ModelClass._isMocked) return;
  ModelClass._isMocked = true;

  const originals = {
    create: ModelClass.create,
    find: ModelClass.find,
    findOne: ModelClass.findOne,
    findById: ModelClass.findById,
    findByIdAndUpdate: ModelClass.findByIdAndUpdate,
    findByIdAndDelete: ModelClass.findByIdAndDelete,
    deleteOne: ModelClass.deleteOne,
    deleteMany: ModelClass.deleteMany,
    updateMany: ModelClass.updateMany,
    countDocuments: ModelClass.countDocuments
  };

  global.mockCollections[name] = global.mockCollections[name] || [];
  const collection = global.mockCollections[name];

  const generateId = () => new mongoose.Types.ObjectId().toString();

  ModelClass.create = async function(data) {
    if (!global.useMockDB) return originals.create.apply(this, arguments);
    const arr = Array.isArray(data) ? data : [data];
    const created = arr.map(item => {
      const doc = { _id: generateId(), createdAt: new Date(), updatedAt: new Date(), ...item };
      wrapDocument(doc, name);
      collection.push(doc);
      return doc;
    });
    saveMockDB();
    return Array.isArray(data) ? created : created[0];
  };

  ModelClass.find = function(query = {}) {
    if (!global.useMockDB) return originals.find.apply(this, arguments);
    const results = collection.filter(doc => matchQuery(doc, query)).map(doc => wrapDocument(doc, name));
    return new MockQuery(results);
  };

  ModelClass.findOne = function(query = {}) {
    if (!global.useMockDB) return originals.findOne.apply(this, arguments);
    const doc = collection.find(d => matchQuery(d, query));
    return new MockQuery(wrapDocument(doc, name));
  };

  ModelClass.findById = function(id) {
    if (!global.useMockDB) return originals.findById.apply(this, arguments);
    return ModelClass.findOne({ _id: id });
  };

  ModelClass.findByIdAndUpdate = async function(id, update, options = {}) {
    if (!global.useMockDB) return originals.findByIdAndUpdate.apply(this, arguments);
    const doc = collection.find(d => String(d._id) === String(id));
    if (!doc) return null;
    applyUpdate(doc, update);
    wrapDocument(doc, name);
    saveMockDB();
    return doc;
  };

  ModelClass.findByIdAndDelete = async function(id) {
    if (!global.useMockDB) return originals.findByIdAndDelete.apply(this, arguments);
    const idx = collection.findIndex(d => String(d._id) === String(id));
    if (idx === -1) return null;
    const removed = collection.splice(idx, 1)[0];
    saveMockDB();
    return wrapDocument(removed, name);
  };

  ModelClass.deleteOne = async function(query) {
    if (!global.useMockDB) return originals.deleteOne.apply(this, arguments);
    const idx = collection.findIndex(d => matchQuery(d, query));
    if (idx !== -1) {
      collection.splice(idx, 1);
      saveMockDB();
      return { deletedCount: 1 };
    }
    return { deletedCount: 0 };
  };

  ModelClass.deleteMany = async function(query) {
    if (!global.useMockDB) return originals.deleteMany.apply(this, arguments);
    let deletedCount = 0;
    for (let i = collection.length - 1; i >= 0; i--) {
      if (matchQuery(collection[i], query)) {
        collection.splice(i, 1);
        deletedCount++;
      }
    }
    if (deletedCount > 0) saveMockDB();
    return { deletedCount };
  };

  ModelClass.updateMany = async function(query, update) {
    if (!global.useMockDB) return originals.updateMany.apply(this, arguments);
    let matchedCount = 0;
    collection.forEach(doc => {
      if (matchQuery(doc, query)) {
        applyUpdate(doc, update);
        matchedCount++;
      }
    });
    if (matchedCount > 0) saveMockDB();
    return { matchedCount };
  };

  ModelClass.countDocuments = async function(query = {}) {
    if (!global.useMockDB) return originals.countDocuments.apply(this, arguments);
    return collection.filter(doc => matchQuery(doc, query)).length;
  };
};

// Overwrite mongoose.model to dynamically apply our runtime toggleable mock wrapper
const originalModel = mongoose.model.bind(mongoose);
mongoose.model = function(name, schema) {
  const ModelClass = originalModel(name, schema);
  mockModel(ModelClass, name);
  return ModelClass;
};

const enableMongooseMocking = () => {
  console.log('Swapping Mongoose models with Sandbox in-memory engine...');
  global.useMockDB = true;
  loadMockDB();

  // Fake connection state
  Object.defineProperty(mongoose.connection, 'readyState', {
    get: () => 1,
    configurable: true
  });

  const modelNames = mongoose.modelNames();
  modelNames.forEach(name => {
    const ModelClass = mongoose.model(name);
    mockModel(ModelClass, name);
  });
};

const connectDB = async () => {
  if (mongoose.connection.readyState === 1) {
    return mongoose.connection;
  }

  if (cachedConnection) {
    try {
      await cachedConnection;
      return mongoose.connection;
    } catch (err) {
      cachedConnection = null;
    }
  }

  try {
    const dbUri = process.env.MONGODB_URI;
    if (!dbUri || dbUri.includes('127.0.0.1') || dbUri.includes('localhost') || dbUri.includes('pwyxs')) {
      throw new Error('Database domain non-existent or pointing to a local instance.');
    }
    console.log(`Connecting to MongoDB at: ${dbUri}...`);
    cachedConnection = mongoose.connect(dbUri, {
      serverSelectionTimeoutMS: 5000,
    });
    await cachedConnection;
    console.log('MongoDB connected successfully.');
    return mongoose.connection;
  } catch (err) {
    cachedConnection = null;
    console.log('Could not connect to Cloud MongoDB:', err.message);
    
    // Automatically trigger Sandbox Fallback
    enableMongooseMocking();
    return mongoose.connection;
  }
};

const disconnectDB = async () => {
  try {
    await mongoose.disconnect();
    if (mongod) {
      await mongod.stop();
    }
  } catch (err) {
    console.error('Error disconnecting database:', err);
  }
};

module.exports = { connectDB, disconnectDB };
