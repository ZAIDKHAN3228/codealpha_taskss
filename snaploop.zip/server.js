const express = require('express');
const cors = require('cors');
const path = require('path');
require('dotenv').config();

const { connectDB } = require('./config/db');

// Import routes
const authRoutes = require('./routes/auth');
const userRoutes = require('./routes/users');
const postRoutes = require('./routes/posts');
const commentRoutes = require('./routes/comments');
const followRoutes = require('./routes/follows');
const notificationRoutes = require('./routes/notifications');
const reelsRoutes = require('./routes/reels');

const app = express();

// Middlewares
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static upload directory
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Serve frontend client SPA
app.use(express.static(path.join(__dirname, 'public')));

// Ensure DB connection on each request (serverless pattern)
app.use(async (req, res, next) => {
  try {
    await connectDB();
    next();
  } catch (err) {
    console.error('Database connection middleware error:', err.message);
    res.status(500).json({ 
      message: 'Database connection is offline. Please check MONGODB_URI on Vercel and ensure IP addresses (0.0.0.0/0) are whitelisted on MongoDB Atlas.' 
    });
  }
});

// API Routes
app.use('/api/auth', authRoutes);
app.use('/api/users', userRoutes);
app.use('/api/posts', postRoutes);
app.use('/api/comments', commentRoutes);
app.use('/api', followRoutes); // Mounts /api/follow/:id and /api/unfollow/:id
app.use('/api/notifications', notificationRoutes);
app.use('/api/reels', reelsRoutes);

// Fallback index.html for SPA router
app.get('*splat', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Database connection
connectDB().catch(err => {
  console.error('Database connection failed startup:', err);
});

// Export app for Vercel serverless functions
module.exports = app;

// Start local listener only if not running inside Vercel environment
if (!process.env.VERCEL) {
  const PORT = process.env.PORT || 5000;
  app.listen(PORT, () => {
    console.log(`SnapLoop Server running in ${process.env.NODE_ENV || 'production'} mode on port ${PORT}`);
  });
}
