const User = require('../models/User');
const Post = require('../models/Post');
const Comment = require('../models/Comment');
const Follower = require('../models/Follower');
const Notification = require('../models/Notification');
const fs = require('fs');
const path = require('path');

// @desc    Get all users or search users by username/fullname
// @route   GET /api/users
// @access  Private
exports.getUsers = async (req, res) => {
  try {
    const searchQuery = req.query.search;
    let query = {};

    if (searchQuery) {
      const cleanSearch = searchQuery.trim();
      query = {
        $or: [
          { username: { $regex: cleanSearch, $options: 'i' } },
          { fullname: { $regex: cleanSearch, $options: 'i' } }
        ]
      };
    }

    // Exclude current user from result lists if desired, or return all
    // Let's exclude password and return results
    const users = await User.find(query).select('-password').limit(20);
    res.json(users);
  } catch (err) {
    console.error('Get users error:', err);
    res.status(500).json({ message: 'Server error retrieving users.' });
  }
};

// @desc    Get user by ID
// @route   GET /api/users/:id
// @access  Private
exports.getUserById = async (req, res) => {
  try {
    const user = await User.findById(req.params.id)
      .select('-password')
      .populate('followers', 'username fullname profileImage')
      .populate('following', 'username fullname profileImage');

    if (!user) {
      return res.status(404).json({ message: 'User not found.' });
    }

    // Get total posts count
    const postsCount = await Post.countDocuments({ userId: user._id });

    // Convert document to JSON and add posts count
    const userObj = user.toJSON();
    userObj.postsCount = postsCount;

    res.json(userObj);
  } catch (err) {
    console.error('Get user by id error:', err);
    res.status(500).json({ message: 'Server error retrieving user profile.' });
  }
};

// @desc    Update user profile
// @route   PUT /api/users/:id
// @access  Private
exports.updateUser = async (req, res) => {
  try {
    // Check if updating self
    if (req.user._id.toString() !== req.params.id) {
      return res.status(403).json({ message: 'You can only update your own profile.' });
    }

    const user = await User.findById(req.params.id);
    if (!user) {
      return res.status(404).json({ message: 'User not found.' });
    }

    const { fullname, bio, location, website, username, email } = req.body;

    // Check if new username/email are taken
    if (username && username.toLowerCase().trim() !== user.username) {
      const usernameExists = await User.findOne({ username: username.toLowerCase().trim() });
      if (usernameExists) {
        return res.status(400).json({ message: 'Username is already taken.' });
      }
      user.username = username.toLowerCase().trim();
    }

    if (email && email.toLowerCase().trim() !== user.email) {
      const emailExists = await User.findOne({ email: email.toLowerCase().trim() });
      if (emailExists) {
        return res.status(400).json({ message: 'Email is already taken.' });
      }
      user.email = email.toLowerCase().trim();
    }

    if (fullname) user.fullname = fullname.trim();
    if (bio !== undefined) user.bio = bio.trim();

    // Custom fields location and website
    // (We will save them on the User object. Mongoose allows loose schemas if using Mixed, 
    // but since we didn't specify them in model, we can add them to schema dynamically or update model!)
    // Wait, let's look at the model User.js: we only have username, email, password, fullname, bio, profileImage, coverImage, followers, following.
    // If the user wants location/website, we should update the model to include them! Let's check:
    // User Profile page description: Username, Full Name, Bio, Location, Website, Followers Count, Following Count, Total Posts.
    // Yes! Let's make sure our User model includes location and website.
    // I can modify the User.js model later or just set them here. Let's make sure we edit models/User.js to include location & website.
    // Wait! Let's first make sure we write the updateUser controller, and we'll edit User.js right after.
    // Let's add location/website if they exist on the User document.
    // Yes, we will save:
    // user.location = location || '';
    // user.website = website || '';
    // This is clean. We can add them to schema in User.js as well.
    // File uploads: check if files are uploaded
    if (req.files) {
      if (req.files.profileImage && req.files.profileImage[0]) {
        // Delete old profile image if exists and not default
        if (user.profileImage && !user.profileImage.startsWith('http')) {
          const oldPath = path.join(__dirname, '..', user.profileImage);
          if (fs.existsSync(oldPath)) fs.unlinkSync(oldPath);
        }
        user.profileImage = `/uploads/${req.files.profileImage[0].filename}`;
      }

      if (req.files.coverImage && req.files.coverImage[0]) {
        // Delete old cover image if exists
        if (user.coverImage && !user.coverImage.startsWith('http')) {
          const oldPath = path.join(__dirname, '..', user.coverImage);
          if (fs.existsSync(oldPath)) fs.unlinkSync(oldPath);
        }
        user.coverImage = `/uploads/${req.files.coverImage[0].filename}`;
      }
    }

    // Let's store location and website if they are specified
    user.set('location', location !== undefined ? location.trim() : user.get('location'));
    user.set('website', website !== undefined ? website.trim() : user.get('website'));

    await user.save();

    res.json({
      _id: user._id,
      username: user.username,
      email: user.email,
      fullname: user.fullname,
      bio: user.bio,
      location: user.get('location'),
      website: user.get('website'),
      profileImage: user.profileImage,
      coverImage: user.coverImage,
      followersCount: user.followers.length,
      followingCount: user.following.length,
    });
  } catch (err) {
    console.error('Update user error:', err);
    res.status(500).json({ message: 'Server error updating profile.' });
  }
};

// @desc    Delete user profile and cascading contents
// @route   DELETE /api/users/:id
// @access  Private
exports.deleteUser = async (req, res) => {
  try {
    if (req.user._id.toString() !== req.params.id) {
      return res.status(403).json({ message: 'You can only delete your own profile.' });
    }

    const user = await User.findById(req.params.id);
    if (!user) {
      return res.status(404).json({ message: 'User not found.' });
    }

    // 1. Delete all posts and their comments, files
    const posts = await Post.find({ userId: user._id });
    for (const post of posts) {
      // delete post image files from local disk
      for (const img of post.images) {
        if (img && !img.startsWith('http')) {
          const imgPath = path.join(__dirname, '..', img);
          if (fs.existsSync(imgPath)) fs.unlinkSync(imgPath);
        }
      }
      // delete comments for post
      await Comment.deleteMany({ postId: post._id });
    }
    await Post.deleteMany({ userId: user._id });

    // 2. Delete user's comments on other posts
    await Comment.deleteMany({ userId: user._id });

    // 3. Delete notifications relating to this user
    await Notification.deleteMany({
      $or: [{ recipientId: user._id }, { senderId: user._id }]
    });

    // 4. Delete followers/following relations in Followers collection
    await Follower.deleteMany({
      $or: [{ followerId: user._id }, { followingId: user._id }]
    });

    // Remove user ID from all other users' followers & following arrays
    await User.updateMany(
      { followers: user._id },
      { $pull: { followers: user._id } }
    );
    await User.updateMany(
      { following: user._id },
      { $pull: { following: user._id } }
    );

    // Delete profile and cover images
    if (user.profileImage && !user.profileImage.startsWith('http')) {
      const path1 = path.join(__dirname, '..', user.profileImage);
      if (fs.existsSync(path1)) fs.unlinkSync(path1);
    }
    if (user.coverImage && !user.coverImage.startsWith('http')) {
      const path2 = path.join(__dirname, '..', user.coverImage);
      if (fs.existsSync(path2)) fs.unlinkSync(path2);
    }

    // 5. Delete user document
    await User.findByIdAndDelete(user._id);

    res.json({ message: 'User profile and all associated data deleted successfully.' });
  } catch (err) {
    console.error('Delete user error:', err);
    res.status(500).json({ message: 'Server error deleting user profile.' });
  }
};

// @desc    Get user dashboard stats and recent activity
// @route   GET /api/users/:id/dashboard
// @access  Private
exports.getUserDashboard = async (req, res) => {
  try {
    const userId = req.params.id;

    // Verify self
    if (req.user._id.toString() !== userId) {
      return res.status(403).json({ message: 'Access denied.' });
    }

    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ message: 'User not found.' });
    }

    // Aggregate counts
    const totalPosts = await Post.countDocuments({ userId: user._id });
    const followersCount = user.followers.length;
    const followingCount = user.following.length;

    // Notification summary
    const totalNotifications = await Notification.countDocuments({ recipientId: userId });
    const unreadNotifications = await Notification.countDocuments({ recipientId: userId, read: false });

    // Recent Activity (retrieve last 5 notifications)
    const recentActivity = await Notification.find({ recipientId: userId })
      .sort({ createdAt: -1 })
      .limit(5)
      .populate('senderId', 'username fullname profileImage')
      .populate('postId', 'caption');

    res.json({
      stats: {
        totalPosts,
        followersCount,
        followingCount,
        unreadNotifications,
        totalNotifications,
      },
      recentActivity,
    });
  } catch (err) {
    console.error('Dashboard error:', err);
    res.status(500).json({ message: 'Server error retrieving dashboard stats.' });
  }
};
