const Post = require('../models/Post');
const Comment = require('../models/Comment');
const Notification = require('../models/Notification');
const User = require('../models/User');
const fs = require('fs');
const path = require('path');

// @desc    Get home feed posts (paginated)
// @route   GET /api/posts
// @access  Private
exports.getPosts = async (req, res) => {
  try {
    const limit = parseInt(req.query.limit) || 5;
    const skip = parseInt(req.query.skip) || 0;

    let query = {};
    if (req.query.userId) {
      query = { userId: req.query.userId };
    } else if (req.query.id) {
      query = { _id: req.query.id };
    } else {
      const feedUserIds = [...req.user.following, req.user._id];
      query = { userId: { $in: feedUserIds } };
    }
    query.type = { $ne: 'reel' };

    let posts = await Post.find(query)
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limit)
      .populate('userId', 'username fullname profileImage')
      .populate({
        path: 'comments',
        options: { sort: { createdAt: -1 } },
        populate: { path: 'userId', select: 'username fullname profileImage' }
      });

    if (posts.length === 0 && skip === 0 && !req.query.userId && !req.query.id) {
      posts = await Post.find({ type: { $ne: 'reel' } })
        .sort({ createdAt: -1 })
        .limit(limit)
        .populate('userId', 'username fullname profileImage')
        .populate({
          path: 'comments',
          options: { sort: { createdAt: -1 } },
          populate: { path: 'userId', select: 'username fullname profileImage' }
        });
    }

    res.json(posts);
  } catch (err) {
    console.error('Get posts error:', err);
    res.status(500).json({ message: 'Server error retrieving feed.' });
  }
};

// @desc    Create a new post
// @route   POST /api/posts
// @access  Private
exports.createPost = async (req, res) => {
  try {
    const { caption } = req.body;
    const images = [];

    if (req.files && req.files.length > 0) {
      req.files.forEach(file => {
        images.push(`/uploads/${file.filename}`);
      });
    }

    if (images.length === 0 && !caption) {
      return res.status(400).json({ message: 'Post must contain either a caption or at least one image.' });
    }

    const post = await Post.create({
      userId: req.user._id,
      caption: caption || '',
      images,
    });

    const populatedPost = await Post.findById(post._id)
      .populate('userId', 'username fullname profileImage');

    res.status(201).json(populatedPost);
  } catch (err) {
    console.error('Create post error:', err);
    res.status(500).json({ message: 'Server error creating post.' });
  }
};

// @desc    Update a post caption
// @route   PUT /api/posts/:id
// @access  Private
exports.updatePost = async (req, res) => {
  try {
    const post = await Post.findById(req.params.id);
    if (!post) {
      return res.status(404).json({ message: 'Post not found.' });
    }

    // Check ownership
    if (post.userId.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: 'Access denied. You do not own this post.' });
    }

    post.caption = req.body.caption || '';
    await post.save();

    const populatedPost = await Post.findById(post._id)
      .populate('userId', 'username fullname profileImage')
      .populate({
        path: 'comments',
        populate: { path: 'userId', select: 'username fullname profileImage' }
      });

    res.json(populatedPost);
  } catch (err) {
    console.error('Update post error:', err);
    res.status(500).json({ message: 'Server error updating post.' });
  }
};

// @desc    Delete a post
// @route   DELETE /api/posts/:id
// @access  Private
exports.deletePost = async (req, res) => {
  try {
    const post = await Post.findById(req.params.id);
    if (!post) {
      return res.status(404).json({ message: 'Post not found.' });
    }

    // Check ownership
    if (post.userId.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: 'Access denied. You do not own this post.' });
    }

    // Delete associated image files
    post.images.forEach(img => {
      if (img && !img.startsWith('http')) {
        const filePath = path.join(__dirname, '..', img);
        if (fs.existsSync(filePath)) {
          fs.unlinkSync(filePath);
        }
      }
    });

    // Delete associated comments
    await Comment.deleteMany({ postId: post._id });

    // Delete notifications associated with this post
    await Notification.deleteMany({ postId: post._id });

    // Delete post document
    await Post.findByIdAndDelete(post._id);

    res.json({ message: 'Post deleted successfully.', postId: post._id });
  } catch (err) {
    console.error('Delete post error:', err);
    res.status(500).json({ message: 'Server error deleting post.' });
  }
};

// @desc    Like a post
// @route   POST /api/posts/:id/like
// @access  Private
exports.likePost = async (req, res) => {
  try {
    const post = await Post.findById(req.params.id);
    if (!post) {
      return res.status(404).json({ message: 'Post not found.' });
    }

    // Check if already liked
    if (post.likes.includes(req.user._id)) {
      return res.status(400).json({ message: 'Post already liked.' });
    }

    post.likes.push(req.user._id);
    await post.save();

    // Create Notification if liking someone else's post
    if (post.userId.toString() !== req.user._id.toString()) {
      await Notification.create({
        recipientId: post.userId,
        senderId: req.user._id,
        type: 'like',
        postId: post._id,
      });
    }

    res.json({ message: 'Post liked.', likesCount: post.likes.length, likes: post.likes });
  } catch (err) {
    console.error('Like post error:', err);
    res.status(500).json({ message: 'Server error liking post.' });
  }
};

// @desc    Unlike a post
// @route   DELETE /api/posts/:id/unlike
// @access  Private
exports.unlikePost = async (req, res) => {
  try {
    const post = await Post.findById(req.params.id);
    if (!post) {
      return res.status(404).json({ message: 'Post not found.' });
    }

    // Check if liked
    if (!post.likes.includes(req.user._id)) {
      return res.status(400).json({ message: 'Post has not been liked.' });
    }

    post.likes = post.likes.filter(id => id.toString() !== req.user._id.toString());
    await post.save();

    // Remove notification if exists
    await Notification.deleteMany({
      recipientId: post.userId,
      senderId: req.user._id,
      type: 'like',
      postId: post._id,
    });

    res.json({ message: 'Post unliked.', likesCount: post.likes.length, likes: post.likes });
  } catch (err) {
    console.error('Unlike post error:', err);
    res.status(500).json({ message: 'Server error unliking post.' });
  }
};

// @desc    Generate AI caption for an uploaded image
// @route   POST /api/posts/generate-caption
// @access  Private
exports.generateCaption = async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ message: 'Please upload an image to analyze.' });
    }

    const tempFilePath = req.file.path;
    const apiKey = process.env.GEMINI_API_KEY;

    if (apiKey) {
      console.log('Generating caption using Gemini API...');
      const { GoogleGenerativeAI } = require('@google/generative-ai');
      const genAI = new GoogleGenerativeAI(apiKey);
      const model = genAI.getGenerativeModel({ model: 'gemini-1.5-flash' });

      const fileToGenerativePart = (filePath, mimeType) => {
        return {
          inlineData: {
            data: Buffer.from(fs.readFileSync(filePath)).toString('base64'),
            mimeType,
          },
        };
      };

      const imagePart = fileToGenerativePart(tempFilePath, req.file.mimetype);
      const prompt = 'Analyze this image and generate a creative, engaging, and modern social media caption for a platform like Instagram. Keep it concise, natural, and friendly. Add 2-3 relevant hashtags.';
      
      const result = await model.generateContent([prompt, imagePart]);
      const response = await result.response;
      const text = response.text();

      if (fs.existsSync(tempFilePath)) {
        fs.unlinkSync(tempFilePath);
      }

      res.json({ caption: text.trim() });
    } else {
      console.log('No Gemini API key configured. Returning simulated sandbox caption...');
      
      const sandboxCaptions = [
        'Chasing sunbeams and living in the moment. ✨ #goodvibes #lifestyle',
        'Aesthetic check. Rate this view 1-10! 📸 #aesthetic #explore',
        'Coffee first, questions later. ☕️ #morningroutine #vibes',
        'Just another day of creating magic. 💫 #inspiration #connected',
        'Minimalism is not about having less. It\'s about making space for what matters. 🌿 #minimalist #mindful',
        'Creating memories that will last a lifetime. 💛 #naturelovers #adventure',
        'Details. Zoom in for details. 🔍 #aesthetic #closeup',
        'Cozy corner details. Today\'s mood. ☕️📖 #cozyvibes #weekendmode'
      ];
      
      const randomIndex = Math.floor(Math.random() * sandboxCaptions.length);
      const selectedCaption = sandboxCaptions[randomIndex];

      if (fs.existsSync(tempFilePath)) {
        fs.unlinkSync(tempFilePath);
      }

      await new Promise(resolve => setTimeout(resolve, 1500));

      res.json({ caption: selectedCaption });
    }
  } catch (err) {
    console.error('AI Caption generation error:', err);
    if (req.file && fs.existsSync(req.file.path)) {
      fs.unlinkSync(req.file.path);
    }
    res.status(500).json({ message: 'Failed to generate AI caption.' });
  }
};

// @desc    Get reels (video posts)
// @route   GET /api/reels
// @access  Private
exports.getReels = async (req, res) => {
  try {
    const limit = parseInt(req.query.limit) || 10;
    const skip = parseInt(req.query.skip) || 0;
    
    let query = { type: 'reel' };
    if (req.query.userId) {
      query.userId = req.query.userId;
    }

    const reels = await Post.find(query)
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limit)
      .populate('userId', 'username fullname profileImage')
      .populate({
        path: 'comments',
        options: { sort: { createdAt: -1 } },
        populate: { path: 'userId', select: 'username fullname profileImage' }
      });

    res.json(reels);
  } catch (err) {
    console.error('Get reels error:', err);
    res.status(500).json({ message: 'Server error retrieving reels.' });
  }
};

// @desc    Create a new reel
// @route   POST /api/reels
// @access  Private
exports.createReel = async (req, res) => {
  try {
    const { caption } = req.body;
    if (!req.file) {
      return res.status(400).json({ message: 'Please upload a video file for your reel.' });
    }

    const videoUrl = `/uploads/${req.file.filename}`;

    const newReel = await Post.create({
      userId: req.user._id,
      caption: caption || '',
      videoUrl,
      type: 'reel',
      images: []
    });

    const populatedReel = await Post.findById(newReel._id).populate('userId', 'username fullname profileImage');
    res.status(201).json(populatedReel);
  } catch (err) {
    console.error('Create reel error:', err);
    res.status(500).json({ message: 'Server error creating reel.' });
  }
};
