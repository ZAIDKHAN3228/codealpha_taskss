const User = require('../models/User');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { OAuth2Client } = require('google-auth-library');
const mongoose = require('mongoose');

// Generate JWT Helper
const generateToken = (id) => {
  const secret = process.env.JWT_SECRET || 'snaploop_default_jwt_secret_key_change_me_in_production';
  return jwt.sign({ id }, secret, {
    expiresIn: '30d',
  });
};

// @desc    Register a new user
// @route   POST /api/auth/register
// @access  Public
exports.register = async (req, res) => {
  try {
    const { username, email, password, fullname } = req.body;

    if (!username || !email || !password || !fullname) {
      return res.status(400).json({ message: 'Please enter all required fields.' });
    }

    // Check if user exists
    const emailExists = await User.findOne({ email });
    if (emailExists) {
      return res.status(400).json({ message: 'Email is already registered.' });
    }

    const usernameExists = await User.findOne({ username });
    if (usernameExists) {
      return res.status(400).json({ message: 'Username is already taken.' });
    }

    // Hash password
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    // Create user
    const user = await User.create({
      username: username.toLowerCase().trim(),
      email: email.toLowerCase().trim(),
      password: hashedPassword,
      fullname: fullname.trim(),
    });

    if (user) {
      res.status(201).json({
        _id: user._id,
        username: user.username,
        email: user.email,
        fullname: user.fullname,
        token: generateToken(user._id),
      });
    } else {
      res.status(400).json({ message: 'Invalid user data.' });
    }
  } catch (err) {
    console.error('Register error:', err);
    if (mongoose.connection.readyState !== 1) {
      return res.status(500).json({ message: 'Database connection is offline. Please check MONGODB_URI on Vercel and ensure IP addresses (0.0.0.0/0) are whitelisted on MongoDB Atlas.' });
    }
    res.status(500).json({ message: 'Server error during registration.' });
  }
};

// @desc    Login user
// @route   POST /api/auth/login
// @access  Public
exports.login = async (req, res) => {
  try {
    const { emailOrUsername, password } = req.body;

    if (!emailOrUsername || !password) {
      return res.status(400).json({ message: 'Please enter all fields.' });
    }

    // Find by email or username
    const cleanInput = emailOrUsername.toLowerCase().trim();
    const user = await User.findOne({
      $or: [{ email: cleanInput }, { username: cleanInput }]
    });

    if (!user) {
      return res.status(400).json({ message: 'Invalid credentials.' });
    }

    // Check password
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(400).json({ message: 'Invalid credentials.' });
    }

    res.json({
      _id: user._id,
      username: user.username,
      email: user.email,
      fullname: user.fullname,
      bio: user.bio,
      profileImage: user.profileImage,
      coverImage: user.coverImage,
      followersCount: user.followers.length,
      followingCount: user.following.length,
      token: generateToken(user._id),
    });
  } catch (err) {
    console.error('Login error:', err);
    if (mongoose.connection.readyState !== 1) {
      return res.status(500).json({ message: 'Database connection is offline. Please check MONGODB_URI on Vercel and ensure IP addresses (0.0.0.0/0) are whitelisted on MongoDB Atlas.' });
    }
    res.status(500).json({ message: 'Server error during login.' });
  }
};

// @desc    Logout user
// @route   POST /api/auth/logout
// @access  Public
exports.logout = async (req, res) => {
  // Stateless JWT doesn't need server session destruction, 
  // but client will delete the token. We respond success.
  res.json({ message: 'Successfully logged out.' });
};

// @desc    Get Google client ID configuration
// @route   GET /api/auth/google/config
// @access  Public
exports.googleConfig = async (req, res) => {
  res.json({ clientId: process.env.GOOGLE_CLIENT_ID || '' });
};

// @desc    Sign in / Sign up with Google OAuth token
// @route   POST /api/auth/google
// @access  Public
exports.googleLogin = async (req, res) => {
  try {
    const { credential } = req.body;
    if (!credential) {
      return res.status(400).json({ message: 'Google credential token is required.' });
    }

    let payload = null;
    const clientId = process.env.GOOGLE_CLIENT_ID;

    if (credential.startsWith('mock_google_token') || !clientId) {
      console.log('Verifying token in Google Sandbox/Offline mode...');
      let parts = credential.split('::');
      const email = parts[1] || 'sandbox@snaploop.com';
      const name = parts[2] || 'Sandbox User';
      const sub = parts[3] || 'google-sandbox-12345';
      const picture = parts[4] || '';
      
      payload = {
        email: email.toLowerCase().trim(),
        name: name,
        sub: sub,
        picture: picture
      };
    } else {
      const client = new OAuth2Client(clientId);
      const ticket = await client.verifyIdToken({
        idToken: credential,
        audience: clientId,
      });
      payload = ticket.getPayload();
    }

    if (!payload || !payload.email) {
      return res.status(400).json({ message: 'Invalid Google identity token.' });
    }

    const { email, name, sub, picture } = payload;

    let user = await User.findOne({ $or: [{ googleId: sub }, { email }] });

    if (user) {
      if (!user.googleId) {
        user.googleId = sub;
      }
      if (!user.profileImage && picture) {
        user.profileImage = picture;
      }
      await user.save();
    } else {
      let baseUsername = email.split('@')[0].replace(/[^a-zA-Z0-9]/g, '').toLowerCase();
      let uniqueUsername = baseUsername;
      let count = 1;
      
      while (await User.findOne({ username: uniqueUsername })) {
        uniqueUsername = `${baseUsername}${count}`;
        count++;
      }

      user = await User.create({
        username: uniqueUsername,
        email: email,
        fullname: name,
        googleId: sub,
        profileImage: picture || '',
      });
    }

    res.json({
      _id: user._id,
      username: user.username,
      email: user.email,
      fullname: user.fullname,
      bio: user.bio,
      profileImage: user.profileImage,
      coverImage: user.coverImage,
      followersCount: user.followers.length,
      followingCount: user.following.length,
      token: generateToken(user._id),
    });

  } catch (err) {
    console.error('Google Sign-In backend verification failed:', err);
    res.status(500).json({ message: 'Google Sign-In authentication failed.' });
  }
};
