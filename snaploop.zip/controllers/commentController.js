const Comment = require('../models/Comment');
const Post = require('../models/Post');
const Notification = require('../models/Notification');

// @desc    Add a comment to a post
// @route   POST /api/comments
// @access  Private
exports.addComment = async (req, res) => {
  try {
    const { postId, comment } = req.body;

    if (!postId || !comment || !comment.trim()) {
      return res.status(400).json({ message: 'Comment text and postId are required.' });
    }

    const post = await Post.findById(postId);
    if (!post) {
      return res.status(404).json({ message: 'Post not found.' });
    }

    const newComment = await Comment.create({
      postId,
      userId: req.user._id,
      comment: comment.trim(),
    });

    // Reference comment in post
    post.comments.push(newComment._id);
    await post.save();

    // Create Notification if commenting on someone else's post
    if (post.userId.toString() !== req.user._id.toString()) {
      await Notification.create({
        recipientId: post.userId,
        senderId: req.user._id,
        type: 'comment',
        postId: post._id,
        commentText: comment.trim().substring(0, 100), // truncate long comments in notification
      });
    }

    const populatedComment = await Comment.findById(newComment._id)
      .populate('userId', 'username fullname profileImage');

    res.status(201).json(populatedComment);
  } catch (err) {
    console.error('Add comment error:', err);
    res.status(500).json({ message: 'Server error adding comment.' });
  }
};

// @desc    Update a comment
// @route   PUT /api/comments/:id
// @access  Private
exports.updateComment = async (req, res) => {
  try {
    const commentDoc = await Comment.findById(req.params.id);
    if (!commentDoc) {
      return res.status(404).json({ message: 'Comment not found.' });
    }

    // Check ownership
    if (commentDoc.userId.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: 'Access denied. You do not own this comment.' });
    }

    const { comment } = req.body;
    if (!comment || !comment.trim()) {
      return res.status(400).json({ message: 'Comment text is required.' });
    }

    commentDoc.comment = comment.trim();
    await commentDoc.save();

    const populatedComment = await Comment.findById(commentDoc._id)
      .populate('userId', 'username fullname profileImage');

    res.json(populatedComment);
  } catch (err) {
    console.error('Update comment error:', err);
    res.status(500).json({ message: 'Server error updating comment.' });
  }
};

// @desc    Delete a comment
// @route   DELETE /api/comments/:id
// @access  Private
exports.deleteComment = async (req, res) => {
  try {
    const commentDoc = await Comment.findById(req.params.id);
    if (!commentDoc) {
      return res.status(404).json({ message: 'Comment not found.' });
    }

    const post = await Post.findById(commentDoc.postId);
    if (!post) {
      return res.status(404).json({ message: 'Post associated with this comment not found.' });
    }

    // Check ownership: comment author OR post author can delete it
    const isCommentOwner = commentDoc.userId.toString() === req.user._id.toString();
    const isPostOwner = post.userId.toString() === req.user._id.toString();

    if (!isCommentOwner && !isPostOwner) {
      return res.status(403).json({ message: 'Access denied. Unauthorized to delete this comment.' });
    }

    // Remove from post comments array
    post.comments = post.comments.filter(id => id.toString() !== commentDoc._id.toString());
    await post.save();

    // Remove notification if exists
    await Notification.deleteMany({
      recipientId: post.userId,
      senderId: commentDoc.userId,
      type: 'comment',
      postId: post._id,
    });

    // Delete comment document
    await Comment.findByIdAndDelete(commentDoc._id);

    res.json({ message: 'Comment deleted successfully.', commentId: commentDoc._id });
  } catch (err) {
    console.error('Delete comment error:', err);
    res.status(500).json({ message: 'Server error deleting comment.' });
  }
};
