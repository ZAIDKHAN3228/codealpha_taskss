const User = require('../models/User');
const Follower = require('../models/Follower');
const Notification = require('../models/Notification');

// @desc    Follow a user
// @route   POST /api/follow/:id
// @access  Private
exports.followUser = async (req, res) => {
  try {
    const targetUserId = req.params.id;
    const currentUserId = req.user._id;

    if (targetUserId === currentUserId.toString()) {
      return res.status(400).json({ message: 'You cannot follow yourself.' });
    }

    const targetUser = await User.findById(targetUserId);
    if (!targetUser) {
      return res.status(404).json({ message: 'User to follow not found.' });
    }

    // Check if already following
    const isAlreadyFollowing = req.user.following.includes(targetUserId);
    if (isAlreadyFollowing) {
      return res.status(400).json({ message: 'You are already following this user.' });
    }

    // Update current user's following list
    await User.findByIdAndUpdate(currentUserId, { $push: { following: targetUserId } });
    
    // Update target user's followers list
    await User.findByIdAndUpdate(targetUserId, { $push: { followers: currentUserId } });

    // Record in Followers collection
    await Follower.create({
      followerId: currentUserId,
      followingId: targetUserId,
    });

    // Create Notification
    await Notification.create({
      recipientId: targetUserId,
      senderId: currentUserId,
      type: 'follow',
    });

    res.json({ message: 'Successfully followed user.', targetUserId });
  } catch (err) {
    console.error('Follow error:', err);
    res.status(500).json({ message: 'Server error following user.' });
  }
};

// @desc    Unfollow a user
// @route   DELETE /api/unfollow/:id
// @access  Private
exports.unfollowUser = async (req, res) => {
  try {
    const targetUserId = req.params.id;
    const currentUserId = req.user._id;

    const targetUser = await User.findById(targetUserId);
    if (!targetUser) {
      return res.status(404).json({ message: 'User to unfollow not found.' });
    }

    // Check if following
    const isFollowing = req.user.following.includes(targetUserId);
    if (!isFollowing) {
      return res.status(400).json({ message: 'You are not following this user.' });
    }

    // Update current user following list
    await User.findByIdAndUpdate(currentUserId, { $pull: { following: targetUserId } });

    // Update target user followers list
    await User.findByIdAndUpdate(targetUserId, { $pull: { followers: currentUserId } });

    // Remove from Followers collection
    await Follower.deleteOne({
      followerId: currentUserId,
      followingId: targetUserId,
    });

    // Remove Notification
    await Notification.deleteMany({
      recipientId: targetUserId,
      senderId: currentUserId,
      type: 'follow',
    });

    res.json({ message: 'Successfully unfollowed user.', targetUserId });
  } catch (err) {
    console.error('Unfollow error:', err);
    res.status(500).json({ message: 'Server error unfollowing user.' });
  }
};
