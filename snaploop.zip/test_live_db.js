const https = require('https');

const payload = JSON.stringify({
  fullname: 'Live Verification Tester',
  username: 'livetester_' + Math.floor(Math.random() * 100000),
  email: `livetester_${Math.floor(Math.random() * 100000)}@test.com`,
  password: 'password123'
});

const options = {
  hostname: 'snaploop.vercel.app',
  port: 443,
  path: '/api/auth/register',
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Content-Length': Buffer.byteLength(payload)
  }
};

console.log('Sending registration request to live server https://snaploop.vercel.app...');

const req = https.request(options, (res) => {
  let body = '';
  res.setEncoding('utf8');
  res.on('data', (chunk) => body += chunk);
  res.on('end', () => {
    console.log('STATUS CODE:', res.statusCode);
    console.log('RESPONSE:', body);
    if (res.statusCode === 201) {
      console.log('SUCCESS! Registration completed successfully on the live database!');
      process.exit(0);
    } else {
      console.error('FAILED: Registration returned status code ' + res.statusCode);
      process.exit(1);
    }
  });
});

req.on('error', (err) => {
  console.error('REQUEST ERROR:', err.message);
  process.exit(1);
});

req.write(payload);
req.end();
