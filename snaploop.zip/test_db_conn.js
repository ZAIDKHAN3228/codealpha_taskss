const mongoose = require('mongoose');

const URI = 'mongodb+srv://snaploop_user:SnapLoopUserPass2026@cluster0.pwyxs.mongodb.net/snaploop_db?retryWrites=true&w=majority';

async function testConn() {
  try {
    console.log('Attempting to connect to cluster0.pwyxs.mongodb.net...');
    await mongoose.connect(URI, {
      serverSelectionTimeoutMS: 5000
    });
    console.log('SUCCESS! Connected to remote MongoDB Atlas cluster!');
    await mongoose.disconnect();
    process.exit(0);
  } catch (err) {
    console.error('CONNECTION FAILED:', err.message);
    process.exit(1);
  }
}

testConn();
