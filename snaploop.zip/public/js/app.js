// SnapLoop Application Shell Controller
const state = {
  currentUser: null,
  isLoggedIn: false,
  theme: localStorage.getItem('snaploop_theme') || 'light',
  currentRoute: '',
  filesToUpload: [], // for creating post
  feedSkip: 0,
  feedLimit: 5,
  feedLoading: false,
  feedHasMore: true,
  activeCommentPostId: null,
  activeEditPostId: null
};

// --- TOAST NOTIFICATIONS ---
function showToast(message, type = 'info') {
  const container = document.getElementById('toast-container');
  if (!container) return;

  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  
  let icon = 'fa-circle-info';
  if (type === 'success') icon = 'fa-circle-check';
  if (type === 'error') icon = 'fa-triangle-exclamation';

  toast.innerHTML = `
    <i class="fa-solid ${icon} toast-icon"></i>
    <span>${message}</span>
  `;

  container.appendChild(toast);
  
  // Trigger slide-in
  setTimeout(() => toast.classList.add('show'), 10);

  // Remove toast after 4s
  setTimeout(() => {
    toast.classList.remove('show');
    setTimeout(() => toast.remove(), 400);
  }, 4000);
}

// --- THEME MANAGEMENT ---
function initTheme() {
  document.documentElement.setAttribute('data-theme', state.theme);
  updateThemeIcons();
}

function toggleTheme() {
  state.theme = state.theme === 'light' ? 'dark' : 'light';
  localStorage.setItem('snaploop_theme', state.theme);
  document.documentElement.setAttribute('data-theme', state.theme);
  updateThemeIcons();
  showToast(`Switched to ${state.theme} mode`, 'info');
}

function updateThemeIcons() {
  const themeIcons = [
    document.querySelector('#theme-toggle i'),
    document.querySelector('#settings-theme-toggle i')
  ];
  themeIcons.forEach(icon => {
    if (!icon) return;
    if (state.theme === 'dark') {
      icon.className = 'fa-solid fa-sun';
    } else {
      icon.className = 'fa-solid fa-moon';
    }
  });
}

// --- APP LAYOUT CONTROLLER ---
function toggleAppLayout(showLayout) {
  const sidebar = document.getElementById('desktop-sidebar');
  const header = document.getElementById('top-header');
  const bottomNav = document.getElementById('bottom-navbar');

  if (showLayout) {
    sidebar.classList.remove('hidden');
    header.classList.remove('hidden');
    bottomNav.classList.remove('hidden');
  } else {
    sidebar.classList.add('hidden');
    header.classList.add('hidden');
    bottomNav.classList.add('hidden');
  }
}

function updateNavigationActiveState(target) {
  // Sidebar items
  document.querySelectorAll('#desktop-sidebar .nav-item').forEach(item => {
    item.classList.remove('active');
    if (item.getAttribute('data-target') === target) {
      item.classList.add('active');
    }
  });

  // Bottom navbar items
  document.querySelectorAll('#bottom-navbar .bottom-nav-item').forEach(item => {
    item.classList.remove('active');
    if (item.getAttribute('data-target') === target) {
      item.classList.add('active');
    }
  });
}

function updateHeaderUserProfile() {
  if (!state.currentUser) return;
  
  const avatarUrl = state.currentUser.profileImage || 'https://api.dicebear.com/7.x/adventurer/svg?seed=' + state.currentUser.username;
  
  document.getElementById('quick-avatar-img').src = avatarUrl;
  document.getElementById('top-avatar-img').src = avatarUrl;
  document.getElementById('quick-profile-fullname').textContent = state.currentUser.fullname;
  document.getElementById('quick-profile-username').textContent = `@${state.currentUser.username}`;
  
  // Update links
  const profileHash = `#/profile/${state.currentUser._id}`;
  document.getElementById('sidebar-profile-link').href = profileHash;
  document.getElementById('top-profile-link').href = profileHash;
  document.getElementById('bottom-profile-link').href = profileHash;
}

// Check notification counts
async function checkUnreadNotifications() {
  if (!state.isLoggedIn) return;
  try {
    const data = await api.get(`/users/${state.currentUser._id}/dashboard`);
    const count = data.stats.unreadNotifications;
    
    const badges = [
      document.getElementById('notification-badge'),
      document.getElementById('mobile-notification-badge')
    ];
    
    badges.forEach(badge => {
      if (!badge) return;
      if (count > 0) {
        badge.textContent = count;
        badge.classList.remove('hidden');
      } else {
        badge.classList.add('hidden');
      }
    });
  } catch (err) {
    console.error('Check notification count failed:', err);
  }
}

// --- SPA ROUTER ---
const routes = {
  landing: 'landing-page',
  login: 'auth-page',
  register: 'auth-page',
  feed: 'feed-page',
  profile: 'profile-page',
  'edit-profile': 'edit-profile-page',
  notifications: 'notifications-page',
  search: 'search-page',
  settings: 'settings-page',
  'create-post': 'create-post-page',
  dashboard: 'dashboard-page',
  reels: 'reels-page',
  notfound: 'notfound-page'
};

async function router() {
  const hash = window.location.hash || '#/';
  state.currentRoute = hash;

  // Tidy modal windows on routing
  closeModal('comments-modal');
  closeModal('edit-post-modal');

  // Route matches
  let matchedView = 'feed';
  let routeParamId = null;

  if (hash === '#/') {
    matchedView = state.isLoggedIn ? 'feed' : 'landing';
  } else if (hash === '#/login') {
    matchedView = 'login';
  } else if (hash === '#/register') {
    matchedView = 'register';
  } else if (hash === '#/edit-profile') {
    matchedView = 'edit-profile';
  } else if (hash === '#/notifications') {
    matchedView = 'notifications';
  } else if (hash === '#/search') {
    matchedView = 'search';
  } else if (hash === '#/settings') {
    matchedView = 'settings';
  } else if (hash === '#/create-post') {
    matchedView = 'create-post';
  } else if (hash === '#/dashboard') {
    matchedView = 'dashboard';
  } else if (hash === '#/reels') {
    matchedView = 'reels';
  } else if (hash.startsWith('#/profile/')) {
    matchedView = 'profile';
    routeParamId = hash.split('#/profile/')[1];
  } else if (hash === '#/profile') {
    matchedView = 'profile';
    routeParamId = state.currentUser ? state.currentUser._id : null;
  } else {
    matchedView = 'notfound';
  }

  // Redirect checks
  const isAuthRestricted = ['feed', 'profile', 'edit-profile', 'notifications', 'search', 'settings', 'create-post', 'dashboard', 'reels'].includes(matchedView);
  if (isAuthRestricted && !state.isLoggedIn) {
    window.location.hash = '#/login';
    return;
  }

  if (['login', 'register', 'landing'].includes(matchedView) && state.isLoggedIn) {
    window.location.hash = '#/';
    return;
  }

  // Set navigation active state
  updateNavigationActiveState(matchedView);

  // Toggle layout visibility
  const hasAppLayout = state.isLoggedIn && matchedView !== 'notfound';
  toggleAppLayout(hasAppLayout);

  // Hide all section views, display matched view
  Object.values(routes).forEach(viewId => {
    document.getElementById(viewId).classList.add('hidden');
  });

  const targetViewId = routes[matchedView];
  document.getElementById(targetViewId).classList.remove('hidden');

  // Trigger login/register card flips
  if (matchedView === 'login') {
    document.getElementById('login-card').classList.remove('hidden');
    document.getElementById('register-card').classList.add('hidden');
  } else if (matchedView === 'register') {
    document.getElementById('login-card').classList.add('hidden');
    document.getElementById('register-card').classList.remove('hidden');
  }

  // Run render logics
  if (state.isLoggedIn) {
    checkUnreadNotifications();
    updateHeaderUserProfile();
  }

  switch (matchedView) {
    case 'feed':
      initFeedView();
      break;
    case 'profile':
      initProfileView(routeParamId);
      break;
    case 'edit-profile':
      initEditProfileView();
      break;
    case 'notifications':
      initNotificationsView();
      break;
    case 'search':
      initSearchView();
      break;
    case 'settings':
      initSettingsView();
      break;
    case 'create-post':
      initCreatePostView();
      break;
    case 'dashboard':
      initDashboardView();
      break;
    case 'reels':
      initReelsView();
      break;
  }
}

// --- AUTHENTICATION ACTIONS ---
async function handleLogin(e) {
  e.preventDefault();
  const emailOrUsername = document.getElementById('login-email').value;
  const password = document.getElementById('login-password').value;

  try {
    const data = await api.post('/auth/login', { emailOrUsername, password });
    api.setToken(data.token);
    state.currentUser = data;
    state.isLoggedIn = true;
    
    showToast('Logged in successfully', 'success');
    window.location.hash = '#/';
  } catch (err) {
    showToast(err.message, 'error');
  }
}

async function handleRegister(e) {
  e.preventDefault();
  const fullname = document.getElementById('reg-fullname').value;
  const username = document.getElementById('reg-username').value;
  const email = document.getElementById('reg-email').value;
  const password = document.getElementById('reg-password').value;

  try {
    const data = await api.post('/auth/register', { fullname, username, email, password });
    api.setToken(data.token);
    state.currentUser = data;
    state.isLoggedIn = true;
    
    showToast('Registered successfully', 'success');
    window.location.hash = '#/';
  } catch (err) {
    showToast(err.message, 'error');
  }
}

function handleLogout() {
  api.clearToken();
  state.currentUser = null;
  state.isLoggedIn = false;
  showToast('Logged out successfully', 'info');
  window.location.hash = '#/login';
}

// Bootstrapping session on page refresh
async function bootstrapApp() {
  const token = api.getToken();
  initTheme();
  
  if (token) {
    try {
      // Decode user details by calling users list/dashboard or self profile info
      // We'll call user profile using special payload, but let's query dashboard first or register /GET users self
      // Let's create an API GET /users/me in backend, but wait, we already have GET /users/:id. Let's decode ID from token or retrieve user details
      // Since our token has payload `{ id }`, how do we know the logged-in user id?
      // Our login API returned `_id`. We can store currentUser JSON in localStorage or do a quick lookup.
      // Let's fetch GET /api/users to find users, but since we don't know the user id, let's look up. Wait!
      // In controllers/authController.js, we return user details. We can store the user JSON in local storage as well for convenience!
      // Let's store user info in localStorage:
      const cachedUser = localStorage.getItem('snaploop_user');
      if (cachedUser) {
        state.currentUser = JSON.parse(cachedUser);
        state.isLoggedIn = true;
      } else {
        // Fallback: If no user cached, let's fetch self by decoded ID. 
        // We'll write the login process to cache the user document in localStorage.
        api.clearToken();
        state.isLoggedIn = false;
      }
    } catch (err) {
      console.error('App bootstrap failed:', err);
      api.clearToken();
      state.isLoggedIn = false;
    }
  }

  // Wait, let's make sure login & register processes save user info to localStorage
  const originalLogin = api.post;
  // We hook the login API response to update localStorage
  window.addEventListener('auth-expired', () => {
    localStorage.removeItem('snaploop_user');
    state.isLoggedIn = false;
    state.currentUser = null;
    router();
  });

  router();
  
  if (!state.isLoggedIn) {
    initGoogleSignIn();
  }
}

// Hooking api responses
const originalLoginAPI = api.post;
api.post = async function(url, body) {
  const data = await originalLoginAPI.call(this, url, body);
  if (url === '/auth/login' || url === '/auth/register' || url === '/auth/google') {
    localStorage.setItem('snaploop_user', JSON.stringify(data));
  }
  return data;
};

// --- GOOGLE SIGN IN OAUTH2 INTEGRATION ---
async function initGoogleSignIn() {
  try {
    const { clientId } = await api.get('/auth/google/config');
    
    // Fallback: If no client ID configured in backend environment, render Simulated Google Buttons
    if (!clientId) {
      renderSimulatedGoogleButtons();
      return;
    }
    
    // Verify that the global google GSI library is loaded
    if (typeof google === 'undefined' || !google.accounts) {
      console.log('Google Identity Services SDK not loaded yet. Retrying...');
      setTimeout(initGoogleSignIn, 1000);
      return;
    }
    
    google.accounts.id.initialize({
      client_id: clientId,
      callback: handleGoogleCredentialResponse
    });
    
    const loginBtn = document.getElementById('google-login-btn');
    const regBtn = document.getElementById('google-reg-btn');
    
    if (loginBtn) {
      google.accounts.id.renderButton(loginBtn, { theme: 'outline', size: 'large', width: 280, text: 'signin_with', shape: 'pill' });
    }
    if (regBtn) {
      google.accounts.id.renderButton(regBtn, { theme: 'outline', size: 'large', width: 280, text: 'signup_with', shape: 'pill' });
    }
    
  } catch (err) {
    console.error('Google Sign-In initialization failed:', err);
    renderSimulatedGoogleButtons(); // fallback to simulator
  }
}

function renderSimulatedGoogleButtons() {
  const loginBtn = document.getElementById('google-login-btn');
  const regBtn = document.getElementById('google-reg-btn');
  
  const clickHandler = () => {
    const email = prompt('Google SSO Sandbox: Enter mock email:', 'john@example.com');
    if (!email) return;
    const fullname = prompt('Google SSO Sandbox: Enter mock fullname:', 'John Doe');
    if (!fullname) return;
    const sub = 'google-sandbox-' + Math.floor(Math.random() * 1000000);
    const token = `mock_google_token::${email}::${fullname}::${sub}::https://api.dicebear.com/7.x/adventurer/svg?seed=${email.split('@')[0]}`;
    handleGoogleCredentialResponse({ credential: token });
  };

  const renderMockBtn = (el, text) => {
    if (!el) return;
    el.innerHTML = `
      <button type="button" class="btn btn-secondary" style="border-radius: 20px; font-size: 0.85rem; width: 100%; max-width: 280px; gap: 0.5rem; justify-content: center; border: 1px solid var(--border-color); background-color: var(--input-bg);">
        <i class="fa-brands fa-google" style="color: #4285F4;"></i>
        ${text}
      </button>
    `;
    el.querySelector('button').onclick = clickHandler;
  };

  renderMockBtn(loginBtn, 'Sign in with Google (Simulated)');
  renderMockBtn(regBtn, 'Sign up with Google (Simulated)');
}

async function handleGoogleCredentialResponse(response) {
  try {
    const data = await api.post('/auth/google', { credential: response.credential });
    
    api.setToken(data.token);
    state.currentUser = data;
    state.isLoggedIn = true;
    
    showToast(`Welcome to SnapLoop, ${data.fullname}!`, 'success');
    window.location.hash = '#/';
  } catch (err) {
    showToast(err.message, 'error');
  }
}

// --- VIEW RENDER LOGICS ---

// 1. HOME FEED VIEW
function initFeedView() {
  state.feedSkip = 0;
  state.feedHasMore = true;
  state.feedLoading = false;
  document.getElementById('feed-posts-container').innerHTML = '';
  document.getElementById('feed-end-message').classList.add('hidden');
  
  loadFeedPosts();
  setupInfiniteScroll();
}

async function loadFeedPosts() {
  if (state.feedLoading || !state.feedHasMore) return;
  state.feedLoading = true;
  
  const skeleton = document.getElementById('feed-loading-skeleton');
  skeleton.classList.remove('hidden');

  try {
    const posts = await api.get(`/posts?limit=${state.feedLimit}&skip=${state.feedSkip}`);
    
    skeleton.classList.add('hidden');
    state.feedLoading = false;

    if (posts.length < state.feedLimit) {
      state.feedHasMore = false;
      if (state.feedSkip > 0 || posts.length > 0) {
        document.getElementById('feed-end-message').classList.remove('hidden');
      }
    }

    if (posts.length === 0 && state.feedSkip === 0) {
      document.getElementById('feed-posts-container').innerHTML = `
        <div style="text-align: center; padding: 4rem 2rem; color: var(--text-muted);">
          <i class="fa-regular fa-folder-open" style="font-size: 3rem; margin-bottom: 1rem; color: var(--primary-color);"></i>
          <h3>No posts found</h3>
          <p style="margin-top: 0.5rem;">Be the first to share a moment! Or go to Search to follow other users.</p>
          <button class="btn btn-primary" onclick="window.location.hash = '#/create-post'" style="margin-top: 1.5rem; font-size: 0.85rem;">
            Create Post
          </button>
        </div>
      `;
      return;
    }

    posts.forEach(post => renderPostCard(post));
    state.feedSkip += posts.length;
  } catch (err) {
    state.feedLoading = false;
    skeleton.classList.add('hidden');
    showToast('Failed to load posts feed', 'error');
  }
}

function setupInfiniteScroll() {
  // Simple check on scroll height
  window.onscroll = () => {
    if (state.currentRoute !== '#/') return;
    if ((window.innerHeight + window.scrollY) >= document.documentElement.scrollHeight - 200) {
      loadFeedPosts();
    }
  };
}

function renderPostCard(post, containerId = 'feed-posts-container') {
  const container = document.getElementById(containerId);
  if (!container) return;

  const card = document.createElement('div');
  card.className = 'post-card';
  card.id = `post-${post._id}`;

  const isLiked = post.likes.includes(state.currentUser._id);
  const timeAgo = formatTimeAgo(post.createdAt);
  const avatarUrl = post.userId.profileImage || 'https://api.dicebear.com/7.x/adventurer/svg?seed=' + post.userId.username;

  // Ownership dropdown
  const isPostOwner = post.userId._id === state.currentUser._id;
  let actionsDropdown = '';
  if (isPostOwner) {
    actionsDropdown = `
      <div style="position: relative;">
        <i class="fa-solid fa-ellipsis post-dropdown-trigger" onclick="togglePostDropdown('${post._id}')"></i>
        <div class="post-dropdown-menu hidden" id="dropdown-${post._id}">
          <div class="post-dropdown-item" onclick="openEditPostCaptionModal('${post._id}', \`${escapeJSString(post.caption)}\`)">
            <i class="fa-solid fa-pen-to-square"></i> Edit
          </div>
          <div class="post-dropdown-item delete" onclick="deletePost('${post._id}')">
            <i class="fa-solid fa-trash"></i> Delete
          </div>
        </div>
      </div>
    `;
  }

  // Follow/Unfollow button on card if not self
  let followButton = '';
  if (!isPostOwner) {
    const isFollowing = state.currentUser.following.includes(post.userId._id);
    if (isFollowing) {
      followButton = `<button class="unfollow-btn-sm" onclick="toggleCardFollow('${post.userId._id}', this)">Following</button>`;
    } else {
      followButton = `<button class="follow-btn-sm" onclick="toggleCardFollow('${post.userId._id}', this)">Follow</button>`;
    }
  }

  // Carousel images
  let mediaCarousel = '';
  if (post.images && post.images.length > 0) {
    let slides = '';
    let indicators = '';
    
    post.images.forEach((img, index) => {
      slides += `
        <div class="carousel-slide ${index === 0 ? 'active' : ''}" data-index="${index}">
          <img src="${img}" alt="Post image" loading="lazy">
        </div>
      `;
      indicators += `<span class="indicator ${index === 0 ? 'active' : ''}" data-slide-to="${index}"></span>`;
    });

    const controls = post.images.length > 1 ? `
      <button class="carousel-btn prev" onclick="navigateCarousel('${post._id}', -1)"><i class="fa-solid fa-chevron-left"></i></button>
      <button class="carousel-btn next" onclick="navigateCarousel('${post._id}', 1)"><i class="fa-solid fa-chevron-right"></i></button>
    ` : '';

    const indicatorsContainer = post.images.length > 1 ? `
      <div class="carousel-indicators">
        ${indicators}
      </div>
    ` : '';

    mediaCarousel = `
      <div class="post-images-carousel" id="carousel-${post._id}">
        <div class="carousel-track-container">
          ${slides}
        </div>
        ${controls}
        ${indicatorsContainer}
      </div>
    `;
  }

  // Comments preview (show last 2 comments)
  let commentsPreviewHtml = '';
  if (post.comments && post.comments.length > 0) {
    const displayComments = post.comments.slice(0, 2);
    displayComments.forEach(comm => {
      const commAuthorAvatar = comm.userId.profileImage || 'https://api.dicebear.com/7.x/adventurer/svg?seed=' + comm.userId.username;
      
      let commDeleteBtn = '';
      const isCommentOwner = comm.userId._id === state.currentUser._id;
      if (isCommentOwner || isPostOwner) {
        commDeleteBtn = `<i class="fa-solid fa-trash-can comment-action-btn delete" onclick="deleteComment('${comm._id}', '${post._id}')" title="Delete comment"></i>`;
      }

      commentsPreviewHtml += `
        <div class="comment-item" id="comment-${comm._id}">
          <img src="${commAuthorAvatar}" class="comment-avatar" alt="Avatar">
          <div class="comment-body">
            <span class="comment-author" onclick="window.location.hash = '#/profile/${comm.userId._id}'">${comm.userId.username}</span>
            <span>${escapeHTML(comm.comment)}</span>
          </div>
          <div class="comment-actions">
            ${commDeleteBtn}
          </div>
        </div>
      `;
    });
  }

  const commentsLinkText = post.comments.length > 2 
    ? `View all ${post.comments.length} comments` 
    : (post.comments.length > 0 ? '' : 'No comments yet. Be the first to comment!');

  card.innerHTML = `
    <div class="post-header">
      <img src="${avatarUrl}" class="post-author-avatar" alt="${post.userId.username}" onclick="window.location.hash = '#/profile/${post.userId._id}'">
      <div class="post-meta">
        <a href="#/profile/${post.userId._id}" class="post-author-name">${post.userId.fullname}</a>
        <span class="post-time">${timeAgo}</span>
      </div>
      <div class="post-header-actions">
        ${followButton}
        ${actionsDropdown}
      </div>
    </div>
    
    <div class="post-caption">${escapeHTML(post.caption)}</div>
    
    ${mediaCarousel}
    
    <div class="post-actions">
      <button class="post-action-btn like ${isLiked ? 'liked' : ''}" onclick="toggleLikePost('${post._id}', this)">
        <i class="${isLiked ? 'fa-solid' : 'fa-regular'} fa-heart"></i>
        <span class="like-count">${post.likes.length}</span>
      </button>
      <button class="post-action-btn comment" onclick="openCommentsModal('${post._id}')">
        <i class="fa-regular fa-comment"></i>
        <span>${post.comments.length}</span>
      </button>
      <button class="post-action-btn save save-right" onclick="toggleSavePost(this)">
        <i class="fa-regular fa-bookmark"></i>
      </button>
    </div>
    
    <div class="post-comments-summary-btn" onclick="openCommentsModal('${post._id}')">
      ${commentsLinkText}
    </div>
    
    <div class="post-comments-list" id="card-comments-${post._id}">
      ${commentsPreviewHtml}
    </div>
    
    <div class="post-comment-input-bar">
      <input type="text" placeholder="Add a comment..." id="input-comm-${post._id}">
      <button onclick="submitComment('${post._id}')"><i class="fa-solid fa-paper-plane"></i></button>
    </div>
  `;

  container.appendChild(card);
}

// Dropdown toggle
function togglePostDropdown(postId) {
  const menu = document.getElementById(`dropdown-${postId}`);
  if (menu) {
    menu.classList.toggle('hidden');
    // Click outside handler to dismiss dropdown
    const closeMenu = (e) => {
      if (!e.target.classList.contains('post-dropdown-trigger')) {
        menu.classList.add('hidden');
        document.removeEventListener('click', closeMenu);
      }
    };
    document.addEventListener('click', closeMenu);
  }
}

// Carousel Navigation
function navigateCarousel(postId, dir) {
  const carousel = document.getElementById(`carousel-${postId}`);
  if (!carousel) return;

  const slides = carousel.querySelectorAll('.carousel-slide');
  const indicators = carousel.querySelectorAll('.indicator');
  let activeIndex = 0;

  slides.forEach((slide, index) => {
    if (slide.classList.contains('active')) {
      activeIndex = index;
    }
  });

  slides[activeIndex].classList.remove('active');
  indicators[activeIndex].classList.remove('active');

  let nextIndex = activeIndex + dir;
  if (nextIndex >= slides.length) nextIndex = 0;
  if (nextIndex < 0) nextIndex = slides.length - 1;

  slides[nextIndex].classList.add('active');
  indicators[nextIndex].classList.add('active');
}

// Like/Unlike post call
async function toggleLikePost(postId, btn) {
  const countSpan = btn.querySelector('.like-count');
  const icon = btn.querySelector('i');
  const isLiked = btn.classList.contains('liked');

  try {
    if (isLiked) {
      const data = await api.delete(`/posts/${postId}/unlike`);
      btn.classList.remove('liked');
      icon.className = 'fa-regular fa-heart';
      countSpan.textContent = data.likesCount;
    } else {
      const data = await api.post(`/posts/${postId}/like`);
      btn.classList.add('liked');
      icon.className = 'fa-solid fa-heart';
      countSpan.textContent = data.likesCount;
    }
  } catch (err) {
    showToast('Failed to process like action', 'error');
  }
}

// Follow/Unfollow user from Card
async function toggleCardFollow(targetUserId, btn) {
  const isFollowing = btn.classList.contains('unfollow-btn-sm') || btn.textContent === 'Following';
  
  try {
    if (isFollowing) {
      await api.delete(`/unfollow/${targetUserId}`);
      btn.className = 'follow-btn-sm';
      btn.textContent = 'Follow';
      
      // Update local state arrays
      state.currentUser.following = state.currentUser.following.filter(id => id !== targetUserId);
    } else {
      await api.post(`/follow/${targetUserId}`);
      btn.className = 'unfollow-btn-sm';
      btn.textContent = 'Following';
      
      state.currentUser.following.push(targetUserId);
    }
    // Update local storage representation
    localStorage.setItem('snaploop_user', JSON.stringify(state.currentUser));
  } catch (err) {
    showToast(err.message, 'error');
  }
}

// Mock save post
function toggleSavePost(btn) {
  btn.classList.toggle('saved');
  const icon = btn.querySelector('i');
  if (btn.classList.contains('saved')) {
    icon.className = 'fa-solid fa-bookmark';
    btn.style.color = 'var(--secondary-color)';
    showToast('Post saved to library', 'success');
  } else {
    icon.className = 'fa-regular fa-bookmark';
    btn.style.removeAttribute('style');
    showToast('Post removed from library', 'info');
  }
}

// Post deletion
async function deletePost(postId) {
  if (!confirm('Are you sure you want to delete this post permanently?')) return;
  try {
    await api.delete(`/posts/${postId}`);
    const card = document.getElementById(`post-${postId}`);
    if (card) {
      card.style.opacity = '0';
      card.style.transform = 'scale(0.9)';
      setTimeout(() => card.remove(), 400);
    }
    showToast('Post deleted successfully', 'success');
  } catch (err) {
    showToast(err.message, 'error');
  }
}

// Add comments from inline input
async function submitComment(postId) {
  const input = document.getElementById(`input-comm-${postId}`);
  const commentText = input.value;
  if (!commentText || !commentText.trim()) return;

  try {
    const comment = await api.post('/comments', { postId, comment: commentText });
    input.value = '';
    
    // Rerender comment preview on card
    const commentList = document.getElementById(`card-comments-${postId}`);
    const avatarUrl = comment.userId.profileImage || 'https://api.dicebear.com/7.x/adventurer/svg?seed=' + comment.userId.username;
    
    const newCommentHtml = `
      <div class="comment-item" id="comment-${comment._id}">
        <img src="${avatarUrl}" class="comment-avatar" alt="Avatar">
        <div class="comment-body">
          <span class="comment-author" onclick="window.location.hash = '#/profile/${comment.userId._id}'">${comment.userId.username}</span>
          <span>${escapeHTML(comment.comment)}</span>
        </div>
        <div class="comment-actions">
          <i class="fa-solid fa-trash-can comment-action-btn delete" onclick="deleteComment('${comment._id}', '${postId}')" title="Delete comment"></i>
        </div>
      </div>
    `;

    // Append comment dynamically
    commentList.insertAdjacentHTML('afterbegin', newCommentHtml);
    
    // Update counters on feed button
    const card = document.getElementById(`post-${postId}`);
    const commentBtnSpan = card.querySelector('.comment span');
    commentBtnSpan.textContent = parseInt(commentBtnSpan.textContent) + 1;
    
    showToast('Comment added', 'success');
  } catch (err) {
    showToast(err.message, 'error');
  }
}

// Delete comments
async function deleteComment(commentId, postId) {
  if (!confirm('Delete this comment?')) return;
  try {
    await api.delete(`/comments/${commentId}`);
    
    const item = document.getElementById(`comment-${commentId}`);
    if (item) item.remove();

    // Rerender count updates on post card
    const card = document.getElementById(`post-${postId}`);
    if (card) {
      const commentBtnSpan = card.querySelector('.comment span');
      commentBtnSpan.textContent = Math.max(0, parseInt(commentBtnSpan.textContent) - 1);
    }
    showToast('Comment deleted', 'info');
  } catch (err) {
    showToast(err.message, 'error');
  }
}

// Edit post caption modal
function openEditPostCaptionModal(postId, currentCaption) {
  state.activeEditPostId = postId;
  const modal = document.getElementById('edit-post-modal');
  const textarea = document.getElementById('modal-edit-caption-textarea');
  
  textarea.value = currentCaption;
  openModal('edit-post-modal');
}

// --- PROFILE VIEW ---
async function initProfileView(userId) {
  const isSelf = userId === state.currentUser._id;
  
  // Default Tabs resets
  document.querySelectorAll('.profile-tab').forEach(t => t.classList.remove('active'));
  document.getElementById('tab-posts-trigger').classList.add('active');
  document.getElementById('profile-tab-posts-content').classList.remove('hidden');
  document.getElementById('profile-tab-users-content').classList.add('hidden');
  
  try {
    const user = await api.get(`/users/${userId}`);
    
    // Fill user details
    const coverUrl = user.coverImage || 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=1000&auto=format&fit=crop&q=60';
    const avatarUrl = user.profileImage || 'https://api.dicebear.com/7.x/adventurer/svg?seed=' + user.username;
    
    document.getElementById('profile-cover-img').src = coverUrl;
    document.getElementById('profile-avatar-img').src = avatarUrl;
    document.getElementById('profile-fullname').textContent = user.fullname;
    document.getElementById('profile-username-tag').textContent = `@${user.username}`;
    document.getElementById('profile-bio-text').textContent = user.bio || 'No bio yet.';
    
    // Location & website displays
    const locBox = document.getElementById('profile-loc-container');
    const webBox = document.getElementById('profile-web-container');
    
    if (user.location) {
      locBox.classList.remove('hidden');
      document.getElementById('profile-location-text').textContent = user.location;
    } else {
      locBox.classList.add('hidden');
    }
    
    if (user.website) {
      webBox.classList.remove('hidden');
      const webLink = document.getElementById('profile-website-text');
      webLink.textContent = user.website.replace(/(^\w+:|^)\/\//, ''); // strip http
      webLink.href = user.website;
    } else {
      webBox.classList.add('hidden');
    }

    // Update stats val
    document.getElementById('profile-stat-posts-val').textContent = user.postsCount || 0;
    document.getElementById('profile-stat-followers-val').textContent = user.followers.length;
    document.getElementById('profile-stat-following-val').textContent = user.following.length;

    // Action button display
    const actionContainer = document.getElementById('profile-action-container');
    actionContainer.innerHTML = '';
    
    if (isSelf) {
      actionContainer.innerHTML = `
        <button class="btn btn-secondary" onclick="window.location.hash = '#/edit-profile'">
          <i class="fa-solid fa-user-gear"></i> Edit Profile
        </button>
      `;
    } else {
      const isFollowing = state.currentUser.following.includes(user._id);
      if (isFollowing) {
        actionContainer.innerHTML = `
          <button class="btn btn-secondary" onclick="toggleProfileFollow('${user._id}', this)">Unfollow</button>
        `;
      } else {
        actionContainer.innerHTML = `
          <button class="btn btn-primary" onclick="toggleProfileFollow('${user._id}', this)">Follow</button>
        `;
      }
    }

    // Fetch user posts
    loadProfilePosts(user._id);

    // Bind tab clicks
    document.getElementById('tab-posts-trigger').onclick = () => {
      toggleProfileTab('posts');
      loadProfilePosts(user._id);
    };
    
    document.getElementById('tab-followers-trigger').onclick = () => {
      toggleProfileTab('users');
      renderUserList(user.followers, 'Followers list empty.');
    };
    
    document.getElementById('tab-following-trigger').onclick = () => {
      toggleProfileTab('users');
      renderUserList(user.following, 'Not following anyone yet.');
    };
    
  } catch (err) {
    showToast('Failed to load profile details', 'error');
  }
}

// Follow toggle on Profile view
async function toggleProfileFollow(targetId, btn) {
  const isFollowing = btn.textContent === 'Unfollow';
  const followCountSpan = document.getElementById('profile-stat-followers-val');
  let count = parseInt(followCountSpan.textContent);

  try {
    if (isFollowing) {
      await api.delete(`/unfollow/${targetId}`);
      btn.className = 'btn btn-primary';
      btn.textContent = 'Follow';
      followCountSpan.textContent = Math.max(0, count - 1);
      state.currentUser.following = state.currentUser.following.filter(id => id !== targetId);
    } else {
      await api.post(`/follow/${targetId}`);
      btn.className = 'btn btn-secondary';
      btn.textContent = 'Unfollow';
      followCountSpan.textContent = count + 1;
      state.currentUser.following.push(targetId);
    }
    localStorage.setItem('snaploop_user', JSON.stringify(state.currentUser));
  } catch (err) {
    showToast(err.message, 'error');
  }
}

async function loadProfilePosts(userId) {
  const grid = document.getElementById('profile-tab-posts-content');
  grid.innerHTML = '<div class="skeleton-post" style="grid-column: 1/-1; height: 150px;"></div>';

  try {
    // In backend post model, how do we retrieve profile posts? 
    // We can fetch from posts and filter by userId on frontend, or support userId query in GET /api/posts.
    // Let's modify controllers/postController.js to support query param `userId`.
    // Wait, let's make sure it handles it or we've written posts API.
    // Let's write the front end query as: GET /api/posts?userId=id.
    // Yes! Let's check controllers/postController.js. We wrote getPosts which gets followed users + self. 
    // Wait! Let's verify if we need to filter on server. Yes, let's update controllers/postController.js to support fetching by userId!
    // But first, let's make the API request. We will query `/posts?userId=${userId}`.
    // Wait, we will verify this. Let's make sure we update postController to support userId filter in getPosts! 
    const posts = await api.get(`/posts?userId=${userId}&limit=100`);
    
    grid.innerHTML = '';
    if (posts.length === 0) {
      grid.innerHTML = `
        <div style="grid-column: 1/-1; text-align: center; padding: 3rem; color: var(--text-muted);">
          <i class="fa-regular fa-image" style="font-size: 2.5rem; margin-bottom: 0.75rem;"></i>
          <p>No posts published yet</p>
        </div>
      `;
      return;
    }

    posts.forEach(post => {
      const coverImg = post.images[0] || 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=400&q=80';
      const card = document.createElement('div');
      card.className = 'grid-post-card';
      card.onclick = () => {
        // Simple mock to scroll and inspect on feed, or expand modal
        window.location.hash = '#/';
        setTimeout(() => {
          const el = document.getElementById(`post-${post._id}`);
          if (el) el.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }, 300);
      };
      
      card.innerHTML = `
        <img src="${coverImg}" alt="Post cover" loading="lazy">
        <div class="grid-post-overlay">
          <span><i class="fa-solid fa-heart"></i> ${post.likes.length}</span>
          <span><i class="fa-solid fa-comment"></i> ${post.comments.length}</span>
        </div>
      `;
      grid.appendChild(card);
    });

  } catch (err) {
    grid.innerHTML = '';
    showToast('Failed to load profile posts', 'error');
  }
}

function toggleProfileTab(tabType) {
  document.querySelectorAll('.profile-tab').forEach(t => t.classList.remove('active'));
  
  if (tabType === 'posts') {
    document.getElementById('tab-posts-trigger').classList.add('active');
    document.getElementById('profile-tab-posts-content').classList.remove('hidden');
    document.getElementById('profile-tab-users-content').classList.add('hidden');
  } else {
    // followers or following lists
    const target = tabType === 'followers' ? 'tab-followers-trigger' : 'tab-following-trigger';
    document.getElementById(target).classList.add('active');
    document.getElementById('profile-tab-posts-content').classList.add('hidden');
    document.getElementById('profile-tab-users-content').classList.remove('hidden');
  }
}

// Render users inside profile tab
function renderUserList(usersArray, emptyMsgText) {
  const container = document.getElementById('profile-tab-users-content');
  container.innerHTML = '';

  if (!usersArray || usersArray.length === 0) {
    container.innerHTML = `
      <div style="text-align: center; padding: 2rem; color: var(--text-muted); font-size: 0.9rem;">
        ${emptyMsgText}
      </div>
    `;
    return;
  }

  usersArray.forEach(user => {
    const avatar = user.profileImage || 'https://api.dicebear.com/7.x/adventurer/svg?seed=' + user.username;
    const card = document.createElement('div');
    card.className = 'user-item-card';
    card.innerHTML = `
      <img src="${avatar}" class="user-item-avatar" alt="Avatar" onclick="window.location.hash = '#/profile/${user._id}'">
      <div class="user-item-meta">
        <span class="user-item-name" style="cursor: pointer;" onclick="window.location.hash = '#/profile/${user._id}'">${user.fullname}</span>
        <span class="user-item-username">@${user.username}</span>
      </div>
      <button class="btn btn-secondary btn-sm" onclick="window.location.hash = '#/profile/${user._id}'" style="padding: 0.4rem 1rem; font-size: 0.75rem;">View Profile</button>
    `;
    container.appendChild(card);
  });
}

// --- REELS & SHORT VIDEOS PLAYBACK ---
let reelsObserver = null;

async function initReelsView() {
  const container = document.getElementById('reels-container');
  container.innerHTML = `
    <div style="text-align: center; padding: 3rem; color: var(--text-muted);">
      <i class="fa-solid fa-spinner fa-spin" style="font-size: 2rem; margin-bottom: 1rem; color: var(--primary-color);"></i>
      <p>Loading Reels...</p>
    </div>
  `;

  try {
    const reels = await api.get('/reels');
    container.innerHTML = '';

    if (reels.length === 0) {
      container.innerHTML = `
        <div style="display: flex; flex-direction: column; align-items: center; justify-content: center; height: 100%; text-align: center; padding: 2rem; color: var(--text-muted); gap: 1rem;">
          <i class="fa-solid fa-film" style="font-size: 3rem; color: var(--primary-color);"></i>
          <h3 style="font-weight: 700; color: var(--text-color);">No Reels Yet</h3>
          <p style="font-size: 0.9rem;">Be the first one to share a short video!</p>
          <button class="btn btn-primary btn-sm" onclick="window.location.hash = '#/create-post'" style="margin-top: 0.5rem;"><i class="fa-solid fa-plus"></i> Share a Reel</button>
        </div>
      `;
      return;
    }

    if (reelsObserver) {
      reelsObserver.disconnect();
    }

    reelsObserver = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        const video = entry.target;
        if (entry.isIntersecting) {
          video.play().catch(e => console.log('Autoplay blocked:', e));
        } else {
          video.pause();
        }
      });
    }, {
      root: container,
      threshold: 0.6
    });

    reels.forEach(reel => {
      const authorAvatar = reel.userId.profileImage || 'https://api.dicebear.com/7.x/adventurer/svg?seed=' + reel.userId.username;
      const isLiked = reel.likes.includes(state.currentUser._id);
      const isFollowing = state.currentUser.following.includes(reel.userId._id);
      
      const card = document.createElement('div');
      card.className = 'reel-card';
      card.id = `reel-card-${reel._id}`;
      card.innerHTML = `
        <video class="reel-video" src="${reel.videoUrl}" loop playsinline preload="auto" onclick="toggleReelPlay(this)"></video>
        
        <div class="reel-play-overlay"><i class="fa-solid fa-play"></i></div>

        <div class="reel-actions">
          <div class="reel-action-btn like ${isLiked ? 'liked' : ''}" id="reel-like-btn-${reel._id}" onclick="toggleReelLike('${reel._id}')">
            <i class="fa-solid fa-heart"></i>
            <span class="likes-count" id="reel-likes-val-${reel._id}">${reel.likes.length}</span>
          </div>
          <div class="reel-action-btn comment" onclick="openReelComments('${reel._id}')">
            <i class="fa-solid fa-comment"></i>
            <span>${reel.comments.length}</span>
          </div>
          <div class="reel-action-btn share" onclick="shareReel('${reel._id}')">
            <i class="fa-solid fa-share-nodes"></i>
            <span style="font-size: 0.65rem; font-weight: normal; margin-top: 1px;">Share</span>
          </div>
        </div>

        <div class="reel-meta">
          <div class="reel-author">
            <img src="${authorAvatar}" class="reel-avatar" alt="Avatar" onclick="window.location.hash = '#/profile/${reel.userId._id}'">
            <span class="reel-username" onclick="window.location.hash = '#/profile/${reel.userId._id}'">${reel.userId.username}</span>
            ${reel.userId._id !== state.currentUser._id ? `
              <button class="btn btn-primary btn-sm reel-follow-btn" id="reel-follow-${reel._id}" onclick="toggleReelFollow('${reel.userId._id}', '${reel._id}')">
                ${isFollowing ? 'Following' : 'Follow'}
              </button>
            ` : ''}
          </div>
          <p class="reel-caption">${escapeHTML(reel.caption)}</p>
        </div>
      `;
      container.appendChild(card);

      const videoEl = card.querySelector('.reel-video');
      reelsObserver.observe(videoEl);
    });

  } catch (err) {
    container.innerHTML = `
      <div style="text-align: center; padding: 3rem; color: var(--accent-color);">
        <i class="fa-solid fa-triangle-exclamation" style="font-size: 2rem; margin-bottom: 1rem;"></i>
        <p>Failed to load Reels. Please try again.</p>
      </div>
    `;
    showToast(err.message, 'error');
  }
}

function toggleReelPlay(video) {
  const overlay = video.parentElement.querySelector('.reel-play-overlay');
  if (video.paused) {
    video.play().catch(() => {});
    overlay.innerHTML = '<i class="fa-solid fa-play"></i>';
  } else {
    video.pause();
    overlay.innerHTML = '<i class="fa-solid fa-pause"></i>';
  }
  
  overlay.classList.add('show');
  setTimeout(() => overlay.classList.remove('show'), 500);
}

async function toggleReelLike(reelId) {
  const btn = document.getElementById(`reel-like-btn-${reelId}`);
  const val = document.getElementById(`reel-likes-val-${reelId}`);
  const isLiked = btn.classList.contains('liked');

  try {
    if (isLiked) {
      const data = await api.delete(`/posts/${reelId}/unlike`);
      btn.classList.remove('liked');
      val.textContent = data.likesCount;
    } else {
      const data = await api.post(`/posts/${reelId}/like`);
      btn.classList.add('liked');
      val.textContent = data.likesCount;
    }
  } catch (err) {
    showToast(err.message, 'error');
  }
}

async function toggleReelFollow(authorId, reelId) {
  const isFollowing = state.currentUser.following.includes(authorId);

  try {
    if (isFollowing) {
      await api.delete(`/unfollow/${authorId}`);
      state.currentUser.following = state.currentUser.following.filter(id => id !== authorId);
      showToast('Unfollowed user', 'info');
    } else {
      await api.post(`/follow/${authorId}`);
      state.currentUser.following.push(authorId);
      showToast('Followed user', 'success');
    }
    
    initReelsView();
  } catch (err) {
    showToast(err.message, 'error');
  }
}

function openReelComments(reelId) {
  const videos = document.querySelectorAll('.reel-video');
  videos.forEach(v => v.pause());

  openCommentsModal(reelId);
}

function shareReel(reelId) {
  const shareUrl = `${window.location.origin}/#/reels`;
  navigator.clipboard.writeText(shareUrl).then(() => {
    showToast('Reels link copied to clipboard!', 'success');
  }).catch(() => {
    showToast('Failed to copy link', 'error');
  });
}

// --- CREATE POST VIEW ---
function initCreatePostView() {
  state.filesToUpload = [];
  state.createPostType = 'post';
  document.getElementById('create-caption').value = '';
  document.getElementById('previews-container').innerHTML = '';
  document.getElementById('create-post-submit-btn').innerHTML = '<i class="fa-solid fa-paper-plane" style="margin-right: 0.5rem;"></i>Publish Post';
  document.getElementById('create-post-submit-btn').removeAttribute('disabled');
  
  const aiBtn = document.getElementById('ai-generate-caption-btn');
  if (aiBtn) {
    aiBtn.setAttribute('disabled', 'true');
    aiBtn.innerHTML = '<i class="fa-solid fa-wand-magic-sparkles"></i> AI Generate Caption';
  }

  const tabPost = document.getElementById('create-tab-post');
  const tabReel = document.getElementById('create-tab-reel');
  if (tabPost && tabReel) {
    tabPost.className = 'btn btn-primary create-tab-btn active';
    tabPost.style.backgroundColor = '';
    tabPost.style.color = '';
    tabReel.className = 'btn btn-secondary create-tab-btn';
    tabReel.style.backgroundColor = 'transparent';
    tabReel.style.color = 'var(--text-muted)';
  }

  const dragIcon = document.querySelector('#drag-drop-zone i');
  const dragText = document.querySelector('#drag-drop-zone .upload-text');
  const dragSub = document.querySelector('#drag-drop-zone .upload-subtext');
  const fileInput = document.getElementById('input-post-files');
  if (dragIcon && dragText && dragSub && fileInput) {
    dragIcon.className = 'fa-solid fa-images upload-icon';
    dragText.textContent = 'Drag and drop images here, or click to upload';
    dragSub.textContent = 'JPEG, PNG, GIF, WEBP up to 5MB (Max 10 files)';
    fileInput.setAttribute('accept', 'image/*');
    fileInput.multiple = true;
  }
}

function handlePostFileSelect(files) {
  const previews = document.getElementById('previews-container');
  
  if (state.createPostType === 'reel') {
    const file = files[0];
    if (!file) return;
    if (!file.type.match('video.*')) {
      showToast('Please upload a valid short video file (MP4, WebM, etc.)', 'error');
      return;
    }
    state.filesToUpload = [file];
    
    const reader = new FileReader();
    reader.onload = (e) => {
      previews.innerHTML = `
        <div class="preview-item" style="grid-column: span 4; aspect-ratio: 9/16; max-height: 250px; margin: 0 auto; border-radius: 8px; overflow: hidden; background: #000; position: relative;">
          <video src="${e.target.result}" style="width: 100%; height: 100%; object-fit: cover;" autoplay muted loop></video>
          <button class="preview-remove-btn" onclick="removePostPreview(0)">&times;</button>
        </div>
      `;
    };
    reader.readAsDataURL(file);

    const aiBtn = document.getElementById('ai-generate-caption-btn');
    if (aiBtn) {
      aiBtn.setAttribute('disabled', 'true');
    }
    return;
  }

  for (let i = 0; i < files.length; i++) {
    const file = files[i];
    if (!file.type.match('image.*')) {
      showToast('Only image files are supported', 'error');
      continue;
    }
    
    if (state.filesToUpload.length >= 10) {
      showToast('Max limit of 10 images reached', 'warning');
      break;
    }

    state.filesToUpload.push(file);

    const reader = new FileReader();
    reader.onload = (e) => {
      const idx = state.filesToUpload.length - 1;
      const previewCard = document.createElement('div');
      previewCard.className = 'preview-item';
      previewCard.id = `preview-${idx}`;
      previewCard.innerHTML = `
        <img src="${e.target.result}" alt="Preview">
        <button class="preview-remove-btn" onclick="removePostPreview(${idx})">&times;</button>
      `;
      previews.appendChild(previewCard);
    };
    reader.readAsDataURL(file);
  }
  
  const aiBtn = document.getElementById('ai-generate-caption-btn');
  if (aiBtn && state.filesToUpload.length > 0) {
    aiBtn.removeAttribute('disabled');
  }
}

function removePostPreview(index) {
  if (state.createPostType === 'reel') {
    state.filesToUpload = [];
    document.getElementById('previews-container').innerHTML = '';
    return;
  }

  state.filesToUpload.splice(index, 1);
  const element = document.getElementById(`preview-${index}`);
  if (element) element.remove();
  
  // Re-adjust previews indices on DOM to match array index matches
  const previews = document.getElementById('previews-container');
  previews.innerHTML = '';
  state.filesToUpload.forEach((file, idx) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const previewCard = document.createElement('div');
      previewCard.className = 'preview-item';
      previewCard.id = `preview-${idx}`;
      previewCard.innerHTML = `
        <img src="${e.target.result}" alt="Preview">
        <button class="preview-remove-btn" onclick="removePostPreview(${idx})">&times;</button>
      `;
      previews.appendChild(previewCard);
    };
    reader.readAsDataURL(file);
  });

  const aiBtn = document.getElementById('ai-generate-caption-btn');
  if (aiBtn && state.filesToUpload.length === 0) {
    aiBtn.setAttribute('disabled', 'true');
  }
}

async function handleAIGenerateCaption() {
  if (state.filesToUpload.length === 0) return;
  
  const aiBtn = document.getElementById('ai-generate-caption-btn');
  if (!aiBtn) return;
  
  aiBtn.setAttribute('disabled', 'true');
  aiBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Analyzing...';
  
  const formData = new FormData();
  formData.append('image', state.filesToUpload[0]);
  
  try {
    const data = await api.postMultipart('/posts/generate-caption', formData);
    document.getElementById('create-caption').value = data.caption;
    showToast('AI caption generated!', 'success');
  } catch (err) {
    showToast(err.message, 'error');
  } finally {
    aiBtn.removeAttribute('disabled');
    aiBtn.innerHTML = '<i class="fa-solid fa-wand-magic-sparkles"></i> AI Generate Caption';
  }
}

async function handleCreatePostSubmit(e) {
  e.preventDefault();
  const caption = document.getElementById('create-caption').value;
  
  if (state.filesToUpload.length === 0 && !caption.trim()) {
    showToast('Add a caption or upload at least one file', 'warning');
    return;
  }

  const submitBtn = document.getElementById('create-post-submit-btn');

  if (state.createPostType === 'reel') {
    if (state.filesToUpload.length === 0) {
      showToast('Please select a short video for your reel', 'warning');
      return;
    }
    submitBtn.setAttribute('disabled', 'true');
    submitBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Uploading Reel...';

    const formData = new FormData();
    formData.append('caption', caption);
    formData.append('video', state.filesToUpload[0]);

    try {
      await api.postMultipart('/reels', formData);
      showToast('Reel published successfully!', 'success');
      window.location.hash = '#/reels';
    } catch (err) {
      submitBtn.removeAttribute('disabled');
      submitBtn.innerHTML = '<i class="fa-solid fa-paper-plane" style="margin-right: 0.5rem;"></i>Publish Post';
      showToast(err.message, 'error');
    }
    return;
  }

  submitBtn.setAttribute('disabled', 'true');
  submitBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Uploading...';

  const formData = new FormData();
  formData.append('caption', caption);
  state.filesToUpload.forEach(file => {
    formData.append('images', file);
  });

  try {
    await api.postMultipart('/posts', formData);
    showToast('Post published successfully!', 'success');
    window.location.hash = '#/';
  } catch (err) {
    submitBtn.removeAttribute('disabled');
    submitBtn.innerHTML = '<i class="fa-solid fa-paper-plane" style="margin-right: 0.5rem;"></i>Publish Post';
    showToast(err.message, 'error');
  }
}

// --- EDIT PROFILE VIEW ---
function initEditProfileView() {
  if (!state.currentUser) return;
  
  // Fill profile form values
  document.getElementById('edit-fullname').value = state.currentUser.fullname;
  document.getElementById('edit-username').value = state.currentUser.username;
  document.getElementById('edit-email').value = state.currentUser.email;
  document.getElementById('edit-bio').value = state.currentUser.bio || '';
  document.getElementById('edit-location').value = state.currentUser.location || '';
  document.getElementById('edit-website').value = state.currentUser.website || '';
  
  const coverUrl = state.currentUser.coverImage || 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800&q=80';
  const avatarUrl = state.currentUser.profileImage || 'https://api.dicebear.com/7.x/adventurer/svg?seed=' + state.currentUser.username;
  
  document.getElementById('edit-cover-preview-img').src = coverUrl;
  document.getElementById('edit-avatar-preview-img').src = avatarUrl;
}

// Preview image selection locally
function previewEditImage(input, previewImgId) {
  if (input.files && input.files[0]) {
    const file = input.files[0];
    const reader = new FileReader();
    reader.onload = (e) => {
      document.getElementById(previewImgId).src = e.target.result;
    };
    reader.readAsDataURL(file);
  }
}

async function handleEditProfileSubmit(e) {
  e.preventDefault();
  
  const formData = new FormData();
  formData.append('fullname', document.getElementById('edit-fullname').value);
  formData.append('username', document.getElementById('edit-username').value);
  formData.append('email', document.getElementById('edit-email').value);
  formData.append('bio', document.getElementById('edit-bio').value);
  formData.append('location', document.getElementById('edit-location').value);
  formData.append('website', document.getElementById('edit-website').value);

  const avatarFile = document.getElementById('input-avatar-file').files[0];
  const coverFile = document.getElementById('input-cover-file').files[0];

  if (avatarFile) formData.append('profileImage', avatarFile);
  if (coverFile) formData.append('coverImage', coverFile);

  try {
    const data = await api.putMultipart(`/users/${state.currentUser._id}`, formData);
    
    // Merge into local current user state
    state.currentUser = { ...state.currentUser, ...data };
    localStorage.setItem('snaploop_user', JSON.stringify(state.currentUser));
    
    showToast('Profile updated successfully!', 'success');
    window.location.hash = `#/profile/${state.currentUser._id}`;
  } catch (err) {
    showToast(err.message, 'error');
  }
}

// --- SEARCH VIEW ---
let searchDebounceTimeout = null;

function initSearchView() {
  document.getElementById('search-page-input').value = '';
  document.getElementById('search-results-container').innerHTML = '';
  document.getElementById('search-placeholder-msg').classList.remove('hidden');
}

function handleSearchQuery(query) {
  clearTimeout(searchDebounceTimeout);
  
  const container = document.getElementById('search-results-container');
  const placeholder = document.getElementById('search-placeholder-msg');
  
  if (!query || !query.trim()) {
    container.innerHTML = '';
    placeholder.classList.remove('hidden');
    placeholder.textContent = 'Enter a search term to find users on SnapLoop.';
    return;
  }
  
  placeholder.textContent = 'Searching...';
  placeholder.classList.remove('hidden');

  searchDebounceTimeout = setTimeout(async () => {
    try {
      const users = await api.get(`/users?search=${encodeURIComponent(query.trim())}`);
      
      placeholder.classList.add('hidden');
      container.innerHTML = '';

      if (users.length === 0) {
        placeholder.textContent = `No users found matching "${query}"`;
        placeholder.classList.remove('hidden');
        return;
      }

      users.forEach(user => {
        const avatar = user.profileImage || 'https://api.dicebear.com/7.x/adventurer/svg?seed=' + user.username;
        const isSelf = user._id === state.currentUser._id;
        
        let subAction = '';
        if (!isSelf) {
          const isFollowing = state.currentUser.following.includes(user._id);
          subAction = isFollowing 
            ? `<button class="btn btn-secondary btn-sm" onclick="toggleSearchFollow('${user._id}', this)" style="padding: 0.4rem 0.8rem; font-size: 0.75rem;">Following</button>`
            : `<button class="btn btn-primary btn-sm" onclick="toggleSearchFollow('${user._id}', this)" style="padding: 0.4rem 0.8rem; font-size: 0.75rem;">Follow</button>`;
        }

        const card = document.createElement('div');
        card.className = 'user-item-card';
        card.innerHTML = `
          <img src="${avatar}" class="user-item-avatar" alt="Avatar" onclick="window.location.hash = '#/profile/${user._id}'" style="cursor: pointer;">
          <div class="user-item-meta">
            <span class="user-item-name" onclick="window.location.hash = '#/profile/${user._id}'" style="cursor: pointer;">${user.fullname}</span>
            <span class="user-item-username">@${user.username}</span>
          </div>
          ${subAction}
        `;
        container.appendChild(card);
      });

    } catch (err) {
      placeholder.textContent = 'Error querying users. Try again.';
      showToast('Search query failed', 'error');
    }
  }, 400);
}

// Search Card follow toggle helper
async function toggleSearchFollow(targetId, btn) {
  const isFollowing = btn.textContent === 'Following';
  try {
    if (isFollowing) {
      await api.delete(`/unfollow/${targetId}`);
      btn.className = 'btn btn-primary btn-sm';
      btn.textContent = 'Follow';
      state.currentUser.following = state.currentUser.following.filter(id => id !== targetId);
    } else {
      await api.post(`/follow/${targetId}`);
      btn.className = 'btn btn-secondary btn-sm';
      btn.textContent = 'Following';
      state.currentUser.following.push(targetId);
    }
    localStorage.setItem('snaploop_user', JSON.stringify(state.currentUser));
  } catch (err) {
    showToast(err.message, 'error');
  }
}

// --- NOTIFICATIONS VIEW ---
async function initNotificationsView() {
  const list = document.getElementById('notifications-list-container');
  list.innerHTML = '<div class="skeleton-post" style="height: 60px;"></div>';

  try {
    const listData = await api.get('/notifications');
    list.innerHTML = '';

    if (listData.length === 0) {
      list.innerHTML = `
        <div style="text-align: center; padding: 3rem; color: var(--text-muted); font-size: 0.9rem;">
          <i class="fa-regular fa-bell" style="font-size: 2.5rem; margin-bottom: 0.75rem; color: var(--text-muted);"></i>
          <p>No notifications yet</p>
        </div>
      `;
      return;
    }

    listData.forEach(notif => {
      const avatar = notif.senderId.profileImage || 'https://api.dicebear.com/7.x/adventurer/svg?seed=' + notif.senderId.username;
      const time = formatTimeAgo(notif.createdAt);
      
      let badgeIcon = 'fa-user-plus';
      let message = `<strong>${notif.senderId.fullname}</strong> started following you.`;
      let postThumbnail = '';

      if (notif.type === 'like') {
        badgeIcon = 'fa-heart';
        message = `<strong>${notif.senderId.fullname}</strong> liked your post.`;
        if (notif.postId && notif.postId.images && notif.postId.images.length > 0) {
          postThumbnail = `<img src="${notif.postId.images[0]}" class="notification-thumb" alt="Thumbnail">`;
        }
      } else if (notif.type === 'comment') {
        badgeIcon = 'fa-comment';
        message = `<strong>${notif.senderId.fullname}</strong> commented: "${escapeHTML(notif.commentText)}"`;
        if (notif.postId && notif.postId.images && notif.postId.images.length > 0) {
          postThumbnail = `<img src="${notif.postId.images[0]}" class="notification-thumb" alt="Thumbnail">`;
        }
      }

      const card = document.createElement('div');
      card.className = `notification-card ${notif.read ? '' : 'unread'}`;
      card.onclick = () => {
        // Read details and click to route
        if (notif.type === 'follow') {
          window.location.hash = `#/profile/${notif.senderId._id}`;
        } else if (notif.postId) {
          window.location.hash = '#/';
          setTimeout(() => {
            const el = document.getElementById(`post-${notif.postId._id}`);
            if (el) el.scrollIntoView({ behavior: 'smooth', block: 'center' });
          }, 300);
        }
      };

      card.innerHTML = `
        <div class="notification-icon-wrapper">
          <img src="${avatar}" class="comment-avatar" style="width: 38px; height: 38px;" alt="Avatar">
          <div class="notification-badge-type ${notif.type}">
            <i class="fa-solid ${badgeIcon}"></i>
          </div>
        </div>
        <div class="notification-msg">
          <p>${message}</p>
          <span style="font-size: 0.725rem; color: var(--text-muted);">${time}</span>
        </div>
        ${postThumbnail}
      `;
      list.appendChild(card);
    });

  } catch (err) {
    list.innerHTML = '';
    showToast('Failed to load notifications list', 'error');
  }
}

// Mark notifications read
async function markAllNotificationsAsRead() {
  try {
    await api.put('/notifications/read');
    document.querySelectorAll('.notification-card').forEach(card => card.classList.remove('unread'));
    
    // Hide badges
    document.getElementById('notification-badge').classList.add('hidden');
    document.getElementById('mobile-notification-badge').classList.add('hidden');
    showToast('All notifications marked as read', 'success');
  } catch (err) {
    showToast('Failed to mark notifications read', 'error');
  }
}

// --- SETTINGS VIEW ---
function initSettingsView() {
  updateThemeIcons();
}

async function handleDeleteAccount() {
  if (!confirm('WARNING: Are you sure you want to delete your SnapLoop account permanently? This action CANNOT be undone.')) return;
  const usernameConfirm = prompt('Please enter your username to confirm profile deletion:');
  
  if (usernameConfirm !== state.currentUser.username) {
    showToast('Username confirmation did not match.', 'error');
    return;
  }

  try {
    await api.delete(`/users/${state.currentUser._id}`);
    showToast('Account deleted successfully.', 'info');
    
    // Log out client
    localStorage.removeItem('snaploop_user');
    api.clearToken();
    state.currentUser = null;
    state.isLoggedIn = false;
    router();
  } catch (err) {
    showToast(err.message, 'error');
  }
}

// --- DASHBOARD VIEW ---
async function initDashboardView() {
  const timeline = document.getElementById('dash-activity-timeline');
  timeline.innerHTML = '<div class="skeleton-post" style="height: 100px;"></div>';

  try {
    const data = await api.get(`/users/${state.currentUser._id}/dashboard`);
    
    // Stats counters
    document.getElementById('dash-posts-val').textContent = data.stats.totalPosts;
    document.getElementById('dash-followers-val').textContent = data.stats.followersCount;
    document.getElementById('dash-following-val').textContent = data.stats.followingCount;
    document.getElementById('dash-notifications-val').textContent = data.stats.unreadNotifications;

    // Mini profile card on side
    const avatarUrl = state.currentUser.profileImage || 'https://api.dicebear.com/7.x/adventurer/svg?seed=' + state.currentUser.username;
    document.getElementById('dash-side-avatar').src = avatarUrl;
    document.getElementById('dash-side-fullname').textContent = state.currentUser.fullname;
    document.getElementById('dash-side-username').textContent = `@${state.currentUser.username}`;

    // Activities timeline
    timeline.innerHTML = '';
    const activities = data.recentActivity;

    if (activities.length === 0) {
      timeline.innerHTML = `
        <div style="text-align: center; color: var(--text-muted); font-size: 0.85rem; padding: 1.5rem 0;">
          No recent activity logs.
        </div>
      `;
      return;
    }

    activities.forEach(item => {
      const avatar = item.senderId.profileImage || 'https://api.dicebear.com/7.x/adventurer/svg?seed=' + item.senderId.username;
      const time = formatTimeAgo(item.createdAt);
      
      let actionText = '';
      if (item.type === 'follow') {
        actionText = `<strong>${item.senderId.fullname}</strong> started following you.`;
      } else if (item.type === 'like') {
        actionText = `<strong>${item.senderId.fullname}</strong> liked your post: <em>"${escapeHTML(item.postId ? item.postId.caption : '')}"</em>`;
      } else if (item.type === 'comment') {
        actionText = `<strong>${item.senderId.fullname}</strong> commented: <em>"${escapeHTML(item.commentText)}"</em>`;
      }

      const row = document.createElement('div');
      row.className = 'activity-timeline-item';
      row.innerHTML = `
        <div class="activity-dot"></div>
        <img src="${avatar}" class="activity-avatar" alt="">
        <div class="activity-content">
          <p>${actionText}</p>
        </div>
        <span class="activity-date">${time}</span>
      `;
      timeline.appendChild(row);
    });

  } catch (err) {
    timeline.innerHTML = '';
    showToast('Failed to load dashboard metrics', 'error');
  }
}

// --- POST COMMENTS MODAL (EXPANDED CONVERSATION VIEW) ---
async function openCommentsModal(postId) {
  state.activeCommentPostId = postId;
  const list = document.getElementById('modal-comments-list');
  list.innerHTML = '<div class="skeleton-post" style="height: 50px;"></div>';
  
  openModal('comments-modal');
  document.getElementById('modal-comment-input').value = '';

  try {
    // Retrieve post comments list directly
    const post = await api.get(`/posts?limit=1`); 
    // Wait! A more direct approach: we query details of the target post!
    // But since we can fetch the post document by using a custom filter or query, let's query GET /posts?id=postId or load details.
    // Wait, let's query `/posts` by filter, or let's create a custom post details route or let's find the post in the DOM and list comments.
    // Actually, querying the exact post comments is very clean! Let's check:
    // In postController we can return feed. Let's make an endpoint `GET /posts/:id` if we need, or query feed.
    // Since we don't have a direct `GET /posts/:id` endpoint mapped in api spec, let's look at the api routes specified in user prompt:
    // - POST /comments
    // - PUT /comments/:id
    // - DELETE /comments/:id
    // Wait, if we don't have a GET /posts/:id API, we can fetch all posts and find the matching one, OR we can dynamically write one,
    // OR we can just fetch the comments bypostId. Wait, how do we get comments for a post?
    // In GET /posts, it returns comments populated inside each post card!
    // So we can easily read the comment documents from the posts feed state, or write a quick `GET /posts/:id` route in backend.
    // Writing a `GET /posts/:id` in backend makes the API extremely developer friendly and robust! Let's make sure our backend has GET /posts/:id route.
    // Let's check `routes/posts.js` and `controllers/postController.js`. We did not specify `GET /posts/:id` in `routes/posts.js`.
    // Let's add `GET /api/posts/:id` to fetch a single post with populated comments. It's incredibly clean. We will add it shortly.
    const postObj = await api.get(`/posts?id=${postId}`); // We will support filtering by ID in getPosts or add GET /posts/:id
    // Let's assume we fetch `/posts` and support parameter `id` in search query!
    const targetPost = Array.isArray(postObj) ? postObj.find(p => p._id === postId) : postObj;

    list.innerHTML = '';
    if (!targetPost || !targetPost.comments || targetPost.comments.length === 0) {
      list.innerHTML = `
        <div style="text-align: center; color: var(--text-muted); font-size: 0.85rem; padding: 2rem;">
          No comments yet.
        </div>
      `;
      return;
    }

    targetPost.comments.forEach(comm => {
      const avatar = comm.userId.profileImage || 'https://api.dicebear.com/7.x/adventurer/svg?seed=' + comm.userId.username;
      
      let commDeleteBtn = '';
      const isCommentOwner = comm.userId._id === state.currentUser._id;
      const isPostOwner = targetPost.userId._id === state.currentUser._id;
      if (isCommentOwner || isPostOwner) {
        commDeleteBtn = `<i class="fa-solid fa-trash-can comment-action-btn delete" onclick="deleteModalComment('${comm._id}', '${postId}')" title="Delete comment"></i>`;
      }

      const item = document.createElement('div');
      item.className = 'comment-item';
      item.id = `modal-comment-${comm._id}`;
      item.innerHTML = `
        <img src="${avatar}" class="comment-avatar" alt="Avatar">
        <div class="comment-body">
          <span class="comment-author" onclick="closeModal('comments-modal'); window.location.hash = '#/profile/${comm.userId._id}'">${comm.userId.username}</span>
          <span>${escapeHTML(comm.comment)}</span>
        </div>
        <div class="comment-actions">
          ${commDeleteBtn}
        </div>
      `;
      list.appendChild(item);
    });

  } catch (err) {
    list.innerHTML = '';
    showToast('Failed to load comments list', 'error');
  }
}

// Submit comment from Modal
async function handleModalCommentSubmit() {
  const postId = state.activeCommentPostId;
  const input = document.getElementById('modal-comment-input');
  const text = input.value;
  if (!postId || !text || !text.trim()) return;

  try {
    const comment = await api.post('/comments', { postId, comment: text });
    input.value = '';
    
    // Reload comments in modal
    openCommentsModal(postId);

    // Also update feed posts card preview count and list if card exists
    const card = document.getElementById(`post-${postId}`);
    if (card) {
      const countSpan = card.querySelector('.comment span');
      countSpan.textContent = parseInt(countSpan.textContent) + 1;
      
      // prepend preview
      const previewList = document.getElementById(`card-comments-${postId}`);
      const avatarUrl = comment.userId.profileImage || 'https://api.dicebear.com/7.x/adventurer/svg?seed=' + comment.userId.username;
      const previewHtml = `
        <div class="comment-item" id="comment-${comment._id}">
          <img src="${avatarUrl}" class="comment-avatar" alt="Avatar">
          <div class="comment-body">
            <span class="comment-author" onclick="window.location.hash = '#/profile/${comment.userId._id}'">${comment.userId.username}</span>
            <span>${escapeHTML(comment.comment)}</span>
          </div>
          <div class="comment-actions">
            <i class="fa-solid fa-trash-can comment-action-btn delete" onclick="deleteComment('${comment._id}', '${postId}')" title="Delete comment"></i>
          </div>
        </div>
      `;
      previewList.insertAdjacentHTML('afterbegin', previewHtml);
    }
    showToast('Comment added', 'success');
  } catch (err) {
    showToast(err.message, 'error');
  }
}

// Delete comment from modal
async function deleteModalComment(commentId, postId) {
  if (!confirm('Delete this comment?')) return;
  try {
    await api.delete(`/comments/${commentId}`);
    
    const item = document.getElementById(`modal-comment-${commentId}`);
    if (item) item.remove();

    // Sync feed card if exists
    const card = document.getElementById(`post-${postId}`);
    if (card) {
      const countSpan = card.querySelector('.comment span');
      countSpan.textContent = Math.max(0, parseInt(countSpan.textContent) - 1);
      
      const inlineComment = document.getElementById(`comment-${commentId}`);
      if (inlineComment) inlineComment.remove();
    }
    showToast('Comment deleted', 'info');
  } catch (err) {
    showToast(err.message, 'error');
  }
}

// Save post caption edits
async function handleModalPostCaptionSave() {
  const postId = state.activeEditPostId;
  const textarea = document.getElementById('modal-edit-caption-textarea');
  const caption = textarea.value;
  if (!postId) return;

  try {
    await api.put(`/posts/${postId}`, { caption });
    closeModal('edit-post-modal');
    
    // Update caption on feed card in DOM
    const card = document.getElementById(`post-${postId}`);
    if (card) {
      const captionDiv = card.querySelector('.post-caption');
      if (captionDiv) captionDiv.textContent = caption;
    }
    showToast('Caption updated', 'success');
  } catch (err) {
    showToast(err.message, 'error');
  }
}

// --- HELPER UTILITIES ---

function openModal(modalId) {
  const modal = document.getElementById(modalId);
  if (modal) modal.classList.add('active');
}

function closeModal(modalId) {
  const modal = document.getElementById(modalId);
  if (modal) modal.classList.remove('active');
}

function formatTimeAgo(dateString) {
  const date = new Date(dateString);
  const now = new Date();
  const diffMs = now - date;
  
  const diffSecs = Math.floor(diffMs / 1000);
  const diffMins = Math.floor(diffSecs / 60);
  const diffHours = Math.floor(diffMins / 60);
  const diffDays = Math.floor(diffHours / 24);

  if (diffSecs < 60) return 'Just now';
  if (diffMins < 60) return `${diffMins}m ago`;
  if (diffHours < 24) return `${diffHours}h ago`;
  if (diffDays < 7) return `${diffDays}d ago`;
  
  return date.toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' });
}

function escapeHTML(str) {
  if (!str) return '';
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

function escapeJSString(str) {
  if (!str) return '';
  return str
    .replace(/\\/g, '\\\\')
    .replace(/`/g, '\\`')
    .replace(/\$/g, '\\$')
    .replace(/"/g, '\\"')
    .replace(/'/g, "\\'");
}

// --- EVENT LISTENERS REGISTRATIONS ---
document.addEventListener('DOMContentLoaded', () => {
  // Bootstrap application
  bootstrapApp();

  // Route monitoring
  window.addEventListener('hashchange', router);

  // Theme Toggler Click
  document.getElementById('theme-toggle').onclick = toggleTheme;
  document.getElementById('settings-theme-toggle').onclick = toggleTheme;

  // Auth Forms submission
  document.getElementById('login-form').onsubmit = handleLogin;
  document.getElementById('register-form').onsubmit = handleRegister;

  // Link flips in Auth cards
  document.getElementById('go-to-register').onclick = () => window.location.hash = '#/register';
  document.getElementById('go-to-login').onclick = () => window.location.hash = '#/login';
  
  // Logout action
  document.getElementById('quick-logout-btn').onclick = handleLogout;

  // Create post drag zones & preview carousel attachments
  const zone = document.getElementById('drag-drop-zone');
  const fileInput = document.getElementById('input-post-files');
  
  zone.onclick = () => fileInput.click();
  fileInput.onchange = (e) => handlePostFileSelect(e.target.files);
  
  zone.ondragover = (e) => {
    e.preventDefault();
    zone.classList.add('dragover');
  };
  zone.ondragleave = () => zone.classList.remove('dragover');
  zone.ondrop = (e) => {
    e.preventDefault();
    zone.classList.remove('dragover');
    handlePostFileSelect(e.dataTransfer.files);
  };

  const tabPost = document.getElementById('create-tab-post');
  const tabReel = document.getElementById('create-tab-reel');
  const dragIcon = document.querySelector('#drag-drop-zone i');
  const dragText = document.querySelector('#drag-drop-zone .upload-text');
  const dragSub = document.querySelector('#drag-drop-zone .upload-subtext');
  const aiBtn = document.getElementById('ai-generate-caption-btn');

  if (tabPost && tabReel) {
    tabPost.onclick = () => {
      state.createPostType = 'post';
      state.filesToUpload = [];
      document.getElementById('previews-container').innerHTML = '';
      
      tabPost.className = 'btn btn-primary create-tab-btn active';
      tabPost.style.backgroundColor = '';
      tabPost.style.color = '';
      tabReel.className = 'btn btn-secondary create-tab-btn';
      tabReel.style.backgroundColor = 'transparent';
      tabReel.style.color = 'var(--text-muted)';

      if (dragIcon && dragText && dragSub && fileInput) {
        dragIcon.className = 'fa-solid fa-images upload-icon';
        dragText.textContent = 'Drag and drop images here, or click to upload';
        dragSub.textContent = 'JPEG, PNG, GIF, WEBP up to 5MB (Max 10 files)';
        fileInput.setAttribute('accept', 'image/*');
        fileInput.multiple = true;
      }
      if (aiBtn) {
        aiBtn.setAttribute('disabled', 'true');
        aiBtn.style.display = 'flex';
      }
    };

    tabReel.onclick = () => {
      state.createPostType = 'reel';
      state.filesToUpload = [];
      document.getElementById('previews-container').innerHTML = '';

      tabReel.className = 'btn btn-primary create-tab-btn active';
      tabReel.style.backgroundColor = '';
      tabReel.style.color = '';
      tabPost.className = 'btn btn-secondary create-tab-btn';
      tabPost.style.backgroundColor = 'transparent';
      tabPost.style.color = 'var(--text-muted)';

      if (dragIcon && dragText && dragSub && fileInput) {
        dragIcon.className = 'fa-solid fa-clapperboard upload-icon';
        dragText.textContent = 'Drag and drop short video here, or click to upload';
        dragSub.textContent = 'MP4, WebM, MOV up to 50MB (Max 1 file)';
        fileInput.setAttribute('accept', 'video/*');
        fileInput.multiple = false;
      }
      if (aiBtn) {
        aiBtn.setAttribute('disabled', 'true');
        aiBtn.style.display = 'none';
      }
    };
  }

  document.getElementById('create-post-form').onsubmit = handleCreatePostSubmit;
  document.getElementById('ai-generate-caption-btn').onclick = handleAIGenerateCaption;

  // Edit profile form files triggers
  const coverTrigger = document.getElementById('cover-upload-trigger');
  const avatarTrigger = document.getElementById('avatar-upload-trigger');
  const inputCover = document.getElementById('input-cover-file');
  const inputAvatar = document.getElementById('input-avatar-file');

  coverTrigger.onclick = (e) => {
    // Avoid triggering avatar click when clicking inner avatar bubble
    if (e.target.closest('#avatar-upload-trigger')) return;
    inputCover.click();
  };
  avatarTrigger.onclick = () => inputAvatar.click();

  inputCover.onchange = () => previewEditImage(inputCover, 'edit-cover-preview-img');
  inputAvatar.onchange = () => previewEditImage(inputAvatar, 'edit-avatar-preview-img');

  document.getElementById('edit-profile-form').onsubmit = handleEditProfileSubmit;

  // Live User Search monitoring
  const searchInput = document.getElementById('search-page-input');
  searchInput.oninput = (e) => handleSearchQuery(e.target.value);
  
  const headerSearchInput = document.getElementById('top-search-input');
  headerSearchInput.onkeydown = (e) => {
    if (e.key === 'Enter') {
      const q = headerSearchInput.value;
      headerSearchInput.value = '';
      window.location.hash = '#/search';
      setTimeout(() => {
        const inp = document.getElementById('search-page-input');
        if (inp) {
          inp.value = q;
          handleSearchQuery(q);
        }
      }, 200);
    }
  };

  // Mark alerts read
  document.getElementById('mark-all-read-btn').onclick = markAllNotificationsAsRead;

  // Settings Actions
  document.getElementById('delete-account-btn').onclick = handleDeleteAccount;

  // Modal actions dismiss
  document.getElementById('comments-modal-close').onclick = () => closeModal('comments-modal');
  document.getElementById('edit-post-modal-close').onclick = () => closeModal('edit-post-modal');
  document.getElementById('modal-edit-post-cancel-btn').onclick = () => closeModal('edit-post-modal');
  
  // Submit modal actions
  document.getElementById('modal-comment-submit-btn').onclick = handleModalCommentSubmit;
  document.getElementById('modal-comment-input').onkeydown = (e) => {
    if (e.key === 'Enter') handleModalCommentSubmit();
  };
  document.getElementById('modal-edit-post-save-btn').onclick = handleModalPostCaptionSave;
});
