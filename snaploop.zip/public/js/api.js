const API_URL = '/api';

const api = {
  getToken() {
    return localStorage.getItem('snaploop_token');
  },
  
  setToken(token) {
    localStorage.setItem('snaploop_token', token);
  },
  
  clearToken() {
    localStorage.removeItem('snaploop_token');
  },
  
  getHeaders(isMultipart = false) {
    const headers = {};
    if (!isMultipart) {
      headers['Content-Type'] = 'application/json';
    }
    const token = this.getToken();
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }
    return headers;
  },
  
  async request(url, options = {}) {
    try {
      const response = await fetch(`${API_URL}${url}`, options);
      const data = await response.json();
      
      if (!response.ok) {
        if (response.status === 401) {
          this.clearToken();
          window.dispatchEvent(new Event('auth-expired'));
        }
        throw new Error(data.message || 'Something went wrong');
      }
      return data;
    } catch (err) {
      console.error(`API Error on ${url}:`, err);
      throw err;
    }
  },
  
  async get(url) {
    return this.request(url, {
      method: 'GET',
      headers: this.getHeaders()
    });
  },
  
  async post(url, body = {}) {
    return this.request(url, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify(body)
    });
  },
  
  async put(url, body = {}) {
    return this.request(url, {
      method: 'PUT',
      headers: this.getHeaders(),
      body: JSON.stringify(body)
    });
  },
  
  async delete(url) {
    return this.request(url, {
      method: 'DELETE',
      headers: this.getHeaders()
    });
  },
  
  async postMultipart(url, formData) {
    return this.request(url, {
      method: 'POST',
      headers: this.getHeaders(true),
      body: formData
    });
  },
  
  async putMultipart(url, formData) {
    return this.request(url, {
      method: 'PUT',
      headers: this.getHeaders(true),
      body: formData
    });
  }
};
