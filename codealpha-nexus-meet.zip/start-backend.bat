@echo off
echo =======================================================
echo   NexusMeet - Start Local Backend Server
echo =======================================================
echo.
echo Starting the Express backend server on port 5007...
echo Keep this command window open while using the application.
echo.
cd /d "%~dp0\backend"
npm start
echo.
pause
