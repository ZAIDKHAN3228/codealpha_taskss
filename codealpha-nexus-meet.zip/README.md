# NexusMeet

NexusMeet is a modern, production-ready, and feature-rich Real-Time Communication (RTC) web application similar to Google Meet, Zoom, and Microsoft Teams. It features peer-to-peer audio-video conferencing, screen sharing, real-time chat with emoji reactions and message replies, secure file uploads via Cloudinary, and a collaborative drawing whiteboard synced instantly between participants.

---

## Technical Stack Overview

### Frontend
- **Framework**: React.js (Vite)
- **Styling**: Tailwind CSS (v3 with preset glassmorphism classes)
- **Animations**: Framer Motion (for smooth dashboard page flows and modal transitions)
- **Real-Time Client**: Socket.io Client
- **RTC Engine**: Browser Native WebRTC APIs (multi-user Mesh topology)
- **Icons**: React Icons (lucide / feather set)
- **Network calls**: Axios (intercepted for automatically attaching Bearer tokens)

### Backend
- **Framework**: Node.js & Express (configured as ES Modules)
- **Database**: MongoDB + Mongoose Schemas (User, Meeting, Message, File)
- **Real-Time Server**: Socket.io Engine
- **Auth & Hashing**: JSON Web Token (JWT) & bcryptjs
- **Uploads Handler**: Multer
- **Storage Service**: Cloudinary (with a smart fallback to local disk storage if credentials are not provided)
- **Security Protections**: Helmet (CSP rules configured for WebSockets/WebRTC), Express-Rate-Limit, CORS origins control

---

## Features Matrix

- **Multi-user Video Calling**: Full-mesh WebRTC topology coordinating camera and mic feeds.
- **Dynamic Device Switching**: Swap hot-plugged webcams and microphones mid-call with instant track updates.
- **Collaborative Whiteboard**: Draw sketches, circles, rectangles, lines, or erase drawings, synced instantly. Supports PNG and printable PDF exports.
- **Real-Time Chat & File Attachments**: Rich chat room with message replies, read statuses, typing indicators, emoji tray, and file drops (Images, PDFs, Word, ZIPs, Videos) with uploading progress indicators.
- **Host Controls**: A dedicated host can mute other call participants or end the meeting for everyone.
- **Raise Hand & Speaker Highlight**: Click the hand icon to alert peers, with simulated border-glow speaker highlighting.
- **Password Protection**: Secure meetings with optionally configured room passwords.
- **Email Verification & Password Reset**: Console logs mock emails with generated URLs during local development.

---

## Project Structure

```
nexus-meet/
├── backend/
│   ├── config/             # DB & Cloudinary configs
│   ├── controllers/        # REST Route handlers (auth, meetings, files, users)
│   ├── middleware/         # Security blocks, uploads, and auth guards
│   ├── models/             # Mongoose schemas
│   ├── routes/             # API routing
│   ├── sockets/            # Socket.io events signaling core
│   ├── server.js           # Server application file
│   └── package.json
├── frontend/
│   ├── src/
│   │   ├── components/     # Modals, chat, whiteboard views
│   │   ├── contexts/       # React Auth, Sockets, and WebRTC states
│   │   ├── pages/          # Landing, Dashboard, Profile, settings
│   │   ├── services/       # Axios API client setup
│   │   ├── styles/         # Tailwind CSS entries
│   │   ├── App.jsx
│   │   └── main.jsx
│   ├── tailwind.config.js
│   └── package.json
├── render.yaml             # Render deployment config
└── README.md
```

---

## Installation & Local Setup

### Prerequisites
- [Node.js](https://nodejs.org) (v18+ recommended)
- A running MongoDB server locally (`mongodb://127.0.0.1:27017/nexusmeet`) or a MongoDB Atlas connection string.

### Step 1: Clone and Set Up Backend
1. Navigate to the backend directory:
   ```bash
   cd backend
   ```
2. Create your `.env` file by copying the example:
   ```bash
   copy .env.example .env
   ```
3. Open `.env` and fill in your keys (or leave Cloudinary keys blank to use local folder fallback):
   - `JWT_SECRET`: A secure string for token signing.
   - `MONGO_URI`: Your MongoDB database URL.
4. Install dependencies:
   ```bash
   npm install
   ```
5. Run the dev server:
   ```bash
   npm run dev
   ```

### Step 2: Set Up Frontend
1. Open a new terminal window and navigate to the frontend directory:
   ```bash
   cd frontend
   ```
2. Create your `.env` file from the example:
   ```bash
   copy .env.example .env
   ```
3. Install packages:
   ```bash
   npm install
   ```
4. Run the Vite development server:
   ```bash
   npm run dev
   ```
5. Open your browser to `http://localhost:5173`.

---

## Deployment Settings

### Deploying Frontend (Vercel)
1. Install Vercel CLI: `npm i -g vercel`.
2. Run `vercel` in the `frontend/` directory.
3. Configure the environment variables:
   - `VITE_API_URL`: Your deployed backend API URL (e.g. `https://your-api.onrender.com/api`).
   - `VITE_SOCKET_URL`: Your deployed backend websocket URL (e.g. `https://your-api.onrender.com`).

### Deploying Backend (Render)
1. Create a new Web Service on Render.
2. Point it to your repository, set the root directory as `backend`.
3. Set the build command as `npm install` and start command as `npm start`.
4. Configure the environment variables on the Render dashboard as defined in `backend/.env`.
