@echo off
echo =======================================================
echo   NexusMeet - Local Sharing Tunnel Helper
echo =======================================================
echo.
echo This script will expose your local server to the live internet
echo so anyone can join your meetings from outside your network.
echo.
echo Exposing local frontend (Port 5173) to the internet...
echo.
npx localtunnel --port 5173
echo.
pause
