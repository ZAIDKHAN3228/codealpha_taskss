@echo off
echo =======================================================
echo   NexusMeet - Vercel Direct Deployer (Token Mode)
echo =======================================================
echo.
echo Deploying your frontend folder to Vercel...
echo using the Vercel Auth Token you provided.
echo.
cd /d "%~dp0"
npx vercel --token vcp_4q0CclxhE4QMiS4AShEVAF7ICjCOiQjqQz9ffE8k1V4WF5FtTd4Xu987 --yes --prod
echo.
echo Vercel Deployment Finished.
echo.
pause
