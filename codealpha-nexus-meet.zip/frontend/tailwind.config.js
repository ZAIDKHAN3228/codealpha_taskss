/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        brand: {
          50: '#f0f4ff',
          100: '#d9e2ff',
          200: '#b8c9ff',
          300: '#8ca6ff',
          400: '#5978ff',
          500: '#2546ff', // primary accent
          600: '#0022f5',
          700: '#001bd6',
          800: '#0015b3',
          900: '#000f8f',
        },
        dark: {
          50: '#f3f4f6',
          100: '#e5e7eb',
          200: '#d1d5db',
          800: '#1a1f2c', // glassbg dark
          900: '#0d111a', // main bg dark
          950: '#05070a', // deep dark
        }
      },
      fontFamily: {
        sans: ['Outfit', 'Inter', 'system-ui', 'sans-serif'],
      },
      animation: {
        'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'fade-in': 'fadeIn 0.3s ease-out forwards',
        'slide-up': 'slideUp 0.4s ease-out forwards',
      },
      keyframes: {
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        slideUp: {
          '0%': { transform: 'translateY(15px)', opacity: '0' },
          '100%': { transform: 'translateY(0)', opacity: '1' },
        }
      }
    },
  },
  plugins: [],
}
