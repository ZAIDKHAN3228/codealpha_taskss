import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.jsx'
import './styles/index.css'
import { AuthProvider } from './contexts/AuthContext.jsx'
import { SocketProvider } from './contexts/SocketContext.jsx'
import { WebRTCProvider } from './contexts/WebRTCContext.jsx'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <AuthProvider>
      <SocketProvider>
        <WebRTCProvider>
          <App />
        </WebRTCProvider>
      </SocketProvider>
    </AuthProvider>
  </React.StrictMode>,
)
