import React, { useEffect, useRef, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useWebRTC } from '../contexts/WebRTCContext';
import { useAuth } from '../contexts/AuthContext';
import { useSocket } from '../contexts/SocketContext';
import api from '../services/api';
import ChatPanel from '../components/chat/ChatPanel';
import Whiteboard from '../components/whiteboard/Whiteboard';

import { 
  FiMic, 
  FiMicOff, 
  FiVideo, 
  FiVideoOff, 
  FiShare2, 
  FiPhoneCall, 
  FiUsers, 
  FiMessageSquare, 
  FiEdit, 
  FiCopy, 
  FiUserPlus,
  FiSlash,
  FiAlertOctagon,
  FiMaximize2,
  FiShieldOff
} from 'react-icons/fi';
import { motion, AnimatePresence } from 'framer-motion';

const MeetingRoom = () => {
  const { roomId } = useParams();
  const navigate = useNavigate();
  const socket = useSocket();
  const { user } = useAuth();
  
  const {
    localStream,
    screenStream,
    participants,
    isMuted,
    isCameraOff,
    isScreenSharing,
    isHandRaised,
    joinMeetingRoom,
    leaveMeetingRoom,
    toggleMute,
    toggleCamera,
    toggleScreenShare,
    toggleRaiseHand,
    hostMuteAll,
    hostEndMeeting,
  } = useWebRTC();

  // Local state controls
  const [meetingDetails, setMeetingDetails] = useState(null);
  const [showInviteModal, setShowInviteModal] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  
  // Right panels toggles
  const [activeSidebar, setActiveSidebar] = useState(null); // null, 'chat', 'participants'
  const [showWhiteboard, setShowWhiteboard] = useState(false);
  const [fullscreen, setFullscreen] = useState(false);

  // Active speaker detection state
  const [activeSpeakerSocket, setActiveSpeakerSocket] = useState(null);

  const localVideoRef = useRef(null);
  const remoteVideoRefs = useRef({}); // { [socketId]: HTMLVideoElement }

  // Load meeting metadata
  useEffect(() => {
    const fetchMeeting = async () => {
      try {
        const res = await api.get(`/meetings/${roomId}`);
        if (res.data.success) {
          setMeetingDetails(res.data.meeting);
        }
      } catch (err) {
        console.error('Error fetching meeting info:', err);
      }
    };
    fetchMeeting();
  }, [roomId]);

  // Connect WebRTC and Socket room coordination
  useEffect(() => {
    if (socket && user) {
      // Check if user is host of this meeting room
      const checkIsHost = async () => {
        try {
          const res = await api.get(`/meetings/${roomId}`);
          const isHost = res.data.meeting?.host?._id === (user.id || user._id);
          joinMeetingRoom(roomId, isHost);
        } catch (err) {
          joinMeetingRoom(roomId, false);
        }
      };
      checkIsHost();
      
      return () => {
        leaveMeetingRoom();
      };
    }
  }, [socket, user, roomId]);

  // Sync local stream video output
  useEffect(() => {
    if (localVideoRef.current && localStream) {
      localVideoRef.current.srcObject = localStream;
    }
  }, [localStream, isCameraOff]);

  // Play remote feeds on mount/track updates
  useEffect(() => {
    participants.forEach((p) => {
      const videoEl = remoteVideoRefs.current[p.socketId];
      if (videoEl && p.stream) {
        videoEl.srcObject = p.stream;
      }
    });
  }, [participants]);

  // Listen to remote end-meeting event from server
  useEffect(() => {
    if (!socket) return;
    
    socket.on('meeting-ended', () => {
      alert('The meeting has been ended by the host.');
      navigate('/dashboard');
    });

    return () => {
      socket.off('meeting-ended');
    };
  }, [socket]);

  // Simple active speaker analysis simulation
  // Highlights users speaking based on random mock triggers (or simple audio input readings)
  // To avoid complex browser policy blockages, we mock it, triggering speech periodically
  useEffect(() => {
    const interval = setInterval(() => {
      // Pick a random participant to speak
      if (participants.length > 0) {
        const speakerCandidates = [null, ...participants.map(p => p.socketId)];
        const randomSpeaker = speakerCandidates[Math.floor(Math.random() * speakerCandidates.length)];
        setActiveSpeakerSocket(randomSpeaker);
      } else {
        setActiveSpeakerSocket(null);
      }
    }, 5000);

    return () => clearInterval(interval);
  }, [participants]);

  const copyInviteLink = () => {
    const inviteUrl = `${window.location.origin}/join?code=${roomId}`;
    navigator.clipboard.writeText(inviteUrl);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const handleLeaveCall = () => {
    leaveMeetingRoom();
    navigate('/dashboard');
  };

  const isUserHost = meetingDetails?.host?._id === (user?.id || user?._id);

  // Dynamic Grid sizing styles
  const getGridClass = () => {
    const totalVideos = participants.length + 1; // peers + self
    if (totalVideos === 1) return 'grid-cols-1 max-w-xl mx-auto';
    if (totalVideos === 2) return 'grid-cols-1 md:grid-cols-2 max-w-4xl mx-auto';
    if (totalVideos <= 4) return 'grid-cols-2 max-w-5xl mx-auto';
    return 'grid-cols-2 md:grid-cols-3 max-w-6xl mx-auto';
  };

  const getInitialAvatar = (fullName) => {
    return `https://ui-avatars.com/api/?name=${encodeURIComponent(fullName || '')}&background=2546ff&color=ffffff&size=128&bold=true`;
  };

  return (
    <div className={`h-screen w-screen bg-dark-950 text-slate-100 flex flex-col overflow-hidden font-sans relative ${fullscreen ? 'p-0' : ''}`}>
      
      {/* Top Banner (Header) */}
      {!fullscreen && (
        <header className="px-6 py-3.5 bg-dark-900 border-b border-slate-900 flex justify-between items-center z-10">
          <div>
            <h1 className="text-sm font-bold text-white flex items-center space-x-2">
              <span>{meetingDetails?.meetingName || 'NexusRoom Call'}</span>
              <span className="text-[10px] text-brand-400 bg-brand-500/10 px-2 py-0.5 rounded border border-brand-500/15">HD Secure</span>
            </h1>
            <p className="text-[10px] text-slate-500 mt-0.5">Meeting Code: {roomId}</p>
          </div>
          
          <div className="flex items-center space-x-3">
            <button
              onClick={() => setShowInviteModal(true)}
              className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 transition-all flex items-center space-x-1.5"
            >
              <FiUserPlus className="h-3.5 w-3.5" />
              <span>Invite Members</span>
            </button>
            
            <button
              onClick={() => setFullscreen(!fullscreen)}
              className="p-2 rounded-lg bg-slate-850 hover:bg-slate-750 text-slate-400 hover:text-white transition-all"
              title="Fullscreen mode"
            >
              <FiMaximize2 className="h-4 w-4" />
            </button>
          </div>
        </header>
      )}

      {/* Conference Container */}
      <div className="flex-grow flex relative min-h-0">
        
        {/* Left Side: Video Grid or Shared Whiteboard */}
        <div className="flex-grow flex flex-col justify-center p-6 relative bg-dark-950 min-w-0">
          {showWhiteboard ? (
            /* COLLABORATIVE WHITEBOARD PANEL */
            <div className="h-full w-full max-w-6xl mx-auto flex flex-col">
              <div className="flex justify-between items-center mb-2 px-1">
                <span className="text-xs font-bold text-slate-400">Collaborative Board (Real-Time Sync)</span>
                <button
                  onClick={() => setShowWhiteboard(false)}
                  className="text-xs text-brand-400 hover:text-brand-300 font-semibold"
                >
                  Return to Video Grid
                </button>
              </div>
              <div className="flex-grow min-h-0">
                <Whiteboard roomId={roomId} />
              </div>
            </div>
          ) : (
            /* STANDARD VIDEO CALL GRID */
            <div className={`grid gap-4 w-full h-full content-center max-h-[85%] ${getGridClass()}`}>
              
              {/* LOCAL USER STREAM CARD */}
              <div className={`aspect-video rounded-2xl bg-slate-850 overflow-hidden relative border-2 ${activeSpeakerSocket === 'local' ? 'border-brand-500 shadow-lg shadow-brand-500/10' : 'border-slate-800/60'}`}>
                {isCameraOff ? (
                  <div className="absolute inset-0 flex flex-col items-center justify-center space-y-3">
                    <img 
                      src={user?.avatar || getInitialAvatar(user?.name)} 
                      alt="Avatar" 
                      className="w-16 h-16 rounded-full border border-slate-700 bg-slate-800 object-cover" 
                    />
                    <span className="text-xs text-slate-400 font-semibold">{user?.name} (You)</span>
                  </div>
                ) : (
                  <video
                    ref={localVideoRef}
                    autoPlay
                    playsInline
                    muted
                    className="w-full h-full object-cover transform -scale-x-100"
                  />
                )}
                
                {/* Audio indicators */}
                <div className="absolute bottom-3 left-3 bg-black/60 backdrop-blur px-2.5 py-1 rounded-lg text-[10px] text-slate-300 flex items-center space-x-1">
                  <span>{user?.name} (You)</span>
                  {isMuted && <FiMicOff className="h-3 w-3 text-red-400 ml-1" />}
                </div>

                {isHandRaised && (
                  <div className="absolute top-3 right-3 bg-yellow-500 text-slate-950 p-1.5 rounded-full text-xs font-bold shadow animate-bounce">
                    ✋
                  </div>
                )}
              </div>

              {/* REMOTE PARTICIPANTS STREAM CARDS */}
              {participants.map((peer) => (
                <div 
                  key={peer.socketId}
                  className={`aspect-video rounded-2xl bg-slate-850 overflow-hidden relative border-2 ${activeSpeakerSocket === peer.socketId ? 'border-brand-500 shadow-lg shadow-brand-500/10' : 'border-slate-800/60'}`}
                >
                  {(!peer.isCamActive || !peer.stream) ? (
                    <div className="absolute inset-0 flex flex-col items-center justify-center space-y-3">
                      <img 
                        src={peer.avatar || getInitialAvatar(peer.name)} 
                        alt="Avatar" 
                        className="w-16 h-16 rounded-full border border-slate-700 bg-slate-800 object-cover" 
                      />
                      <span className="text-xs text-slate-400 font-semibold">{peer.name}</span>
                    </div>
                  ) : (
                    <video
                      ref={(el) => (remoteVideoRefs.current[peer.socketId] = el)}
                      autoPlay
                      playsInline
                      className="w-full h-full object-cover"
                    />
                  )}

                  <div className="absolute bottom-3 left-3 bg-black/60 backdrop-blur px-2.5 py-1 rounded-lg text-[10px] text-slate-300 flex items-center space-x-1">
                    <span>{peer.name}</span>
                    {!peer.isMicActive && <FiMicOff className="h-3 w-3 text-red-400 ml-1" />}
                  </div>

                  {peer.isHandRaised && (
                    <div className="absolute top-3 right-3 bg-yellow-500 text-slate-950 p-1.5 rounded-full text-xs font-bold shadow animate-bounce">
                      ✋
                    </div>
                  )}

                  {peer.isHost && (
                    <div className="absolute top-3 left-3 bg-brand-500 text-white px-2 py-0.5 rounded text-[8px] font-bold uppercase tracking-wider">
                      Host
                    </div>
                  )}
                </div>
              ))}

            </div>
          )}
        </div>

        {/* Right Side: Chat or Participants Panel */}
        <AnimatePresence>
          {activeSidebar && (
            <motion.div
              className="w-80 md:w-96 flex-shrink-0 border-l border-slate-900 bg-slate-900 relative z-20 flex flex-col h-full"
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'tween', duration: 0.25 }}
            >
              <div className="p-4 bg-slate-950/20 border-b border-slate-800 flex justify-between items-center">
                <h3 className="text-sm font-bold capitalize text-white">
                  {activeSidebar === 'chat' ? 'Meeting Collaboration' : 'Room Participants'}
                </h3>
                <button
                  onClick={() => setActiveSidebar(null)}
                  className="p-1.5 rounded-lg bg-slate-850 hover:bg-slate-750 text-slate-400 hover:text-white transition-all"
                >
                  <FiX className="h-4 w-4" />
                </button>
              </div>

              <div className="flex-grow min-h-0">
                {activeSidebar === 'chat' ? (
                  <ChatPanel roomId={roomId} />
                ) : (
                  /* PARTICIPANTS SIDEBAR LIST */
                  <div className="p-4 space-y-4 overflow-y-auto h-full custom-scrollbar text-slate-350">
                    <div className="flex justify-between items-center text-xs font-semibold text-slate-500">
                      <span>Total Members</span>
                      <span>{participants.length + 1}</span>
                    </div>

                    {/* Self record */}
                    <div className="flex justify-between items-center p-2 rounded-xl bg-slate-800/20 border border-slate-800">
                      <div className="flex items-center space-x-2.5">
                        <img src={user?.avatar || getInitialAvatar(user?.name)} className="w-8 h-8 rounded-full border border-slate-700 object-cover" />
                        <div>
                          <p className="text-xs font-bold text-white">{user?.name} (You)</p>
                          <p className="text-[9px] text-slate-500">Primary Host</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-1 text-slate-500">
                        {isMuted ? <FiMicOff className="h-3.5 w-3.5 text-red-400" /> : <FiMic className="h-3.5 w-3.5" />}
                        {isCameraOff ? <FiVideoOff className="h-3.5 w-3.5 text-red-400" /> : <FiVideo className="h-3.5 w-3.5" />}
                      </div>
                    </div>

                    {/* Peer records */}
                    {participants.map((peer) => (
                      <div key={peer.socketId} className="flex justify-between items-center p-2 rounded-xl bg-slate-800/10 border border-slate-850">
                        <div className="flex items-center space-x-2.5">
                          <img src={peer.avatar || getInitialAvatar(peer.name)} className="w-8 h-8 rounded-full border border-slate-800 object-cover" />
                          <div>
                            <p className="text-xs font-bold text-slate-200">{peer.name}</p>
                            <p className="text-[9px] text-slate-500">{peer.isHost ? 'Co-Host' : 'Participant'}</p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-1 text-slate-500">
                          {!peer.isMicActive ? <FiMicOff className="h-3.5 w-3.5 text-red-400" /> : <FiMic className="h-3.5 w-3.5" />}
                          {!peer.isCamActive ? <FiVideoOff className="h-3.5 w-3.5 text-red-400" /> : <FiVideo className="h-3.5 w-3.5" />}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

      </div>

      {/* Control Bar (Footer) */}
      <footer className="px-6 py-4.5 bg-dark-900 border-t border-slate-900/60 flex justify-between items-center z-10">
        
        {/* Left Side Controls (Meeting Details info) */}
        <div className="hidden md:flex items-center space-x-2 text-xs text-slate-400 font-semibold">
          <span>{new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
          <span className="text-slate-650">|</span>
          <span className="truncate max-w-[120px]">{meetingDetails?.meetingName || 'NexusRoom'}</span>
        </div>

        {/* Center Controls (Mic, Cam, Share Screen, Board, Hangup) */}
        <div className="flex items-center space-x-2.5 mx-auto md:mx-0">
          {/* Mute Mic button */}
          <button
            onClick={() => toggleMute()}
            className={`p-3.5 rounded-2xl transition-all shadow-md ${isMuted ? 'bg-red-500 hover:bg-red-650 text-white' : 'bg-slate-800 hover:bg-slate-700 text-slate-200'}`}
            title={isMuted ? 'Unmute microphone' : 'Mute microphone'}
          >
            {isMuted ? <FiMicOff className="h-5 w-5" /> : <FiMic className="h-5 w-5" />}
          </button>

          {/* Toggle Camera button */}
          <button
            onClick={toggleCamera}
            className={`p-3.5 rounded-2xl transition-all shadow-md ${isCameraOff ? 'bg-red-500 hover:bg-red-650 text-white' : 'bg-slate-800 hover:bg-slate-700 text-slate-200'}`}
            title={isCameraOff ? 'Start camera' : 'Stop camera'}
          >
            {isCameraOff ? <FiVideoOff className="h-5 w-5" /> : <FiVideo className="h-5 w-5" />}
          </button>

          {/* Share Screen button */}
          <button
            onClick={toggleScreenShare}
            className={`p-3.5 rounded-2xl transition-all shadow-md ${isScreenSharing ? 'bg-brand-500 text-white' : 'bg-slate-800 hover:bg-slate-700 text-slate-200'}`}
            title={isScreenSharing ? 'Stop screen sharing' : 'Share entire screen'}
          >
            <FiShare2 className="h-5 w-5" />
          </button>

          {/* Collaborative Whiteboard button */}
          <button
            onClick={() => setShowWhiteboard(!showWhiteboard)}
            className={`p-3.5 rounded-2xl transition-all shadow-md ${showWhiteboard ? 'bg-brand-500 text-white' : 'bg-slate-800 hover:bg-slate-700 text-slate-200'}`}
            title="Toggle sync whiteboard"
          >
            <FiEdit className="h-5 w-5" />
          </button>

          {/* Raise Hand button */}
          <button
            onClick={toggleRaiseHand}
            className={`p-3.5 rounded-2xl transition-all shadow-md ${isHandRaised ? 'bg-yellow-500 text-slate-950 font-bold' : 'bg-slate-800 hover:bg-slate-700 text-slate-200'}`}
            title="Raise hand"
          >
            ✋
          </button>

          {/* Host Controls Dropdown / Force Mute (Host Only) */}
          {isUserHost && (
            <>
              <button
                onClick={hostMuteAll}
                className="p-3.5 rounded-2xl bg-slate-800 hover:bg-slate-700 text-red-400 hover:text-red-300 transition-all shadow-md"
                title="Mute all other participants (Host Control)"
              >
                <FiSlash className="h-5 w-5" />
              </button>
              
              <button
                onClick={hostEndMeeting}
                className="p-3.5 rounded-2xl bg-red-500/10 hover:bg-red-500/20 text-red-500 hover:text-red-400 border border-red-500/20 transition-all shadow-md"
                title="End meeting for all (Host Control)"
              >
                <FiShieldOff className="h-5 w-5" />
              </button>
            </>
          )}

          <div className="w-px h-6 bg-slate-800 mx-1"></div>

          {/* Leave Call (Standard Hang up) */}
          <button
            onClick={handleLeaveCall}
            className="p-3.5 rounded-2xl bg-red-650 hover:bg-red-700 text-white shadow-lg shadow-red-600/15"
            title="Leave meeting"
          >
            <FiPhoneCall className="h-5 w-5 transform rotate-135" />
          </button>
        </div>

        {/* Right Side Controls (Sidebar toggles: chat, users) */}
        <div className="hidden md:flex items-center space-x-2.5">
          <button
            onClick={() => setActiveSidebar(activeSidebar === 'participants' ? null : 'participants')}
            className={`p-3 rounded-xl transition-all ${activeSidebar === 'participants' ? 'bg-slate-800 text-white' : 'text-slate-400 hover:text-white bg-transparent'}`}
            title="Participant list"
          >
            <FiUsers className="h-5 w-5" />
          </button>
          
          <button
            onClick={() => setActiveSidebar(activeSidebar === 'chat' ? null : 'chat')}
            className={`p-3 rounded-xl transition-all ${activeSidebar === 'chat' ? 'bg-slate-800 text-white' : 'text-slate-400 hover:text-white bg-transparent'}`}
            title="Chat & Files panel"
          >
            <FiMessageSquare className="h-5 w-5" />
          </button>
        </div>

      </footer>

      {/* INVITE MEMBERS MODAL */}
      <AnimatePresence>
        {showInviteModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div 
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowInviteModal(false)}
            />
            
            <motion.div 
              className="w-full max-w-md bg-dark-800 border border-slate-700/40 rounded-2xl p-6 shadow-2xl relative z-10"
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
            >
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-lg font-bold text-white">Invite Members</h3>
                <button 
                  onClick={() => setShowInviteModal(false)}
                  className="p-1.5 rounded-lg bg-slate-850 hover:bg-slate-750 text-slate-400 hover:text-white transition-all"
                >
                  <FiX className="h-4 w-4" />
                </button>
              </div>

              <div className="space-y-5">
                <p className="text-xs text-slate-400">Share this meeting ID or copy the full invite link to send to external users.</p>
                
                {/* Meeting ID display */}
                <div>
                  <span className="block text-[10px] font-semibold text-slate-500 uppercase tracking-wider mb-1.5">Meeting Code ID</span>
                  <div className="flex items-center justify-between p-3 bg-dark-900 border border-slate-750 rounded-xl">
                    <span className="text-sm font-mono font-bold text-brand-400 select-all">{roomId}</span>
                    <button
                      onClick={() => {
                        navigator.clipboard.writeText(roomId);
                        alert('Meeting Code copied to clipboard!');
                      }}
                      className="text-xs text-slate-400 hover:text-white flex items-center space-x-1"
                    >
                      <FiCopy className="h-3.5 w-3.5" />
                      <span>Copy</span>
                    </button>
                  </div>
                </div>

                {/* Invite Link display */}
                <div>
                  <span className="block text-[10px] font-semibold text-slate-500 uppercase tracking-wider mb-1.5">Full Invite Link</span>
                  <div className="flex items-center justify-between p-3 bg-dark-900 border border-slate-750 rounded-xl">
                    <span className="text-xs text-slate-400 truncate max-w-[240px]">{window.location.origin}/join?code={roomId}</span>
                    <button
                      onClick={copyInviteLink}
                      className="text-xs text-brand-400 hover:text-brand-300 font-semibold flex items-center space-x-1 flex-shrink-0 pl-2"
                    >
                      <FiCopy className="h-3.5 w-3.5" />
                      <span>{copiedLink ? 'Copied!' : 'Copy'}</span>
                    </button>
                  </div>
                </div>

                {/* Password if locked */}
                {meetingDetails?.password && (
                  <div className="p-3 bg-yellow-500/10 border border-yellow-500/20 text-yellow-400 text-xs rounded-xl flex items-center space-x-2">
                    <FiAlertOctagon className="h-4 w-4" />
                    <span>This room requires a password: <strong className="font-mono text-white select-all">{meetingDetails.password}</strong></span>
                  </div>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
};

export default MeetingRoom;
