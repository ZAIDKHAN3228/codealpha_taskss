import React, { useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';

const JoinRedirect = () => {
  const [searchParams] = useSearchParams();
  const code = searchParams.get('code');
  const navigate = useNavigate();
  const { user } = useAuth();

  useEffect(() => {
    if (!code) {
      navigate('/dashboard');
      return;
    }

    if (user) {
      // User is logged in, send them straight to the room
      navigate(`/meeting/${code}`);
    } else {
      // User is not logged in, send them to login with details to forward them after auth
      navigate(`/login?code=${code}`);
    }
  }, [code, user, navigate]);

  return (
    <div className="flex h-screen w-screen items-center justify-center bg-dark-900">
      <div className="flex flex-col items-center space-y-4">
        <div className="h-10 w-10 animate-spin rounded-full border-4 border-slate-700 border-t-brand-500"></div>
        <p className="text-slate-400 text-sm font-semibold">Redirecting to meeting room...</p>
      </div>
    </div>
  );
};

export default JoinRedirect;
