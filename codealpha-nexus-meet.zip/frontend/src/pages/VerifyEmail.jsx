import React, { useEffect, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { FiVideo, FiCheckCircle, FiXCircle } from 'react-icons/fi';
import { motion } from 'framer-motion';

const VerifyEmail = () => {
  const [searchParams] = useSearchParams();
  const token = searchParams.get('token');

  const [loadingVerify, setLoadingVerify] = useState(true);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const { verifyEmail } = useAuth();

  useEffect(() => {
    const executeVerify = async () => {
      if (!token) {
        setError('Missing validation token in request URL.');
        setLoadingVerify(false);
        return;
      }

      const result = await verifyEmail(token);
      setLoadingVerify(false);

      if (result.success) {
        setSuccess(result.message);
      } else {
        setError(result.message);
      }
    };
    executeVerify();
  }, [token]);

  return (
    <div className="min-h-screen relative overflow-hidden bg-dark-900 text-slate-100 flex flex-col justify-center items-center px-4">
      <div className="absolute top-[10%] left-[10%] w-[40%] h-[40%] rounded-full gradient-radial-glow opacity-50 pointer-events-none"></div>
      <div className="absolute bottom-[10%] right-[10%] w-[40%] h-[40%] rounded-full gradient-radial-glow opacity-50 pointer-events-none"></div>

      <motion.div 
        className="w-full max-w-md relative z-10"
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="flex flex-col items-center mb-8">
          <Link to="/" className="flex items-center space-x-2">
            <div className="p-2.5 rounded-xl gradient-bg shadow-lg shadow-brand-500/25">
              <FiVideo className="h-6 w-6 text-white" />
            </div>
            <span className="font-sans font-extrabold text-2xl tracking-tight text-white">
              Nexus<span className="text-brand-500">Meet</span>
            </span>
          </Link>
        </div>

        <div className="p-8 rounded-2xl glass-panel shadow-2xl relative border-slate-700/30 text-center">
          <h2 className="text-2xl font-bold font-sans mb-6 text-white">Email Verification</h2>

          {loadingVerify ? (
            <div className="flex flex-col items-center py-6 space-y-4">
              <div className="h-12 w-12 animate-spin rounded-full border-4 border-slate-700 border-t-brand-500"></div>
              <p className="text-slate-400 text-sm">Verifying your email token, please wait...</p>
            </div>
          ) : (
            <div className="space-y-6">
              {success ? (
                <div className="flex flex-col items-center space-y-4">
                  <FiCheckCircle className="h-16 w-16 text-emerald-400" />
                  <p className="text-emerald-400 font-semibold">{success}</p>
                  <p className="text-slate-400 text-sm">Your account is fully verified. You can now access all collaborate features.</p>
                </div>
              ) : (
                <div className="flex flex-col items-center space-y-4">
                  <FiXCircle className="h-16 w-16 text-red-400" />
                  <p className="text-red-400 font-semibold">{error}</p>
                  <p className="text-slate-400 text-sm">The verification code might be expired or already used.</p>
                </div>
              )}

              <div className="pt-6 border-t border-slate-800/60">
                <Link to="/login" className="px-6 py-2.5 rounded-xl gradient-bg font-semibold text-white inline-block text-sm">
                  Go to Login
                </Link>
              </div>
            </div>
          )}
        </div>
      </motion.div>
    </div>
  );
};

export default VerifyEmail;
