import React, { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useWebRTC } from '../contexts/WebRTCContext';
import { FiSettings, FiArrowLeft, FiVideo, FiMic, FiVolume2, FiRefreshCw } from 'react-icons/fi';
import { motion } from 'framer-motion';

const Settings = () => {
  const navigate = useNavigate();
  const {
    devices,
    selectedDevices,
    changeDevice,
  } = useWebRTC();

  const [testStream, setTestStream] = useState(null);
  const [loadingCamera, setLoadingCamera] = useState(false);
  const testVideoRef = useRef(null);

  // Request permissions and play local camera stream for testing
  const startCameraTest = async (deviceId) => {
    setLoadingCamera(true);
    try {
      if (testStream) {
        testStream.getTracks().forEach((track) => track.stop());
      }

      const constraints = {
        video: deviceId ? { deviceId: { exact: deviceId } } : true,
        audio: false, // mute for testing feedback loops
      };

      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      setTestStream(stream);
      if (testVideoRef.current) {
        testVideoRef.current.srcObject = stream;
      }
    } catch (err) {
      console.error('Failed to capture testing camera:', err);
    } finally {
      setLoadingCamera(false);
    }
  };

  // Trigger test on mount or device swaps
  useEffect(() => {
    startCameraTest(selectedDevices.video);

    return () => {
      if (testStream) {
        testStream.getTracks().forEach((track) => track.stop());
      }
    };
  }, [selectedDevices.video]);

  const handleDeviceChange = (type, deviceId) => {
    changeDevice(type, deviceId);
  };

  const refreshHardware = () => {
    window.location.reload();
  };

  return (
    <div className="min-h-screen bg-dark-900 text-slate-100 py-12 px-4 relative overflow-hidden">
      <div className="absolute top-[5%] left-[5%] w-[35%] h-[35%] rounded-full gradient-radial-glow opacity-30 pointer-events-none"></div>

      <div className="max-w-3xl mx-auto relative z-10">
        
        {/* Header Back Link */}
        <div className="flex justify-between items-center mb-8">
          <button
            onClick={() => navigate('/dashboard')}
            className="flex items-center space-x-2 text-slate-400 hover:text-white transition-all text-sm font-semibold"
          >
            <FiArrowLeft className="h-4 w-4" />
            <span>Dashboard</span>
          </button>
          
          <div className="flex items-center space-x-2">
            <FiSettings className="h-5 w-5 text-brand-400" />
            <span className="font-extrabold text-sm tracking-tight text-white">NexusMeet Settings</span>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Left Column: Device Selections */}
          <motion.div
            className="lg:col-span-7 rounded-2xl glass-panel p-8 border-slate-700/30 shadow-2xl space-y-6"
            initial={{ opacity: 0, x: -15 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
          >
            <div className="flex justify-between items-center mb-2">
              <h2 className="text-xl font-bold text-white font-sans">Audio & Video Devices</h2>
              <button
                onClick={refreshHardware}
                title="Refresh hardware lists"
                className="p-2 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white transition-all"
              >
                <FiRefreshCw className="h-4 w-4" />
              </button>
            </div>

            {/* Video Input Select */}
            <div className="space-y-2">
              <label className="text-xs font-semibold uppercase tracking-wider text-slate-400 flex items-center space-x-2">
                <FiVideo className="h-4 w-4 text-brand-400" />
                <span>Camera Device</span>
              </label>
              <select
                value={selectedDevices.video}
                onChange={(e) => handleDeviceChange('video', e.target.value)}
                className="w-full px-4 py-3 rounded-xl bg-dark-900 border border-slate-700/60 focus:border-brand-500 focus:outline-none text-slate-200 text-sm cursor-pointer"
              >
                {devices.video.length === 0 ? (
                  <option value="">No cameras detected</option>
                ) : (
                  devices.video.map((device) => (
                    <option key={device.deviceId} value={device.deviceId}>
                      {device.label || `Camera ${device.deviceId.slice(0, 5)}`}
                    </option>
                  ))
                )}
              </select>
            </div>

            {/* Microphone Input Select */}
            <div className="space-y-2">
              <label className="text-xs font-semibold uppercase tracking-wider text-slate-400 flex items-center space-x-2">
                <FiMic className="h-4 w-4 text-indigo-400" />
                <span>Microphone Device</span>
              </label>
              <select
                value={selectedDevices.audioIn}
                onChange={(e) => handleDeviceChange('audioIn', e.target.value)}
                className="w-full px-4 py-3 rounded-xl bg-dark-900 border border-slate-700/60 focus:border-brand-500 focus:outline-none text-slate-200 text-sm cursor-pointer"
              >
                {devices.audioIn.length === 0 ? (
                  <option value="">No microphones detected</option>
                ) : (
                  devices.audioIn.map((device) => (
                    <option key={device.deviceId} value={device.deviceId}>
                      {device.label || `Microphone ${device.deviceId.slice(0, 5)}`}
                    </option>
                  ))
                )}
              </select>
            </div>

            {/* Speaker Output Select */}
            <div className="space-y-2">
              <label className="text-xs font-semibold uppercase tracking-wider text-slate-400 flex items-center space-x-2">
                <FiVolume2 className="h-4 w-4 text-emerald-400" />
                <span>Speaker Output (Default Browser)</span>
              </label>
              <select
                value={selectedDevices.audioOut}
                onChange={(e) => handleDeviceChange('audioOut', e.target.value)}
                className="w-full px-4 py-3 rounded-xl bg-dark-900 border border-slate-700/60 focus:border-brand-500 focus:outline-none text-slate-200 text-sm cursor-pointer"
              >
                {devices.audioOut.length === 0 ? (
                  <option value="">No speakers detected</option>
                ) : (
                  devices.audioOut.map((device) => (
                    <option key={device.deviceId} value={device.deviceId}>
                      {device.label || `Audio Output ${device.deviceId.slice(0, 5)}`}
                    </option>
                  ))
                )}
              </select>
            </div>
          </motion.div>

          {/* Right Column: Video Preview and Test */}
          <motion.div
            className="lg:col-span-5 flex flex-col space-y-4"
            initial={{ opacity: 0, x: 15 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
          >
            <div className="rounded-2xl glass-panel p-6 border-slate-700/30 shadow-2xl flex-grow flex flex-col justify-between">
              <h3 className="text-sm font-semibold uppercase tracking-wider text-slate-400 mb-3">Camera Preview</h3>
              
              <div className="aspect-[4/3] bg-dark-950 rounded-xl overflow-hidden relative border border-slate-800 flex items-center justify-center">
                {loadingCamera ? (
                  <div className="h-8 w-8 animate-spin rounded-full border-2 border-white/20 border-t-white"></div>
                ) : testStream ? (
                  <video
                    ref={testVideoRef}
                    autoPlay
                    playsInline
                    muted
                    className="w-full h-full object-cover transform -scale-x-100"
                  />
                ) : (
                  <div className="text-slate-600 text-xs flex flex-col items-center space-y-2">
                    <FiVideo className="h-10 w-10 text-slate-700" />
                    <span>Camera output not active</span>
                  </div>
                )}
              </div>
              
              <div className="mt-4 text-center">
                <p className="text-xs text-slate-500">
                  Verify your lighting and camera angle before entering calls. Audio feedback is disabled here to prevent echoing.
                </p>
              </div>
            </div>
          </motion.div>

        </div>
      </div>
    </div>
  );
};

export default Settings;
