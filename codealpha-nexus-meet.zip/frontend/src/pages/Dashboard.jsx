import React, { useEffect, useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import api from '../services/api';
import { 
  FiVideo, 
  FiPlus, 
  FiLink, 
  FiSettings, 
  FiUser, 
  FiLogOut, 
  FiClock, 
  FiCalendar, 
  FiUsers, 
  FiAlertCircle,
  FiX
} from 'react-icons/fi';
import { motion, AnimatePresence } from 'framer-motion';

const Dashboard = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const [history, setHistory] = useState([]);
  const [loadingHistory, setLoadingHistory] = useState(true);

  // Modals visibility
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showJoinModal, setShowJoinModal] = useState(false);

  // Form inputs
  const [meetingName, setMeetingName] = useState('');
  const [meetingPassword, setMeetingPassword] = useState('');
  const [joinMeetingId, setJoinMeetingId] = useState('');
  const [joinPassword, setJoinPassword] = useState('');

  // Form error logs
  const [createError, setCreateError] = useState('');
  const [joinError, setJoinError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  // Fetch meeting histories
  const fetchHistory = async () => {
    try {
      const res = await api.get('/meetings/history');
      if (res.data.success) {
        setHistory(res.data.meetings);
      }
    } catch (err) {
      console.error('Error fetching meeting history:', err);
    } finally {
      setLoadingHistory(false);
    }
  };

  useEffect(() => {
    fetchHistory();
  }, []);

  const handleCreateMeeting = async (e) => {
    e.preventDefault();
    if (!meetingName) {
      setCreateError('Please specify a name for the meeting room.');
      return;
    }
    setCreateError('');
    setSubmitting(true);

    try {
      const res = await api.post('/meetings/create', {
        meetingName,
        password: meetingPassword,
      });

      if (res.data.success) {
        setShowCreateModal(false);
        // Forward user to meeting room
        navigate(`/meeting/${res.data.meeting.meetingId}`);
      }
    } catch (err) {
      if (!err.response) {
        // Local preview mode override
        const mockId = Array.from({ length: 10 }, () => 'abcdefghijklmnopqrstuvwxyz'[Math.floor(Math.random() * 26)]).join('');
        const formattedId = `${mockId.slice(0, 3)}-${mockId.slice(3, 7)}-${mockId.slice(7, 10)}`;
        setShowCreateModal(false);
        navigate(`/meeting/${formattedId}`);
      } else {
        setCreateError(err.response?.data?.message || 'Failed to create meeting room.');
      }
    } finally {
      setSubmitting(false);
    }
  };

  const handleJoinMeeting = async (e) => {
    e.preventDefault();
    if (!joinMeetingId) {
      setJoinError('Please provide a meeting ID.');
      return;
    }
    setJoinError('');
    setSubmitting(true);

    // Clean meeting ID (remove white spaces)
    const cleanId = joinMeetingId.trim().toLowerCase();

    try {
      const res = await api.post('/meetings/join', {
        meetingId: cleanId,
        password: joinPassword,
      });

      if (res.data.success) {
        setShowJoinModal(false);
        navigate(`/meeting/${cleanId}`);
      }
    } catch (err) {
      if (!err.response) {
        setShowJoinModal(false);
        navigate(`/meeting/${cleanId}`);
      } else {
        setJoinError(err.response?.data?.message || 'Failed to join meeting. Verify details.');
      }
    } finally {
      setSubmitting(false);
    }
  };

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const getInitialAvatar = (fullName) => {
    return `https://ui-avatars.com/api/?name=${encodeURIComponent(fullName || '')}&background=2546ff&color=ffffff&size=64&bold=true`;
  };

  return (
    <div className="min-h-screen bg-dark-900 text-slate-100 flex flex-col relative overflow-hidden">
      
      {/* Background Radial Lights */}
      <div className="absolute top-[-10%] right-[-10%] w-[50%] h-[50%] rounded-full gradient-radial-glow opacity-30 pointer-events-none"></div>
      <div className="absolute bottom-[-10%] left-[-10%] w-[50%] h-[50%] rounded-full gradient-radial-glow opacity-30 pointer-events-none"></div>

      {/* Top Navbar */}
      <nav className="border-b border-slate-800/60 bg-dark-900/65 backdrop-blur-md relative z-10">
        <div className="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">
          
          {/* Logo */}
          <Link to="/dashboard" className="flex items-center space-x-2">
            <div className="p-2 rounded-lg gradient-bg">
              <FiVideo className="h-5 w-5 text-white" />
            </div>
            <span className="font-sans font-extrabold text-xl tracking-tight text-white">
              Nexus<span className="text-brand-500">Meet</span>
            </span>
          </Link>

          {/* Right Action Icons */}
          <div className="flex items-center space-x-3">
            <Link 
              to="/settings" 
              title="Settings"
              className="p-2.5 rounded-xl bg-slate-800/65 hover:bg-slate-700/80 text-slate-300 hover:text-white transition-all border border-slate-750"
            >
              <FiSettings className="h-5 w-5" />
            </Link>
            
            {/* User Profile dropdown mock */}
            <div className="flex items-center space-x-3 pl-3 border-l border-slate-800">
              <Link to="/profile" className="flex items-center space-x-2 group">
                <img 
                  src={user?.avatar || getInitialAvatar(user?.name)} 
                  alt="Avatar" 
                  className="w-9 h-9 rounded-full border border-slate-700 object-cover" 
                />
                <span className="hidden md:inline-block text-sm font-semibold text-slate-200 group-hover:text-white transition-all">
                  {user?.name}
                </span>
              </Link>
              
              <button 
                onClick={handleLogout}
                title="Log Out"
                className="p-2.5 rounded-xl bg-red-500/10 hover:bg-red-500/20 text-red-400 transition-all border border-red-500/10"
              >
                <FiLogOut className="h-4 w-4" />
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content Area */}
      <main className="max-w-7xl mx-auto px-6 py-10 flex-grow w-full grid grid-cols-1 lg:grid-cols-12 gap-8 relative z-10">
        
        {/* Left Column: Quick Meeting Actions & Greeting */}
        <section className="lg:col-span-8 space-y-8">
          
          {/* Welcome Card banner */}
          <div className="rounded-2xl glass-panel p-8 relative border-slate-700/30 overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 gradient-radial-glow opacity-40 rounded-full"></div>
            <h1 className="text-3xl font-bold font-sans mb-2 text-white">Hello, {user?.name}!</h1>
            <p className="text-slate-400 text-sm max-w-md">
              Create virtual rooms, draw ideas together, and manage file sharing with high-definition connections.
            </p>
          </div>

          {/* Quick Action Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            
            {/* Create Meeting Card */}
            <div 
              onClick={() => setShowCreateModal(true)}
              className="rounded-2xl glass-panel p-6 border-slate-700/20 shadow-xl cursor-pointer hover:border-brand-500/30 group transition-all"
            >
              <div className="p-4 bg-brand-500/10 text-brand-400 rounded-2xl inline-block mb-4 group-hover:scale-105 transition-transform duration-300">
                <FiPlus className="h-8 w-8" />
              </div>
              <h3 className="text-lg font-bold text-white mb-2">New Meeting</h3>
              <p className="text-slate-400 text-xs leading-relaxed">
                Launch a new call instantly, choose a custom name, lock the room, and get an invite link.
              </p>
            </div>

            {/* Join Meeting Card */}
            <div 
              onClick={() => setShowJoinModal(true)}
              className="rounded-2xl glass-panel p-6 border-slate-700/20 shadow-xl cursor-pointer hover:border-indigo-500/30 group transition-all"
            >
              <div className="p-4 bg-indigo-500/10 text-indigo-400 rounded-2xl inline-block mb-4 group-hover:scale-105 transition-transform duration-300">
                <FiLink className="h-8 w-8" />
              </div>
              <h3 className="text-lg font-bold text-white mb-2">Join with Code</h3>
              <p className="text-slate-400 text-xs leading-relaxed">
                Paste a meeting ID code (e.g. abc-defg-hij) to enter an ongoing call.
              </p>
            </div>

          </div>

          {/* History Lists */}
          <div className="rounded-2xl glass-panel p-6 border-slate-700/30">
            <h3 className="text-lg font-bold text-white font-sans mb-4 flex items-center space-x-2">
              <FiClock className="h-5 w-5 text-brand-400" />
              <span>Recent Meetings</span>
            </h3>

            {loadingHistory ? (
              <div className="flex justify-center py-10">
                <div className="h-8 w-8 animate-spin rounded-full border-2 border-white/20 border-t-brand-500"></div>
              </div>
            ) : history.length === 0 ? (
              <div className="text-center py-12 text-slate-500 text-sm">
                <FiCalendar className="h-10 w-10 text-slate-700 mx-auto mb-3" />
                <span>No previous meetings recorded.</span>
              </div>
            ) : (
              <div className="space-y-3.5 max-h-[300px] overflow-y-auto custom-scrollbar pr-1">
                {history.map((meeting) => (
                  <div 
                    key={meeting._id}
                    className="flex justify-between items-center p-4 rounded-xl bg-slate-800/30 border border-slate-800 hover:border-slate-700/50 hover:bg-slate-800/40 transition-all cursor-pointer"
                    onClick={() => navigate(`/meeting/${meeting.meetingId}`)}
                  >
                    <div>
                      <h4 className="text-sm font-semibold text-slate-200">{meeting.meetingName}</h4>
                      <p className="text-[10px] text-slate-500 mt-1 flex items-center space-x-1">
                        <FiCalendar className="h-3 w-3" />
                        <span>{new Date(meeting.startTime).toLocaleString()}</span>
                      </p>
                    </div>
                    
                    <div className="flex items-center space-x-4">
                      <span className="text-[11px] font-semibold text-slate-400 bg-slate-850 px-2.5 py-1 rounded border border-slate-750">
                        Code: {meeting.meetingId}
                      </span>
                      <div className="flex items-center text-slate-500 text-xs space-x-1" title="Participants list">
                        <FiUsers className="h-3.5 w-3.5" />
                        <span>{meeting.participants?.length || 0}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </section>

        {/* Right Column: Profile summary card */}
        <section className="lg:col-span-4 space-y-6">
          <div className="rounded-2xl glass-panel p-6 border-slate-700/30 text-center space-y-4">
            <div className="relative inline-block">
              <img 
                src={user?.avatar || getInitialAvatar(user?.name)} 
                alt="Profile Avatar" 
                className="w-20 h-20 rounded-full border-2 border-brand-500/35 object-cover bg-slate-800 mx-auto" 
              />
              {user?.isVerified && (
                <span className="absolute bottom-0 right-0 p-1 bg-emerald-500 text-white rounded-full text-[10px] font-bold" title="Verified email account">✓</span>
              )}
            </div>
            
            <div>
              <h3 className="font-bold text-lg text-white">{user?.name}</h3>
              <p className="text-slate-400 text-xs">{user?.email}</p>
            </div>
            
            <div className="border-t border-slate-800/80 pt-4 flex justify-around">
              <Link to="/profile" className="flex flex-col items-center space-y-1 text-slate-400 hover:text-white transition-all text-xs font-semibold">
                <div className="p-2 bg-slate-800/70 rounded-xl mb-1 border border-slate-750">
                  <FiUser className="h-4 w-4" />
                </div>
                <span>Edit Profile</span>
              </Link>
              
              <Link to="/settings" className="flex flex-col items-center space-y-1 text-slate-400 hover:text-white transition-all text-xs font-semibold">
                <div className="p-2 bg-slate-800/70 rounded-xl mb-1 border border-slate-750">
                  <FiSettings className="h-4 w-4" />
                </div>
                <span>Hardware</span>
              </Link>
            </div>
          </div>
        </section>

      </main>

      {/* CREATE MEETING MODAL */}
      <AnimatePresence>
        {showCreateModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            {/* Overlay */}
            <motion.div 
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowCreateModal(false)}
            />
            
            {/* Content Card */}
            <motion.div 
              className="w-full max-w-md bg-dark-800 border border-slate-700/40 rounded-2xl p-6 shadow-2xl relative z-10"
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
            >
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-lg font-bold text-white">Create New Meeting</h3>
                <button 
                  onClick={() => setShowCreateModal(false)}
                  className="p-1.5 rounded-lg bg-slate-850 hover:bg-slate-750 text-slate-400 hover:text-white transition-all"
                >
                  <FiX className="h-4 w-4" />
                </button>
              </div>

              {createError && (
                <div className="mb-4 p-3 rounded-lg bg-red-500/10 border border-red-500/20 text-red-400 text-xs flex items-center space-x-2">
                  <FiAlertCircle className="h-4 w-4 flex-shrink-0" />
                  <span>{createError}</span>
                </div>
              )}

              <form onSubmit={handleCreateMeeting} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold uppercase text-slate-400 mb-1.5">Meeting Name</label>
                  <input
                    type="text"
                    value={meetingName}
                    onChange={(e) => setMeetingName(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-xl bg-dark-900 border border-slate-700 focus:border-brand-500 focus:outline-none text-slate-200 placeholder-slate-600 text-sm"
                    placeholder="Weekly Synced Standup"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase text-slate-400 mb-1.5">Meeting Password (Optional)</label>
                  <input
                    type="password"
                    value={meetingPassword}
                    onChange={(e) => setMeetingPassword(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-xl bg-dark-900 border border-slate-700 focus:border-brand-500 focus:outline-none text-slate-200 placeholder-slate-650 text-sm"
                    placeholder="Leave blank for no password"
                  />
                </div>

                <button
                  type="submit"
                  disabled={submitting}
                  className="w-full py-3 rounded-xl gradient-bg font-semibold text-white shadow-lg hover:shadow-brand-500/25 transition-all text-sm flex justify-center items-center"
                >
                  {submitting ? (
                    <div className="h-5 w-5 animate-spin rounded-full border-2 border-white/20 border-t-white"></div>
                  ) : (
                    'Launch Meeting'
                  )}
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* JOIN MEETING MODAL */}
      <AnimatePresence>
        {showJoinModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div 
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowJoinModal(false)}
            />
            
            <motion.div 
              className="w-full max-w-md bg-dark-800 border border-slate-700/40 rounded-2xl p-6 shadow-2xl relative z-10"
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
            >
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-lg font-bold text-white">Join Meeting</h3>
                <button 
                  onClick={() => setShowJoinModal(false)}
                  className="p-1.5 rounded-lg bg-slate-850 hover:bg-slate-750 text-slate-400 hover:text-white transition-all"
                >
                  <FiX className="h-4 w-4" />
                </button>
              </div>

              {joinError && (
                <div className="mb-4 p-3 rounded-lg bg-red-500/10 border border-red-500/20 text-red-400 text-xs flex items-center space-x-2">
                  <FiAlertCircle className="h-4 w-4 flex-shrink-0" />
                  <span>{joinError}</span>
                </div>
              )}

              <form onSubmit={handleJoinMeeting} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold uppercase text-slate-400 mb-1.5">Meeting Code / ID</label>
                  <input
                    type="text"
                    value={joinMeetingId}
                    onChange={(e) => setJoinMeetingId(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-xl bg-dark-900 border border-slate-700 focus:border-brand-500 focus:outline-none text-slate-200 placeholder-slate-600 text-sm"
                    placeholder="abc-defg-hij"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold uppercase text-slate-400 mb-1.5">Password (If locked)</label>
                  <input
                    type="password"
                    value={joinPassword}
                    onChange={(e) => setJoinPassword(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-xl bg-dark-900 border border-slate-700 focus:border-brand-500 focus:outline-none text-slate-200 placeholder-slate-650 text-sm"
                    placeholder="••••••••"
                  />
                </div>

                <button
                  type="submit"
                  disabled={submitting}
                  className="w-full py-3 rounded-xl gradient-bg font-semibold text-white shadow-lg hover:shadow-brand-500/25 transition-all text-sm flex justify-center items-center"
                >
                  {submitting ? (
                    <div className="h-5 w-5 animate-spin rounded-full border-2 border-white/20 border-t-white"></div>
                  ) : (
                    'Join Call'
                  )}
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
};

export default Dashboard;
