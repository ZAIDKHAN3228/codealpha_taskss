import React, { useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { FiUser, FiMail, FiLock, FiVideo, FiAlertCircle } from 'react-icons/fi';
import { motion } from 'framer-motion';
import GoogleSignInButton from '../components/auth/GoogleSignInButton';

const Register = () => {
  const [searchParams] = useSearchParams();
  const code = searchParams.get('code');

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const { register } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!name || !email || !password || !confirmPassword) {
      setError('Please fill in all fields.');
      return;
    }
    if (password !== confirmPassword) {
      setError('Passwords do not match.');
      return;
    }
    if (password.length < 6) {
      setError('Password must be at least 6 characters.');
      return;
    }

    setError('');
    setSuccess('');
    setSubmitting(true);

    const result = await register(name, email, password);
    setSubmitting(false);

    if (result.success) {
      setSuccess(result.message);
      // Wait 3 seconds then forward to dashboard
      setTimeout(() => {
        navigate('/dashboard');
      }, 3000);
    } else {
      setError(result.message);
    }
  };

  return (
    <div className="min-h-screen relative overflow-hidden bg-dark-900 text-slate-100 flex flex-col justify-center items-center px-4">
      {/* Background Radial Glow */}
      <div className="absolute top-[10%] left-[10%] w-[40%] h-[40%] rounded-full gradient-radial-glow opacity-50 pointer-events-none"></div>
      <div className="absolute bottom-[10%] right-[10%] w-[40%] h-[40%] rounded-full gradient-radial-glow opacity-50 pointer-events-none"></div>

      <motion.div 
        className="w-full max-w-md relative z-10"
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        {/* Brand */}
        <div className="flex flex-col items-center mb-8">
          <Link to="/" className="flex items-center space-x-2">
            <div className="p-2.5 rounded-xl gradient-bg shadow-lg shadow-brand-500/25">
              <FiVideo className="h-6 w-6 text-white" />
            </div>
            <span className="font-sans font-extrabold text-2xl tracking-tight text-white">
              Nexus<span className="text-brand-500">Meet</span>
            </span>
          </Link>
          <p className="text-slate-400 text-sm mt-2">Get started with a free account today</p>
        </div>

        {/* Register Card */}
        <div className="p-8 rounded-2xl glass-panel shadow-2xl relative border-slate-700/30">
          <h2 className="text-2xl font-bold font-sans mb-6 text-center text-white">Create Account</h2>

          {error && (
            <div className="mb-5 p-4 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 text-sm flex items-center space-x-2">
              <FiAlertCircle className="h-5 w-5 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {success && (
            <div className="mb-5 p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-sm">
              {success}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">Full Name</label>
              <div className="relative">
                <FiUser className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-500" />
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full pl-11 pr-4 py-2.5 rounded-xl bg-dark-900 border border-slate-700/60 focus:border-brand-500 focus:ring-2 focus:ring-brand-500/15 focus:outline-none text-slate-200 placeholder-slate-600 transition-all text-sm"
                  placeholder="John Doe"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">Email Address</label>
              <div className="relative">
                <FiMail className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-500" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full pl-11 pr-4 py-2.5 rounded-xl bg-dark-900 border border-slate-700/60 focus:border-brand-500 focus:ring-2 focus:ring-brand-500/15 focus:outline-none text-slate-200 placeholder-slate-600 transition-all text-sm"
                  placeholder="name@company.com"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">Password</label>
              <div className="relative">
                <FiLock className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-500" />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-11 pr-4 py-2.5 rounded-xl bg-dark-900 border border-slate-700/60 focus:border-brand-500 focus:ring-2 focus:ring-brand-500/15 focus:outline-none text-slate-200 placeholder-slate-600 transition-all text-sm"
                  placeholder="•••••••• (Min 6 chars)"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">Confirm Password</label>
              <div className="relative">
                <FiLock className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-500" />
                <input
                  type="password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="w-full pl-11 pr-4 py-2.5 rounded-xl bg-dark-900 border border-slate-700/60 focus:border-brand-500 focus:ring-2 focus:ring-brand-500/15 focus:outline-none text-slate-200 placeholder-slate-600 transition-all text-sm"
                  placeholder="••••••••"
                  required
                />
              </div>
            </div>
            <button
              type="submit"
              disabled={submitting}
              className="w-full py-3 rounded-xl gradient-bg font-semibold text-white shadow-lg shadow-brand-500/15 hover:shadow-brand-500/30 hover:-translate-y-0.5 active:translate-y-0 disabled:-translate-y-0 disabled:opacity-50 disabled:shadow-none transition-all flex justify-center items-center text-sm pt-3.5 pb-3.5"
            >
              {submitting ? (
                <div className="h-5 w-5 animate-spin rounded-full border-2 border-white/30 border-t-white"></div>
              ) : (
                'Sign Up'
              )}
            </button>
          </form>

          <div className="relative flex items-center justify-center my-5">
            <div className="border-t border-slate-800/80 w-full"></div>
            <span className="absolute bg-[#161a25] px-3 text-slate-500 text-xs font-semibold">OR</span>
          </div>

          <GoogleSignInButton code={code} />

          <div className="mt-8 text-center text-sm border-t border-slate-800/60 pt-6">
            <span className="text-slate-500">Already have an account? </span>
            <Link to="/login" className="text-brand-400 hover:text-brand-300 font-semibold">Sign In</Link>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default Register;
