import React, { useState, useRef } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { FiUser, FiArrowLeft, FiCamera, FiVideo, FiCheckCircle, FiAlertCircle } from 'react-icons/fi';
import { motion } from 'framer-motion';

const Profile = () => {
  const { user, updateProfile } = useAuth();
  const navigate = useNavigate();

  const [name, setName] = useState(user?.name || '');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [avatarPreview, setAvatarPreview] = useState(user?.avatar || '');
  const [avatarFile, setAvatarFile] = useState(null);

  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const fileInputRef = useRef(null);

  // Fallback initial avatar generator
  const getInitialAvatar = (fullName) => {
    const initials = fullName
      ?.split(' ')
      .map((n) => n[0])
      .slice(0, 2)
      .join('')
      .toUpperCase();
    return `https://ui-avatars.com/api/?name=${encodeURIComponent(fullName || '')}&background=2546ff&color=ffffff&size=128&font-size=0.35&bold=true`;
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      // Validate file size and type
      if (file.size > 5 * 1024 * 1024) {
        setError('Avatar file must be less than 5MB.');
        return;
      }
      if (!file.type.startsWith('image/')) {
        setError('Avatar file must be an image.');
        return;
      }

      setAvatarFile(file);
      setError('');
      
      // Read file for preview
      const reader = new FileReader();
      reader.onloadend = () => {
        setAvatarPreview(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!name) {
      setError('Name is required.');
      return;
    }
    if (password && password.length < 6) {
      setError('Password must be at least 6 characters.');
      return;
    }
    if (password !== confirmPassword) {
      setError('New passwords do not match.');
      return;
    }

    setError('');
    setSuccess('');
    setSubmitting(true);

    // Prepare multipart form data
    const formData = new FormData();
    formData.append('name', name);
    if (password) {
      formData.append('password', password);
    }
    if (avatarFile) {
      formData.append('avatar', avatarFile);
    }

    const result = await updateProfile(formData);
    setSubmitting(false);

    if (result.success) {
      setSuccess(result.message);
      setPassword('');
      confirmPassword('');
    } else {
      setError(result.message);
    }
  };

  return (
    <div className="min-h-screen bg-dark-900 text-slate-100 py-12 px-4 relative overflow-hidden">
      {/* Background Radiants */}
      <div className="absolute top-[5%] left-[5%] w-[35%] h-[35%] rounded-full gradient-radial-glow opacity-30 pointer-events-none"></div>

      <div className="max-w-xl mx-auto relative z-10">
        
        {/* Header Back Link */}
        <div className="flex justify-between items-center mb-8">
          <button
            onClick={() => navigate('/dashboard')}
            className="flex items-center space-x-2 text-slate-400 hover:text-white transition-all text-sm font-semibold"
          >
            <FiArrowLeft className="h-4 w-4" />
            <span>Dashboard</span>
          </button>
          
          <div className="flex items-center space-x-2">
            <FiVideo className="h-5 w-5 text-brand-400" />
            <span className="font-extrabold text-sm tracking-tight text-white">NexusMeet</span>
          </div>
        </div>

        {/* Profile Card */}
        <motion.div
          className="rounded-2xl glass-panel p-8 border-slate-700/30 shadow-2xl"
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <h2 className="text-2xl font-bold font-sans text-white mb-6">User Profile Settings</h2>

          {error && (
            <div className="mb-5 p-4 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 text-sm flex items-center space-x-2">
              <FiAlertCircle className="h-5 w-5 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {success && (
            <div className="mb-5 p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-sm flex items-center space-x-2">
              <FiCheckCircle className="h-5 w-5 flex-shrink-0" />
              <span>{success}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-6">
            
            {/* Avatar Upload Center */}
            <div className="flex flex-col items-center space-y-3">
              <div className="relative group cursor-pointer" onClick={() => fileInputRef.current.click()}>
                <img
                  src={avatarPreview || getInitialAvatar(user?.name)}
                  alt="Profile Avatar"
                  className="w-28 h-28 rounded-full border-2 border-brand-500/40 object-cover bg-slate-800"
                />
                <div className="absolute inset-0 bg-black/60 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                  <FiCamera className="h-6 w-6 text-white" />
                </div>
              </div>
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleFileChange}
                accept="image/*"
                className="hidden"
              />
              <button
                type="button"
                onClick={() => fileInputRef.current.click()}
                className="text-xs text-brand-400 hover:text-brand-300 font-semibold"
              >
                Change Avatar Image
              </button>
            </div>

            {/* Email (Read Only) */}
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">Email Address (Primary)</label>
              <input
                type="email"
                disabled
                value={user?.email || ''}
                className="w-full px-4 py-3 rounded-xl bg-dark-950 border border-slate-800 text-slate-500 text-sm outline-none cursor-not-allowed"
              />
              <p className="text-[10px] text-slate-500 mt-1.5">For security reasons, your email address is locked and cannot be changed.</p>
            </div>

            {/* Full Name */}
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">Display Name</label>
              <div className="relative">
                <FiUser className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-500" />
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full pl-11 pr-4 py-3 rounded-xl bg-dark-900 border border-slate-700/60 focus:border-brand-500 focus:ring-2 focus:ring-brand-500/15 focus:outline-none text-slate-200 placeholder-slate-600 transition-all text-sm"
                  placeholder="John Doe"
                  required
                />
              </div>
            </div>

            <div className="border-t border-slate-850 my-6 pt-6">
              <h3 className="text-sm font-semibold text-white mb-4 uppercase tracking-wider">Change Password</h3>
              <p className="text-xs text-slate-400 mb-4">Leave fields blank if you do not want to update password.</p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">New Password</label>
                  <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-xl bg-dark-900 border border-slate-700/60 focus:border-brand-500 focus:ring-2 focus:ring-brand-500/15 focus:outline-none text-slate-200 placeholder-slate-600 transition-all text-sm"
                    placeholder="••••••••"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">Confirm Password</label>
                  <input
                    type="password"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    className="w-full px-4 py-2.5 rounded-xl bg-dark-900 border border-slate-700/60 focus:border-brand-500 focus:ring-2 focus:ring-brand-500/15 focus:outline-none text-slate-200 placeholder-slate-600 transition-all text-sm"
                    placeholder="••••••••"
                  />
                </div>
              </div>
            </div>

            <button
              type="submit"
              disabled={submitting}
              className="w-full py-3.5 rounded-xl gradient-bg font-semibold text-white shadow-lg shadow-brand-500/15 hover:shadow-brand-500/30 hover:-translate-y-0.5 active:translate-y-0 disabled:-translate-y-0 disabled:opacity-50 disabled:shadow-none transition-all flex justify-center items-center text-sm"
            >
              {submitting ? (
                <div className="h-5 w-5 animate-spin rounded-full border-2 border-white/30 border-t-white"></div>
              ) : (
                'Save Changes'
              )}
            </button>
          </form>
        </motion.div>
      </div>
    </div>
  );
};

export default Profile;
