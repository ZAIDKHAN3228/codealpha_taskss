import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { FiVideo, FiShield, FiMessageSquare, FiEdit3, FiShare2, FiArrowRight } from 'react-icons/fi';

const Landing = () => {
  return (
    <div className="min-h-screen relative overflow-hidden bg-dark-900 text-slate-100 flex flex-col justify-between">
      
      {/* Background Radial Glow */}
      <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] rounded-full gradient-radial-glow opacity-60 pointer-events-none"></div>
      <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] rounded-full gradient-radial-glow opacity-60 pointer-events-none"></div>

      {/* Header */}
      <header className="container mx-auto px-6 py-6 flex justify-between items-center relative z-10">
        <div className="flex items-center space-x-2">
          <div className="p-2.5 rounded-xl gradient-bg shadow-lg shadow-brand-500/25">
            <FiVideo className="h-6 w-6 text-white" />
          </div>
          <span className="font-sans font-extrabold text-2xl tracking-tight text-white">
            Nexus<span className="text-brand-500">Meet</span>
          </span>
        </div>
        
        <div className="flex items-center space-x-4">
          <Link to="/login" className="px-4 py-2 text-sm font-semibold text-slate-300 hover:text-white transition-all">
            Sign In
          </Link>
          <Link to="/register" className="px-5 py-2 text-sm font-semibold rounded-xl bg-slate-800 border border-slate-700/60 hover:bg-slate-700 hover:border-slate-600 text-white transition-all shadow-md">
            Get Started
          </Link>
        </div>
      </header>

      {/* Hero Section */}
      <main className="container mx-auto px-6 py-12 flex-grow flex flex-col lg:flex-row items-center justify-between relative z-10">
        
        {/* Left Column: Copy */}
        <motion.div 
          className="lg:w-1/2 space-y-6 text-center lg:text-left"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <div className="inline-flex items-center space-x-2 px-3 py-1.5 rounded-full glass-panel text-xs text-brand-300 font-semibold border-brand-500/20">
            <span className="flex h-2 w-2 rounded-full bg-brand-500 animate-pulse"></span>
            <span>Next-Generation Video Calls</span>
          </div>

          <h1 className="text-4xl md:text-5xl lg:text-6xl font-sans font-extrabold tracking-tight leading-tight">
            Connect. Collaborate.<br />
            <span className="gradient-text">Without Limits.</span>
          </h1>

          <p className="text-slate-400 text-lg md:text-xl max-w-xl mx-auto lg:mx-0">
            Experience ultra-low latency, HD audio-video, interactive whiteboard sync, and encrypted file sharing, all combined into a premium web ecosystem.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start space-y-4 sm:space-y-0 sm:space-x-4 pt-4">
            <Link 
              to="/register" 
              className="w-full sm:w-auto px-8 py-4 rounded-xl gradient-bg font-semibold text-white shadow-xl shadow-brand-500/20 hover:shadow-brand-500/40 hover:-translate-y-0.5 active:translate-y-0 transition-all flex items-center justify-center space-x-2"
            >
              <span>Create Free Account</span>
              <FiArrowRight className="h-4 w-4" />
            </Link>
            <Link 
              to="/login" 
              className="w-full sm:w-auto px-8 py-4 rounded-xl bg-dark-800 border border-slate-700/60 font-semibold text-slate-200 hover:bg-slate-700/50 hover:text-white transition-all flex items-center justify-center"
            >
              Join a Meeting
            </Link>
          </div>
        </motion.div>

        {/* Right Column: Mockup Image */}
        <motion.div 
          className="lg:w-1/2 mt-12 lg:mt-0 relative flex justify-center"
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, delay: 0.1 }}
        >
          {/* Decorative Backdrops */}
          <div className="absolute w-[80%] h-[80%] bg-brand-500/10 filter blur-[80px] rounded-full top-10 left-10 pointer-events-none"></div>
          
          {/* Application Screen mockup */}
          <div className="w-[90%] md:w-[80%] aspect-[16/10] glass-panel rounded-2xl p-3 shadow-2xl relative border-slate-700/40">
            <div className="flex items-center space-x-1.5 mb-3 px-1">
              <span className="w-3 h-3 rounded-full bg-red-500/70 inline-block"></span>
              <span className="w-3 h-3 rounded-full bg-yellow-500/70 inline-block"></span>
              <span className="w-3 h-3 rounded-full bg-green-500/70 inline-block"></span>
            </div>
            
            {/* Inner Mockup Grid */}
            <div className="w-full h-[calc(100%-24px)] bg-dark-950 rounded-xl overflow-hidden relative p-4 flex flex-col justify-between">
              
              {/* Fake Video Grid */}
              <div className="grid grid-cols-2 gap-3 flex-grow">
                <div className="rounded-lg bg-slate-800/40 relative flex items-center justify-center border border-slate-700/20">
                  <div className="w-12 h-12 rounded-full bg-brand-500/20 flex items-center justify-center text-brand-300 font-bold">JD</div>
                  <span className="absolute bottom-2 left-2 px-2 py-0.5 bg-slate-900/60 rounded text-[10px] text-slate-300">John Doe (You)</span>
                </div>
                <div className="rounded-lg bg-slate-800/40 relative flex items-center justify-center border border-slate-700/20">
                  <div className="w-12 h-12 rounded-full bg-indigo-500/20 flex items-center justify-center text-indigo-300 font-bold">AS</div>
                  <span className="absolute bottom-2 left-2 px-2 py-0.5 bg-slate-900/60 rounded text-[10px] text-slate-300">Alice Smith</span>
                </div>
              </div>

              {/* Control Bar Mockup */}
              <div className="mt-3 flex justify-center space-x-2.5">
                <span className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center text-xs text-slate-300">🎙️</span>
                <span className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center text-xs text-slate-300">📹</span>
                <span className="w-8 h-8 rounded-full bg-brand-500 flex items-center justify-center text-xs text-white">🖥️</span>
                <span className="w-8 h-8 rounded-full bg-red-500 flex items-center justify-center text-xs text-white">📞</span>
              </div>
            </div>
          </div>
        </motion.div>
      </main>

      {/* Features Grid */}
      <section className="container mx-auto px-6 py-16 relative z-10 border-t border-slate-800/50">
        <div className="text-center space-y-3 mb-12">
          <h2 className="text-2xl md:text-3xl font-bold font-sans">Powering Collaborative Work</h2>
          <p className="text-slate-400 max-w-lg mx-auto">Everything you need to meet, coordinate, and finalize ideas in real-time.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="p-6 rounded-2xl glass-card text-left space-y-4">
            <div className="p-3 bg-brand-500/10 text-brand-400 rounded-xl inline-block">
              <FiVideo className="h-6 w-6" />
            </div>
            <h3 className="text-lg font-bold">HD Video Conferences</h3>
            <p className="text-slate-400 text-sm">Experience crisp high-definition video connections with automatic hardware tuning.</p>
          </div>

          <div className="p-6 rounded-2xl glass-card text-left space-y-4">
            <div className="p-3 bg-indigo-500/10 text-indigo-400 rounded-xl inline-block">
              <FiShare2 className="h-6 w-6" />
            </div>
            <h3 className="text-lg font-bold">WebRTC Screen Share</h3>
            <p className="text-slate-400 text-sm">Present folders, applications, or browser tabs with dynamic quality adjustments.</p>
          </div>

          <div className="p-6 rounded-2xl glass-card text-left space-y-4">
            <div className="p-3 bg-blue-500/10 text-blue-400 rounded-xl inline-block">
              <FiEdit3 className="h-6 w-6" />
            </div>
            <h3 className="text-lg font-bold">Sync Whiteboard</h3>
            <p className="text-slate-400 text-sm">Sketch, take sticky notes, draw shapes, and export work with other members instantly.</p>
          </div>

          <div className="p-6 rounded-2xl glass-card text-left space-y-4">
            <div className="p-3 bg-emerald-500/10 text-emerald-400 rounded-xl inline-block">
              <FiMessageSquare className="h-6 w-6" />
            </div>
            <h3 className="text-lg font-bold">File-Sharing Chat</h3>
            <p className="text-slate-400 text-sm">Drop images, PDFs, slides, and zip folders directly in chat while keeping full control.</p>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="container mx-auto px-6 py-6 border-t border-slate-800/30 text-center text-slate-500 text-xs relative z-10 flex flex-col md:flex-row justify-between items-center space-y-3 md:space-y-0">
        <span>© {new Date().getFullYear()} NexusMeet. Developed with pairs on Google Antigravity.</span>
        <div className="flex space-x-4">
          <a href="#" className="hover:text-slate-300">Privacy Policy</a>
          <a href="#" className="hover:text-slate-300">Terms of Use</a>
          <a href="#" className="hover:text-slate-300">Help Desk</a>
        </div>
      </footer>
    </div>
  );
};

export default Landing;
