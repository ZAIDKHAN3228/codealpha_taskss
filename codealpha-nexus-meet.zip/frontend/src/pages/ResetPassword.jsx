import React, { useState } from 'react';
import { Link, useSearchParams, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { FiLock, FiVideo, FiAlertCircle, FiCheckCircle } from 'react-icons/fi';
import { motion } from 'framer-motion';

const ResetPassword = () => {
  const [searchParams] = useSearchParams();
  const token = searchParams.get('token');
  const navigate = useNavigate();

  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const { resetPassword } = useAuth();

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!token) {
      setError('Invalid reset link: Missing token.');
      return;
    }
    if (!password || !confirmPassword) {
      setError('Please fill in all fields.');
      return;
    }
    if (password !== confirmPassword) {
      setError('Passwords do not match.');
      return;
    }
    if (password.length < 6) {
      setError('Password must be at least 6 characters.');
      return;
    }

    setError('');
    setSuccess('');
    setSubmitting(true);

    const result = await resetPassword(token, password);
    setSubmitting(false);

    if (result.success) {
      setSuccess(result.message);
      // Wait 3 seconds, redirect to login
      setTimeout(() => {
        navigate('/login');
      }, 3000);
    } else {
      setError(result.message);
    }
  };

  return (
    <div className="min-h-screen relative overflow-hidden bg-dark-900 text-slate-100 flex flex-col justify-center items-center px-4">
      <div className="absolute top-[10%] left-[10%] w-[40%] h-[40%] rounded-full gradient-radial-glow opacity-50 pointer-events-none"></div>
      <div className="absolute bottom-[10%] right-[10%] w-[40%] h-[40%] rounded-full gradient-radial-glow opacity-50 pointer-events-none"></div>

      <motion.div 
        className="w-full max-w-md relative z-10"
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="flex flex-col items-center mb-8">
          <Link to="/" className="flex items-center space-x-2">
            <div className="p-2.5 rounded-xl gradient-bg shadow-lg shadow-brand-500/25">
              <FiVideo className="h-6 w-6 text-white" />
            </div>
            <span className="font-sans font-extrabold text-2xl tracking-tight text-white">
              Nexus<span className="text-brand-500">Meet</span>
            </span>
          </Link>
        </div>

        <div className="p-8 rounded-2xl glass-panel shadow-2xl relative border-slate-700/30">
          <h2 className="text-2xl font-bold font-sans mb-3 text-center text-white">Reset Password</h2>
          <p className="text-slate-400 text-sm text-center mb-6">Create a strong new password for your account.</p>

          {!token && (
            <div className="mb-5 p-4 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 text-sm">
              Critical Warning: Password reset link is missing a valid security token. Access denied.
            </div>
          )}

          {error && (
            <div className="mb-5 p-4 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 text-sm flex items-center space-x-2">
              <FiAlertCircle className="h-5 w-5 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {success && (
            <div className="mb-5 p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-sm flex items-center space-x-2">
              <FiCheckCircle className="h-5 w-5 flex-shrink-0" />
              <span>{success}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">New Password</label>
              <div className="relative">
                <FiLock className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-500" />
                <input
                  type="password"
                  disabled={!token}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-11 pr-4 py-2.5 rounded-xl bg-dark-900 border border-slate-700/60 focus:border-brand-500 focus:ring-2 focus:ring-brand-500/15 focus:outline-none text-slate-200 placeholder-slate-600 transition-all text-sm disabled:opacity-40"
                  placeholder="••••••••"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">Confirm New Password</label>
              <div className="relative">
                <FiLock className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-500" />
                <input
                  type="password"
                  disabled={!token}
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="w-full pl-11 pr-4 py-2.5 rounded-xl bg-dark-900 border border-slate-700/60 focus:border-brand-500 focus:ring-2 focus:ring-brand-500/15 focus:outline-none text-slate-200 placeholder-slate-600 transition-all text-sm disabled:opacity-40"
                  placeholder="••••••••"
                  required
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={submitting || !token}
              className="w-full py-3.5 rounded-xl gradient-bg font-semibold text-white shadow-lg shadow-brand-500/15 hover:shadow-brand-500/30 hover:-translate-y-0.5 active:translate-y-0 disabled:-translate-y-0 disabled:opacity-50 disabled:shadow-none transition-all flex justify-center items-center text-sm"
            >
              {submitting ? (
                <div className="h-5 w-5 animate-spin rounded-full border-2 border-white/30 border-t-white"></div>
              ) : (
                'Save Password'
              )}
            </button>
          </form>

          <div className="mt-8 text-center text-sm border-t border-slate-800/60 pt-6">
            <span className="text-slate-500">Go back to </span>
            <Link to="/login" className="text-brand-400 hover:text-brand-300 font-semibold">Sign In</Link>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default ResetPassword;
