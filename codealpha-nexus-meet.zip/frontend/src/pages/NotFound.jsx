import React from 'react';
import { Link } from 'react-router-dom';
import { FiVideo, FiHome } from 'react-icons/fi';
import { motion } from 'framer-motion';

const NotFound = () => {
  return (
    <div className="min-h-screen relative overflow-hidden bg-dark-900 text-slate-100 flex flex-col justify-center items-center px-4">
      <div className="absolute top-[10%] left-[10%] w-[40%] h-[40%] rounded-full gradient-radial-glow opacity-50 pointer-events-none"></div>
      <div className="absolute bottom-[10%] right-[10%] w-[40%] h-[40%] rounded-full gradient-radial-glow opacity-50 pointer-events-none"></div>

      <motion.div 
        className="w-full max-w-md relative z-10 text-center"
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5 }}
      >
        <div className="flex flex-col items-center mb-8">
          <Link to="/" className="flex items-center space-x-2">
            <div className="p-2.5 rounded-xl gradient-bg shadow-lg shadow-brand-500/25">
              <FiVideo className="h-6 w-6 text-white" />
            </div>
            <span className="font-sans font-extrabold text-2xl tracking-tight text-white">
              Nexus<span className="text-brand-500">Meet</span>
            </span>
          </Link>
        </div>

        <div className="p-8 rounded-2xl glass-panel shadow-2xl relative border-slate-700/30">
          <h1 className="text-7xl font-extrabold tracking-tight gradient-text mb-4">404</h1>
          <h2 className="text-xl font-bold font-sans mb-3 text-white">Page Not Found</h2>
          <p className="text-slate-400 text-sm mb-6">
            The page you are looking for doesn't exist or has been moved to a different meeting ID.
          </p>

          <Link
            to="/dashboard"
            className="inline-flex items-center space-x-2 px-6 py-3 rounded-xl gradient-bg font-semibold text-white shadow-lg shadow-brand-500/15 hover:shadow-brand-500/30 hover:-translate-y-0.5 active:translate-y-0 transition-all text-sm"
          >
            <FiHome className="h-4 w-4" />
            <span>Go to Dashboard</span>
          </Link>
        </div>
      </motion.div>
    </div>
  );
};

export default NotFound;
