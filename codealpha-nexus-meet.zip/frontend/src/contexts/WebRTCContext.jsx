import React, { createContext, useContext, useEffect, useRef, useState } from 'react';
import { useSocket } from './SocketContext';
import { useAuth } from './AuthContext';

const WebRTCContext = createContext(null);

// ICE Server configurations (using free Google STUN servers)
const rtcConfig = {
  iceServers: [
    { urls: 'stun:stun.l.google.com:19302' },
    { urls: 'stun:stun1.l.google.com:19302' },
    { urls: 'stun:stun2.l.google.com:19302' },
  ],
};

export const WebRTCProvider = ({ children }) => {
  const socket = useSocket();
  const { user } = useAuth();

  const [localStream, setLocalStream] = useState(null);
  const [screenStream, setScreenStream] = useState(null);
  
  // Array of active participants: { socketId, userId, name, avatar, stream, isMicActive, isCamActive, isScreenSharing, isHandRaised, isHost }
  const [participants, setParticipants] = useState([]);
  
  // Track system status
  const [isMuted, setIsMuted] = useState(false);
  const [isCameraOff, setIsCameraOff] = useState(false);
  const [isScreenSharing, setIsScreenSharing] = useState(false);
  const [isHandRaised, setIsHandRaised] = useState(false);
  
  // Devices lists
  const [devices, setDevices] = useState({ video: [], audioIn: [], audioOut: [] });
  const [selectedDevices, setSelectedDevices] = useState({ video: '', audioIn: '', audioOut: '' });
  
  // Peer connections dictionary: peers.current[socketId] = RTCPeerConnection
  const peers = useRef({});
  
  // Local stream ref to read inside listeners without stale state closure
  const localStreamRef = useRef(null);

  // Load available devices
  const getDevices = async () => {
    try {
      const deviceInfos = await navigator.mediaDevices.enumerateDevices();
      const video = [];
      const audioIn = [];
      const audioOut = [];

      deviceInfos.forEach((info) => {
        if (info.kind === 'videoinput') video.push(info);
        else if (info.kind === 'audioinput') audioIn.push(info);
        else if (info.kind === 'audiooutput') audioOut.push(info);
      });

      setDevices({ video, audioIn, audioOut });

      // Select default devices if none chosen
      setSelectedDevices((prev) => ({
        video: prev.video || video[0]?.deviceId || '',
        audioIn: prev.audioIn || audioIn[0]?.deviceId || '',
        audioOut: prev.audioOut || audioOut[0]?.deviceId || '',
      }));
    } catch (err) {
      console.error('Error listing hardware devices:', err);
    }
  };

  // Start local audio & video capture
  const startLocalStream = async (customConstraints = {}) => {
    try {
      // Close previous stream if open
      if (localStreamRef.current) {
        localStreamRef.current.getTracks().forEach((track) => track.stop());
      }

      const constraints = {
        video: customConstraints.videoDeviceId
          ? { deviceId: { exact: customConstraints.videoDeviceId } }
          : { width: { ideal: 1280 }, height: { ideal: 720 } },
        audio: customConstraints.audioDeviceId
          ? { deviceId: { exact: customConstraints.audioDeviceId } }
          : true,
      };

      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      localStreamRef.current = stream;
      setLocalStream(stream);

      // Track toggles
      if (isMuted) {
        stream.getAudioTracks().forEach(t => t.enabled = false);
      }
      if (isCameraOff) {
        stream.getVideoTracks().forEach(t => t.enabled = false);
      }

      // Re-query devices to get labels (permitted now that getUserMedia has run)
      await getDevices();

      return stream;
    } catch (err) {
      console.error('Failed to get media devices:', err);
      // Fallback: request audio-only or video-only if one fails
      try {
        const fallbackStream = await navigator.mediaDevices.getUserMedia({ audio: true });
        localStreamRef.current = fallbackStream;
        setLocalStream(fallbackStream);
        setIsCameraOff(true);
        return fallbackStream;
      } catch (fallbackErr) {
        console.error('Total local media acquisition failed:', fallbackErr);
        return null;
      }
    }
  };

  // Hot-swap media hardware (camera or microphone)
  const changeDevice = async (type, deviceId) => {
    setSelectedDevices((prev) => ({ ...prev, [type]: deviceId }));
    
    // Restart local stream with new deviceId
    const newStream = await startLocalStream({
      videoDeviceId: type === 'video' ? deviceId : selectedDevices.video,
      audioDeviceId: type === 'audioIn' ? deviceId : selectedDevices.audioIn,
    });

    if (newStream) {
      // Replace tracks in all active peer connections
      const videoTrack = newStream.getVideoTracks()[0];
      const audioTrack = newStream.getAudioTracks()[0];

      Object.values(peers.current).forEach((peerConnection) => {
        const senders = peerConnection.getSenders();
        if (videoTrack) {
          const videoSender = senders.find((s) => s.track?.kind === 'video');
          if (videoSender) videoSender.replaceTrack(videoTrack);
        }
        if (audioTrack) {
          const audioSender = senders.find((s) => s.track?.kind === 'audio');
          if (audioSender) audioSender.replaceTrack(audioTrack);
        }
      });
    }
  };

  // Create an RTCPeerConnection
  const createPeerConnection = (targetSocketId, targetUserMetadata, currentStream) => {
    const pc = new RTCPeerConnection(rtcConfig);

    // Add local tracks to connection
    if (currentStream) {
      currentStream.getTracks().forEach((track) => {
        pc.addTrack(track, currentStream);
      });
    }

    // Ice candidate callback
    pc.onicecandidate = (event) => {
      if (event.candidate && socket) {
        socket.emit('webrtc-ice-candidate', {
          targetSocketId,
          candidate: event.candidate,
        });
      }
    };

    // Track received callback
    pc.ontrack = (event) => {
      console.log(`Received remote track from ${targetSocketId}`);
      const remoteStream = event.streams[0] || new MediaStream([event.track]);

      setParticipants((prev) => {
        const idx = prev.findIndex((p) => p.socketId === targetSocketId);
        if (idx !== -1) {
          const updated = [...prev];
          updated[idx] = { ...updated[idx], stream: remoteStream };
          return updated;
        } else {
          return [
            ...prev,
            {
              socketId: targetSocketId,
              userId: targetUserMetadata.userId,
              name: targetUserMetadata.name,
              avatar: targetUserMetadata.avatar,
              stream: remoteStream,
              isMicActive: targetUserMetadata.isMicActive ?? true,
              isCamActive: targetUserMetadata.isCamActive ?? true,
              isScreenSharing: targetUserMetadata.isScreenSharing ?? false,
              isHandRaised: targetUserMetadata.isHandRaised ?? false,
              isHost: targetUserMetadata.isHost ?? false,
            },
          ];
        }
      });
    };

    pc.onconnectionstatechange = () => {
      console.log(`Connection state with ${targetSocketId}: ${pc.connectionState}`);
      if (pc.connectionState === 'disconnected' || pc.connectionState === 'failed') {
        removeParticipant(targetSocketId);
      }
    };

    peers.current[targetSocketId] = pc;
    return pc;
  };

  // Remove participant helper
  const removeParticipant = (socketId) => {
    if (peers.current[socketId]) {
      peers.current[socketId].close();
      delete peers.current[socketId];
    }
    setParticipants((prev) => prev.filter((p) => p.socketId !== socketId));
  };

  // Join meeting room coordinates
  const joinMeetingRoom = async (roomId, isHost = false) => {
    if (!socket || !user) return;

    // 1. Acquire local tracks
    const stream = await startLocalStream();

    // 2. Transmit join event to signaling server
    socket.emit('join-room', {
      roomId,
      userId: user.id || user._id,
      name: user.name,
      avatar: user.avatar,
      isHost,
    });
  };

  // Leave room coordinates
  const leaveMeetingRoom = () => {
    // 1. Signal server
    if (socket) {
      socket.emit('leave-room');
    }

    // 2. Shut down local tracks
    if (localStreamRef.current) {
      localStreamRef.current.getTracks().forEach((track) => track.stop());
      localStreamRef.current = null;
      setLocalStream(null);
    }
    if (screenStream) {
      screenStream.getTracks().forEach((track) => track.stop());
      setScreenStream(null);
    }

    // 3. Clear active RTCPeerConnections
    Object.keys(peers.current).forEach((socketId) => {
      peers.current[socketId].close();
    });
    peers.current = {};

    // 4. Reset UI variables
    setParticipants([]);
    setIsMuted(false);
    setIsCameraOff(false);
    setIsScreenSharing(false);
    setIsHandRaised(false);
  };

  // Handle incoming signaling messages
  useEffect(() => {
    if (!socket) return;

    // Client receives list of other users inside room upon joining
    socket.on('current-room-users', async (otherUsers) => {
      console.log('Discovered other room users:', otherUsers.length);
      
      const currentStream = localStreamRef.current;
      
      // Initialize participant records (with empty streams initially)
      setParticipants(otherUsers.map(u => ({ ...u, stream: null })));

      // Initiate WebRTC peer connection (createOffer) with each existing user
      for (const u of otherUsers) {
        const pc = createPeerConnection(u.socketId, u, currentStream);
        try {
          const offer = await pc.createOffer();
          await pc.setLocalDescription(offer);
          socket.emit('webrtc-offer', {
            targetSocketId: u.socketId,
            offer,
          });
        } catch (err) {
          console.error(`Error creating offer to ${u.socketId}:`, err);
        }
      }
    });

    // Client receives notice that a new user entered the room
    socket.on('user-joined', (newUser) => {
      console.log('User joined room, setting up peer:', newUser.name);
      
      // Add participant mapping
      setParticipants((prev) => {
        if (prev.some(p => p.socketId === newUser.socketId)) return prev;
        return [...prev, { ...newUser, stream: null }];
      });
      
      // We don't trigger offer creation here. The newly joined client triggers it (as defined in 'current-room-users' loop).
      // We just need to be ready to receive their offer.
    });

    // Handle receiving WebRTC Offer
    socket.on('webrtc-offer', async ({ senderSocketId, offer }) => {
      console.log('Received RTC offer from:', senderSocketId);
      
      // Look up target details in current state
      const targetUser = participants.find(p => p.socketId === senderSocketId) || {};
      
      const currentStream = localStreamRef.current;
      const pc = createPeerConnection(senderSocketId, targetUser, currentStream);

      try {
        await pc.setRemoteDescription(new RTCSessionDescription(offer));
        const answer = await pc.createAnswer();
        await pc.setLocalDescription(answer);
        socket.emit('webrtc-answer', {
          targetSocketId: senderSocketId,
          answer,
        });
      } catch (err) {
        console.error('Error handling WebRTC offer:', err);
      }
    });

    // Handle receiving WebRTC Answer
    socket.on('webrtc-answer', async ({ senderSocketId, answer }) => {
      console.log('Received RTC answer from:', senderSocketId);
      const pc = peers.current[senderSocketId];
      if (pc) {
        try {
          await pc.setRemoteDescription(new RTCSessionDescription(answer));
        } catch (err) {
          console.error('Error setting remote description for answer:', err);
        }
      }
    });

    // Handle receiving ICE Candidate
    socket.on('webrtc-ice-candidate', async ({ senderSocketId, candidate }) => {
      const pc = peers.current[senderSocketId];
      if (pc) {
        try {
          await pc.addIceCandidate(new RTCIceCandidate(candidate));
        } catch (err) {
          console.error('Error adding received ICE candidate:', err);
        }
      }
    });

    // Handle user leaving
    socket.on('user-left', ({ socketId }) => {
      console.log('User disconnected/left room:', socketId);
      removeParticipant(socketId);
    });

    // Sync media changes from peers
    socket.on('peer-toggle-audio', ({ socketId, isActive }) => {
      setParticipants((prev) =>
        prev.map((p) => (p.socketId === socketId ? { ...p, isMicActive: isActive } : p))
      );
    });

    socket.on('peer-toggle-video', ({ socketId, isActive }) => {
      setParticipants((prev) =>
        prev.map((p) => (p.socketId === socketId ? { ...p, isCamActive: isActive } : p))
      );
    });

    socket.on('peer-toggle-screen-share', ({ socketId, isSharing }) => {
      setParticipants((prev) =>
        prev.map((p) => (p.socketId === socketId ? { ...p, isScreenSharing: isSharing } : p))
      );
    });

    socket.on('peer-raise-hand', ({ socketId, isRaised }) => {
      setParticipants((prev) =>
        prev.map((p) => (p.socketId === socketId ? { ...p, isHandRaised: isRaised } : p))
      );
    });

    // Host Force-Mute Command
    socket.on('force-mute', () => {
      console.log('Host has force-muted all participants.');
      toggleMute(true);
    });

    return () => {
      socket.off('current-room-users');
      socket.off('user-joined');
      socket.off('webrtc-offer');
      socket.off('webrtc-answer');
      socket.off('webrtc-ice-candidate');
      socket.off('user-left');
      socket.off('peer-toggle-audio');
      socket.off('peer-toggle-video');
      socket.off('peer-toggle-screen-share');
      socket.off('peer-raise-hand');
      socket.off('force-mute');
    };
  }, [socket, participants]);

  // Audio mute controller
  const toggleMute = (forceState = null) => {
    const stream = localStreamRef.current;
    if (!stream) return;

    const audioTrack = stream.getAudioTracks()[0];
    if (audioTrack) {
      const newState = forceState !== null ? !forceState : !audioTrack.enabled;
      audioTrack.enabled = newState;
      setIsMuted(!newState);

      // Emit status update to room
      if (socket && socket.roomId) {
        socket.emit('toggle-audio', { roomId: socket.roomId, isActive: newState });
      }
    }
  };

  // Camera toggle controller
  const toggleCamera = () => {
    const stream = localStreamRef.current;
    if (!stream) return;

    const videoTrack = stream.getVideoTracks()[0];
    if (videoTrack) {
      const newState = !videoTrack.enabled;
      videoTrack.enabled = newState;
      setIsCameraOff(!newState);

      // Emit status update to room
      if (socket && socket.roomId) {
        socket.emit('toggle-video', { roomId: socket.roomId, isActive: newState });
      }
    }
  };

  // Raise Hand controller
  const toggleRaiseHand = () => {
    if (!socket || !socket.roomId) return;
    const nextState = !isHandRaised;
    setIsHandRaised(nextState);
    socket.emit('raise-hand', { roomId: socket.roomId, isRaised: nextState });
  };

  // Host Control: Mute Everyone
  const hostMuteAll = () => {
    if (!socket || !socket.roomId) return;
    socket.emit('host-mute-all', { roomId: socket.roomId });
  };

  // Host Control: End Meeting
  const hostEndMeeting = () => {
    if (!socket || !socket.roomId) return;
    socket.emit('host-end-meeting', { roomId: socket.roomId });
  };

  // WebRTC Screen Sharing Implementation
  const toggleScreenShare = async () => {
    if (!socket || !socket.roomId) return;

    if (isScreenSharing) {
      // STOP screen share, swap back to local video track
      if (screenStream) {
        screenStream.getTracks().forEach((track) => track.stop());
        setScreenStream(null);
      }

      // Re-enable camera track
      const stream = localStreamRef.current;
      const cameraVideoTrack = stream?.getVideoTracks()[0];

      if (cameraVideoTrack) {
        cameraVideoTrack.enabled = !isCameraOff;
        
        // Swap all senders back to local camera track
        Object.values(peers.current).forEach((peerConnection) => {
          const senders = peerConnection.getSenders();
          const videoSender = senders.find((s) => s.track?.kind === 'video');
          if (videoSender) videoSender.replaceTrack(cameraVideoTrack);
        });
      }

      setIsScreenSharing(false);
      socket.emit('toggle-screen-share', { roomId: socket.roomId, isSharing: false });
    } else {
      // START Screen Share
      try {
        const stream = await navigator.mediaDevices.getDisplayMedia({
          video: { cursor: 'always' },
          audio: true,
        });

        setScreenStream(stream);
        setIsScreenSharing(true);
        socket.emit('toggle-screen-share', { roomId: socket.roomId, isSharing: true });

        const screenVideoTrack = stream.getVideoTracks()[0];

        // Replace local camera tracks in all RTCPeerConnections
        Object.values(peers.current).forEach((peerConnection) => {
          const senders = peerConnection.getSenders();
          const videoSender = senders.find((s) => s.track?.kind === 'video');
          if (videoSender && screenVideoTrack) {
            videoSender.replaceTrack(screenVideoTrack);
          }
        });

        // Detect if user stops screen sharing through browser UI overlay
        screenVideoTrack.onended = () => {
          // Trigger stop workflow manually
          if (screenStream) {
            screenStream.getTracks().forEach((track) => track.stop());
            setScreenStream(null);
          }
          
          const localStreamVal = localStreamRef.current;
          const cameraTrack = localStreamVal?.getVideoTracks()[0];
          if (cameraTrack) {
            cameraTrack.enabled = !isCameraOff;
            Object.values(peers.current).forEach((peerConnection) => {
              const senders = peerConnection.getSenders();
              const videoSender = senders.find((s) => s.track?.kind === 'video');
              if (videoSender) videoSender.replaceTrack(cameraTrack);
            });
          }
          setIsScreenSharing(false);
          socket.emit('toggle-screen-share', { roomId: socket.roomId, isSharing: false });
        };
      } catch (err) {
        console.error('Failed to acquire screen capture stream:', err);
        setIsScreenSharing(false);
      }
    }
  };

  return (
    <WebRTCContext.Provider
      value={{
        localStream,
        screenStream,
        participants,
        isMuted,
        isCameraOff,
        isScreenSharing,
        isHandRaised,
        devices,
        selectedDevices,
        joinMeetingRoom,
        leaveMeetingRoom,
        toggleMute,
        toggleCamera,
        toggleScreenShare,
        toggleRaiseHand,
        changeDevice,
        hostMuteAll,
        hostEndMeeting,
      }}
    >
      {children}
    </WebRTCContext.Provider>
  );
};

export const useWebRTC = () => useContext(WebRTCContext);
export default WebRTCContext;
