import React, { createContext, useContext, useState, useEffect } from 'react';
import api from '../services/api';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  // Fetch profile on initial load if token exists
  useEffect(() => {
    const fetchUser = async () => {
      const token = localStorage.getItem('token');
      if (!token) {
        setLoading(false);
        return;
      }
      try {
        const res = await api.get('/users/profile');
        if (res.data.success) {
          setUser(res.data.user);
        } else {
          localStorage.removeItem('token');
          localStorage.removeItem('mock_user');
        }
      } catch (err) {
        console.error('Failed to load user profile, checking local fallback:', err);
        const savedMock = localStorage.getItem('mock_user');
        if (savedMock) {
          setUser(JSON.parse(savedMock));
        } else {
          localStorage.removeItem('token');
        }
      } finally {
        setLoading(false);
      }
    };
    fetchUser();
  }, []);

  // Login handler
  const login = async (email, password) => {
    setLoading(true);
    try {
      const res = await api.post('/auth/login', { email, password });
      if (res.data.success) {
        localStorage.setItem('token', res.data.token);
        setUser(res.data.user);
        return { success: true };
      }
    } catch (err) {
      if (!err.response) {
        // Local preview fallback
        const mockUser = {
          id: 'mock_' + Date.now(),
          name: email.split('@')[0],
          email: email,
          avatar: '',
          isVerified: true,
        };
        localStorage.setItem('token', 'mock_token_' + Date.now());
        localStorage.setItem('mock_user', JSON.stringify(mockUser));
        setUser(mockUser);
        return { success: true, isMock: true };
      }
      return {
        success: false,
        message: err.response?.data?.message || 'Login failed. Please check credentials.',
      };
    } finally {
      setLoading(false);
    }
  };

  // Register handler
  const register = async (name, email, password) => {
    setLoading(true);
    try {
      const res = await api.post('/auth/register', { name, email, password });
      if (res.data.success) {
        localStorage.setItem('token', res.data.token);
        setUser(res.data.user);
        return { success: true, message: res.data.message };
      }
    } catch (err) {
      if (!err.response) {
        // Local preview fallback
        const mockUser = {
          id: 'mock_' + Date.now(),
          name: name,
          email: email,
          avatar: '',
          isVerified: true,
        };
        localStorage.setItem('token', 'mock_token_' + Date.now());
        localStorage.setItem('mock_user', JSON.stringify(mockUser));
        setUser(mockUser);
        return { success: true, message: 'Welcome to Local Offline Preview Mode!' };
      }
      return {
        success: false,
        message: err.response?.data?.message || 'Registration failed. Try again.',
      };
    } finally {
      setLoading(false);
    }
  };

  // Logout handler
  const logout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('mock_user');
    setUser(null);
  };

  // Google Login handler
  const googleLogin = async (googleUserData) => {
    setLoading(true);
    try {
      const res = await api.post('/auth/google', googleUserData);
      if (res.data.success) {
        localStorage.setItem('token', res.data.token);
        setUser(res.data.user);
        return { success: true };
      }
    } catch (err) {
      if (!err.response) {
        // Local preview fallback
        const mockUser = {
          id: 'mock_' + Date.now(),
          name: googleUserData.name,
          email: googleUserData.email,
          avatar: googleUserData.avatar || '',
          isVerified: true,
        };
        localStorage.setItem('token', 'mock_token_' + Date.now());
        localStorage.setItem('mock_user', JSON.stringify(mockUser));
        setUser(mockUser);
        return { success: true };
      }
      return {
        success: false,
        message: err.response?.data?.message || 'Google Auth failed.',
      };
    } finally {
      setLoading(false);
    }
  };

  // Update profile
  const updateProfile = async (formData) => {
    setLoading(true);
    try {
      // Must use multipart/form-data for uploads
      const res = await api.put('/users/profile', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });
      if (res.data.success) {
        setUser(res.data.user);
        return { success: true, message: res.data.message };
      }
    } catch (err) {
      return {
        success: false,
        message: err.response?.data?.message || 'Failed to update profile.',
      };
    } finally {
      setLoading(false);
    }
  };

  // Forgot password
  const forgotPassword = async (email) => {
    try {
      const res = await api.post('/auth/forgot-password', { email });
      return { success: true, message: res.data.message };
    } catch (err) {
      return {
        success: false,
        message: err.response?.data?.message || 'Failed to request reset link.',
      };
    }
  };

  // Reset password
  const resetPassword = async (token, password) => {
    try {
      const res = await api.post('/auth/reset-password', { token, password });
      return { success: true, message: res.data.message };
    } catch (err) {
      return {
        success: false,
        message: err.response?.data?.message || 'Failed to reset password.',
      };
    }
  };

  // Email Verification
  const verifyEmail = async (token) => {
    try {
      const res = await api.post('/auth/verify-email', { token });
      if (res.data.success) {
        // Optionally update local user verification flag if logged in
        if (user) {
          setUser((prev) => ({ ...prev, isVerified: true }));
        }
        return { success: true, message: res.data.message };
      }
    } catch (err) {
      return {
        success: false,
        message: err.response?.data?.message || 'Failed to verify email.',
      };
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        loading,
        login,
        register,
        logout,
        updateProfile,
        forgotPassword,
        resetPassword,
        verifyEmail,
        googleLogin,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
export default AuthContext;
