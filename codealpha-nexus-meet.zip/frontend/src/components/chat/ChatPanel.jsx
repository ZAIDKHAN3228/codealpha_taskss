import React, { useEffect, useRef, useState } from 'react';
import { useSocket } from '../../contexts/SocketContext';
import { useAuth } from '../../contexts/AuthContext';
import api from '../../services/api';
import { 
  FiSend, 
  FiPaperclip, 
  FiSmile, 
  FiCornerUpLeft, 
  FiTrash2, 
  FiDownload, 
  FiFile, 
  FiImage, 
  FiVideo, 
  FiX,
  FiFolder
} from 'react-icons/fi';

const ChatPanel = ({ roomId }) => {
  const socket = useSocket();
  const { user } = useAuth();
  
  const [activeTab, setActiveTab] = useState('chat'); // chat, files
  const [messages, setMessages] = useState([]);
  const [sharedFiles, setSharedFiles] = useState([]);
  const [inputValue, setInputValue] = useState('');
  
  // Typing state
  const [isTyping, setIsTyping] = useState(false);
  const [activeTypers, setActiveTypers] = useState([]); // Array of peer names typing: ['Alice', 'Bob']
  
  // File uploads
  const [uploadProgress, setUploadProgress] = useState(null);
  const [dragging, setDragging] = useState(false);

  // Reply state
  const [replyMessage, setReplyMessage] = useState(null);

  // Emoji picker visibility
  const [showEmojis, setShowEmojis] = useState(false);

  const messagesEndRef = useRef(null);
  const fileInputRef = useRef(null);
  const typingTimeoutRef = useRef(null);

  const emojis = ['👍', '❤️', '👏', '😂', '😮', '😢', '🙏', '🔥', '🎉', '💯'];

  // Scroll to bottom helper
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  // Fetch initial messages and files on mount
  useEffect(() => {
    const fetchHistory = async () => {
      try {
        // Fetch files list
        const filesRes = await api.get(`/files/meeting/${roomId}`);
        if (filesRes.data.success) {
          setSharedFiles(filesRes.data.files);
        }

        // Fetch messages list
        // Fetch from API or falls back to empty if we haven't created the message API yet
        // Let's create a fallback to prevent app crashing
        try {
          const msgRes = await api.get(`/meetings/${roomId}/messages`);
          if (msgRes.data.success) {
            setMessages(msgRes.data.messages);
          }
        } catch (err) {
          console.warn('Meeting messages endpoint not initialized yet, starting empty chat stream');
        }
      } catch (err) {
        console.error('Error fetching chat history:', err);
      }
    };
    fetchHistory();
  }, [roomId]);

  // Sync scroll
  useEffect(() => {
    scrollToBottom();
  }, [messages, activeTypers]);

  // Listen to real-time socket events
  useEffect(() => {
    if (!socket) return;

    // Incoming messages
    socket.on('new-chat-message', (newMsg) => {
      setMessages((prev) => {
        // Avoid duplicate messages
        if (prev.some(m => m._id === newMsg._id)) return prev;
        return [...prev, newMsg];
      });

      // If it contains a file, add it to files tab list too
      if (newMsg.file) {
        setSharedFiles((prev) => [newMsg.file, ...prev]);
      }
    });

    // Delete message
    socket.on('chat-message-deleted', ({ messageId }) => {
      setMessages((prev) =>
        prev.map((msg) => (msg._id === messageId ? { ...msg, isDeleted: true } : msg))
      );
    });

    // Peer typing indicators
    socket.on('peer-typing-state', ({ socketId, name, isTyping: peerIsTyping }) => {
      setActiveTypers((prev) => {
        if (peerIsTyping) {
          if (prev.includes(name)) return prev;
          return [...prev, name];
        } else {
          return prev.filter((n) => n !== name);
        }
      });
    });

    return () => {
      socket.off('new-chat-message');
      socket.off('chat-message-deleted');
      socket.off('peer-typing-state');
    };
  }, [socket]);

  // Emit typing state to peers
  const handleTyping = () => {
    if (!socket) return;

    if (!isTyping) {
      setIsTyping(true);
      socket.emit('typing-state', { roomId, name: user.name, isTyping: true });
    }

    // Reset typing timeout
    if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);
    
    typingTimeoutRef.current = setTimeout(() => {
      setIsTyping(false);
      socket.emit('typing-state', { roomId, name: user.name, isTyping: false });
    }, 2000);
  };

  const handleSendMessage = (e) => {
    e.preventDefault();
    if (!inputValue.trim() || !socket) return;

    socket.emit('send-chat-message', {
      roomId,
      senderId: user.id || user._id,
      message: inputValue,
      replyToId: replyMessage ? replyMessage._id : null,
    });

    setInputValue('');
    setReplyMessage(null);
    setShowEmojis(false);
    
    // Stop typing immediately
    if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);
    setIsTyping(false);
    socket.emit('typing-state', { roomId, name: user.name, isTyping: false });
  };

  const handleDeleteMessage = (messageId) => {
    if (socket) {
      socket.emit('delete-chat-message', { roomId, messageId });
    }
  };

  // File Upload Handling
  const handleFileUpload = async (file) => {
    if (!file) return;

    // Check size limit: 50MB
    if (file.size > 50 * 1024 * 1024) {
      alert('File size exceeds the 50MB limit.');
      return;
    }

    const formData = new FormData();
    formData.append('file', file);
    formData.append('meetingId', roomId);

    setUploadProgress(0);

    try {
      const res = await api.post('/files/upload', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
        onUploadProgress: (progressEvent) => {
          const progress = Math.round(
            (progressEvent.loaded * 100) / progressEvent.total
          );
          setUploadProgress(progress);
        },
      });

      if (res.data.success) {
        // Emit file shared message via socket
        if (socket) {
          socket.emit('send-chat-message', {
            roomId,
            senderId: user.id || user._id,
            message: `Shared a file: ${file.name}`,
            fileId: res.data.file._id,
          });
        }
      }
    } catch (err) {
      console.error('File upload failed:', err);
      alert('Failed to upload file. Try again.');
    } finally {
      setUploadProgress(null);
    }
  };

  const handleDragOver = (e) => {
    e.preventDefault();
    setDragging(true);
  };

  const handleDragLeave = () => {
    setDragging(false);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    setDragging(false);
    const file = e.dataTransfer.files[0];
    handleFileUpload(file);
  };

  // Helper file previews
  const renderFileIcon = (mimeType) => {
    if (mimeType?.startsWith('image/')) return <FiImage className="h-5 w-5 text-blue-400" />;
    if (mimeType?.startsWith('video/')) return <FiVideo className="h-5 w-5 text-indigo-400" />;
    return <FiFile className="h-5 w-5 text-slate-400" />;
  };

  const formatFileSize = (bytes) => {
    if (!bytes) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
  };

  return (
    <div 
      className={`h-full flex flex-col bg-slate-900 border-l border-slate-800 text-slate-100 transition-all duration-300 relative ${dragging ? 'ring-2 ring-brand-500 ring-inset bg-slate-900/90' : ''}`}
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
    >
      
      {/* Tab Selectors */}
      <div className="flex bg-slate-950/40 border-b border-slate-800 px-4 py-2.5">
        <button
          onClick={() => setActiveTab('chat')}
          className={`flex-grow py-1.5 text-xs font-bold rounded-lg transition-all ${activeTab === 'chat' ? 'bg-slate-800 text-white border border-slate-700' : 'text-slate-400 hover:text-slate-200'}`}
        >
          Meeting Chat
        </button>
        <button
          onClick={() => setActiveTab('files')}
          className={`flex-grow py-1.5 text-xs font-bold rounded-lg transition-all ${activeTab === 'files' ? 'bg-slate-800 text-white border border-slate-700' : 'text-slate-400 hover:text-slate-200'}`}
        >
          Shared Files ({sharedFiles.length})
        </button>
      </div>

      {activeTab === 'chat' ? (
        <>
          {/* Chat Stream */}
          <div className="flex-grow overflow-y-auto px-4 py-4 space-y-4 custom-scrollbar">
            {messages.length === 0 ? (
              <div className="text-center py-20 text-slate-500 text-xs">
                <span>Start conversation. Messages are encrypted.</span>
              </div>
            ) : (
              messages.map((msg) => (
                <div key={msg._id} className={`flex flex-col ${msg.sender?._id === (user.id || user._id) ? 'items-end' : 'items-start'}`}>
                  
                  {/* Sender details */}
                  <span className="text-[10px] text-slate-500 font-semibold mb-1 px-1">{msg.sender?.name}</span>

                  {/* Message Bubble */}
                  <div className={`max-w-[85%] rounded-2xl px-4 py-2.5 text-sm relative group border ${msg.sender?._id === (user.id || user._id) ? 'bg-brand-500/10 border-brand-500/25 text-slate-100 rounded-tr-none' : 'bg-slate-800/60 border-slate-700/40 text-slate-200 rounded-tl-none'}`}>
                    
                    {/* Reply quote preview inside bubble */}
                    {msg.replyTo && (
                      <div className="mb-2 p-2 bg-black/20 rounded border-l-2 border-brand-500 text-[11px] text-slate-400 flex flex-col">
                        <span className="font-bold text-[10px] text-slate-300">Reply to {msg.replyTo.sender?.name}</span>
                        <span className="truncate">{msg.replyTo.message}</span>
                      </div>
                    )}

                    {/* Deleted message indicator */}
                    {msg.isDeleted ? (
                      <span className="italic text-slate-500 text-xs">This message was deleted.</span>
                    ) : (
                      <>
                        <p className="break-words leading-relaxed">{msg.message}</p>
                        
                        {/* Render File attachment inside bubble */}
                        {msg.file && (
                          <div className="mt-2.5 p-2 rounded bg-slate-950/40 border border-slate-800 flex items-center justify-between gap-3 max-w-[240px]">
                            <div className="flex items-center space-x-2 min-w-0">
                              {renderFileIcon(msg.file.mimeType)}
                              <div className="min-w-0">
                                <p className="text-xs font-semibold truncate text-slate-300">{msg.file.fileName}</p>
                                <p className="text-[9px] text-slate-500">{formatFileSize(msg.file.size)}</p>
                              </div>
                            </div>
                            <a 
                              href={msg.file.url} 
                              download={msg.file.fileName}
                              target="_blank" 
                              rel="noreferrer"
                              className="p-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300"
                            >
                              <FiDownload className="h-3.5 w-3.5" />
                            </a>
                          </div>
                        )}
                      </>
                    )}

                    {/* Action overlays (Reply / Delete) */}
                    {!msg.isDeleted && (
                      <div className="absolute top-1/2 -translate-y-1/2 hidden group-hover:flex items-center space-x-1.5 px-2 bg-slate-900 border border-slate-800 rounded-lg shadow-lg z-10" style={{ [msg.sender?._id === (user.id || user._id) ? 'left' : 'right']: '-60px' }}>
                        <button
                          onClick={() => setReplyMessage(msg)}
                          title="Reply"
                          className="p-1 text-slate-400 hover:text-white"
                        >
                          <FiCornerUpLeft className="h-3.5 w-3.5" />
                        </button>
                        {msg.sender?._id === (user.id || user._id) && (
                          <button
                            onClick={() => handleDeleteMessage(msg._id)}
                            title="Delete"
                            className="p-1 text-red-400 hover:text-red-300"
                          >
                            <FiTrash2 className="h-3.5 w-3.5" />
                          </button>
                        )}
                      </div>
                    )}
                  </div>
                  
                  {/* Timestamp */}
                  <span className="text-[8px] text-slate-600 px-1.5 mt-0.5">{new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                </div>
              ))
            )}

            {/* Remote users typing status */}
            {activeTypers.length > 0 && (
              <div className="text-[10px] text-slate-500 italic px-2 py-1 animate-pulse flex items-center space-x-1">
                <span>{activeTypers.join(', ')} {activeTypers.length === 1 ? 'is' : 'are'} typing...</span>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Upload Progress Bar */}
          {uploadProgress !== null && (
            <div className="px-4 py-2 bg-slate-950/60 border-t border-slate-800">
              <div className="flex justify-between text-xs text-slate-400 mb-1 font-semibold">
                <span>Uploading file...</span>
                <span>{uploadProgress}%</span>
              </div>
              <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                <div 
                  className="bg-brand-500 h-full transition-all duration-150" 
                  style={{ width: `${uploadProgress}%` }}
                />
              </div>
            </div>
          )}

          {/* Reply quotes bar above input */}
          {replyMessage && (
            <div className="px-4 py-2 bg-slate-950/80 border-t border-slate-800 flex justify-between items-center text-xs">
              <div className="flex flex-col text-slate-400 truncate max-w-[85%]">
                <span className="font-bold text-[10px] text-brand-400">Replying to {replyMessage.sender?.name}</span>
                <span className="truncate">{replyMessage.message}</span>
              </div>
              <button 
                onClick={() => setReplyMessage(null)}
                className="p-1 text-slate-400 hover:text-white"
              >
                <FiX className="h-4 w-4" />
              </button>
            </div>
          )}

          {/* Emoji Picker Tray */}
          {showEmojis && (
            <div className="p-2.5 bg-slate-950 border-t border-slate-850 flex items-center justify-around flex-wrap gap-1">
              {emojis.map((emoji) => (
                <button
                  key={emoji}
                  onClick={() => {
                    setInputValue((prev) => prev + emoji);
                    handleTyping();
                  }}
                  className="text-lg hover:scale-125 transition-transform"
                >
                  {emoji}
                </button>
              ))}
            </div>
          )}

          {/* Message Input Controls */}
          <form onSubmit={handleSendMessage} className="p-4 bg-slate-950/40 border-t border-slate-800 flex items-center space-x-2 relative z-10">
            <button
              type="button"
              onClick={() => fileInputRef.current.click()}
              className="p-2.5 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-white transition-all"
              title="Attach File"
            >
              <FiPaperclip className="h-4.5 w-4.5" />
            </button>
            <input
              type="file"
              ref={fileInputRef}
              onChange={(e) => handleFileUpload(e.target.files[0])}
              className="hidden"
            />

            <button
              type="button"
              onClick={() => setShowEmojis(!showEmojis)}
              className={`p-2.5 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-white transition-all ${showEmojis ? 'bg-slate-700 text-brand-400' : ''}`}
              title="Add Emoji"
            >
              <FiSmile className="h-4.5 w-4.5" />
            </button>

            <input
              type="text"
              value={inputValue}
              onChange={(e) => {
                setInputValue(e.target.value);
                handleTyping();
              }}
              className="flex-grow px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-800 focus:border-brand-500 focus:outline-none text-slate-200 placeholder-slate-600 text-sm"
              placeholder="Type message here..."
              required
            />

            <button
              type="submit"
              className="p-2.5 rounded-xl gradient-bg hover:shadow-lg text-white hover:shadow-brand-500/10 transition-all"
            >
              <FiSend className="h-4.5 w-4.5" />
            </button>
          </form>
        </>
      ) : (
        /* Shared Files Lists view */
        <div className="flex-grow overflow-y-auto p-4 space-y-3 custom-scrollbar">
          {sharedFiles.length === 0 ? (
            <div className="text-center py-20 text-slate-500 text-xs">
              <FiFolder className="h-10 w-10 text-slate-700 mx-auto mb-3" />
              <span>No files have been shared yet in this call. Drag and drop file here to upload.</span>
            </div>
          ) : (
            sharedFiles.map((file) => (
              <div 
                key={file._id}
                className="p-3 rounded-xl bg-slate-800/40 border border-slate-750 flex items-center justify-between gap-3 hover:bg-slate-800/60 transition-all"
              >
                <div className="flex items-center space-x-2.5 min-w-0">
                  <div className="p-2 bg-slate-900 rounded-lg">
                    {renderFileIcon(file.mimeType)}
                  </div>
                  <div className="min-w-0">
                    <p className="text-xs font-semibold text-slate-200 truncate" title={file.fileName}>{file.fileName}</p>
                    <p className="text-[9px] text-slate-500">Shared by {file.uploadedBy?.name || 'User'}</p>
                  </div>
                </div>
                
                <a 
                  href={file.url}
                  download={file.fileName}
                  target="_blank"
                  rel="noreferrer"
                  className="p-2 rounded-lg bg-slate-900 hover:bg-slate-850 text-slate-400 hover:text-white transition-all flex-shrink-0"
                >
                  <FiDownload className="h-4 w-4" />
                </a>
              </div>
            ))
          )}
        </div>
      )}

    </div>
  );
};

export default ChatPanel;
export { ChatPanel };
