import React, { useState } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import { FiX, FiCheck, FiMail, FiUser } from 'react-icons/fi';
import { motion, AnimatePresence } from 'framer-motion';

const GoogleSignInButton = ({ code }) => {
  const { googleLogin } = useAuth();
  const navigate = useNavigate();
  const [showConsent, setShowConsent] = useState(false);
  const [customEmail, setCustomEmail] = useState('');
  const [customName, setCustomName] = useState('');
  const [selectedMock, setSelectedMock] = useState(null);
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const mockAccounts = [
    { name: 'Alex Mercer', email: 'alex.mercer@gmail.com', avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=80&h=80&q=80' },
    { name: 'Sarah Connor', email: 'sarah.connor@gmail.com', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=80&h=80&q=80' },
  ];

  const handleGoogleAuth = async (name, email, avatar) => {
    if (!email || !name) {
      setError('Please provide your name and email to mock Google Sign-in.');
      return;
    }
    setError('');
    setSubmitting(true);

    const result = await googleLogin({
      name,
      email,
      avatar,
      googleId: 'mock_' + Date.now(),
    });

    setSubmitting(false);

    if (result.success) {
      setShowConsent(false);
      if (code) {
        navigate(`/meeting/${code}`);
      } else {
        navigate('/dashboard');
      }
    } else {
      setError(result.message);
    }
  };

  const handleCustomSubmit = (e) => {
    e.preventDefault();
    const initialsAvatar = `https://ui-avatars.com/api/?name=${encodeURIComponent(customName)}&background=4285f4&color=ffffff&size=128&bold=true`;
    handleGoogleAuth(customName, customEmail, initialsAvatar);
  };

  return (
    <>
      {/* Official styled Google sign in button */}
      <button
        type="button"
        onClick={() => setShowConsent(true)}
        className="w-full py-3 px-4 rounded-xl bg-white border border-slate-300 hover:bg-slate-50 text-slate-700 font-semibold flex justify-center items-center space-x-3 transition-all text-sm hover:shadow"
      >
        <svg className="h-5 w-5" viewBox="0 0 24 24">
          <path
            fill="#ea4335"
            d="M5.266 9.765A7.077 7.077 0 0 1 12 4.909c1.69 0 3.218.6 4.418 1.582L19.91 3C17.782 1.145 15.055 0 12 0 7.359 0 3.39 2.673 1.482 6.582l3.784 3.183z"
          />
          <path
            fill="#4285f4"
            d="M23.455 12.273c0-.818-.082-1.609-.227-2.373H12v4.509h6.427a5.51 5.51 0 0 1-2.39 3.618l3.736 2.9A11.758 11.758 0 0 0 24 12c0-.127-.009-.255-.018-.382z"
          />
          <path
            fill="#fbbc05"
            d="M5.266 14.235 1.482 17.42A11.968 11.968 0 0 0 12 24c3.055 0 5.782-1.027 7.782-2.8l-3.736-2.9A7.062 7.062 0 0 1 12 19.09a7.077 7.077 0 0 1-6.734-4.855z"
          />
          <path
            fill="#34a853"
            d="M12 4.909c1.69 0 3.218.6 4.418 1.582L19.91 3C17.782 1.145 15.055 0 12 0v12h11.455c-.018-.127-.027-.255-.045-.382L12 4.909z"
          />
        </svg>
        <span>Continue with Google</span>
      </button>

      {/* Dynamic Google Consent popup simulation */}
      <AnimatePresence>
        {showConsent && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
            
            {/* Click outside to cancel */}
            <div className="absolute inset-0" onClick={() => setShowConsent(false)} />

            {/* Simulated Google popup window */}
            <motion.div
              className="w-full max-w-md bg-white text-slate-800 rounded-xl shadow-2xl overflow-hidden relative z-10 border border-slate-200"
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
            >
              {/* Fake Google Chrome Header */}
              <div className="bg-slate-100 px-4 py-3 flex justify-between items-center border-b border-slate-200">
                <div className="flex items-center space-x-2">
                  <svg className="h-4 w-4" viewBox="0 0 24 24">
                    <path
                      fill="#4285f4"
                      d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm0 18c-3.314 0-6-2.686-6-6s2.686-6 6-6 6 2.686 6 6-2.686 6-6 6z"
                    />
                  </svg>
                  <span className="text-xs font-semibold text-slate-600">Sign in with Google</span>
                </div>
                <button 
                  onClick={() => setShowConsent(false)}
                  className="p-1 rounded-lg hover:bg-slate-200 text-slate-400 hover:text-slate-600 transition-all"
                >
                  <FiX className="h-4 w-4" />
                </button>
              </div>

              {/* Consent Screen body */}
              <div className="p-6 space-y-6">
                
                {/* Brand name */}
                <div className="text-center">
                  <h3 className="text-xl font-bold text-slate-900 font-sans">Sign in to NexusMeet</h3>
                  <p className="text-xs text-slate-500 mt-1">To continue, Google will share your profile and email.</p>
                </div>

                {error && (
                  <div className="p-3 bg-red-50 text-red-600 rounded-lg text-xs font-medium">
                    {error}
                  </div>
                )}

                {/* Scope Consent indicators */}
                <div className="p-4 rounded-xl bg-slate-50 border border-slate-150 space-y-2">
                  <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Permissions Requested</p>
                  <div className="flex items-center space-x-2 text-xs font-semibold text-slate-700">
                    <FiCheck className="h-4 w-4 text-emerald-500" />
                    <span>Basic Profile info (Display Name, Avatar)</span>
                  </div>
                  <div className="flex items-center space-x-2 text-xs font-semibold text-slate-700">
                    <FiCheck className="h-4 w-4 text-emerald-500" />
                    <span>Email Address access (verify identity)</span>
                  </div>
                </div>

                {/* Account Selection Lists */}
                <div className="space-y-2">
                  <p className="text-xs font-bold text-slate-500 px-1">Select an account</p>
                  
                  {mockAccounts.map((acc, index) => (
                    <button
                      key={index}
                      onClick={() => handleGoogleAuth(acc.name, acc.email, acc.avatar)}
                      disabled={submitting}
                      className="w-full flex items-center justify-between p-3 rounded-xl hover:bg-slate-50 border border-transparent hover:border-slate-200 transition-all text-left"
                    >
                      <div className="flex items-center space-x-3">
                        <img src={acc.avatar} alt="avatar" className="w-10 h-10 rounded-full bg-slate-200 object-cover" />
                        <div>
                          <p className="text-sm font-bold text-slate-800 leading-tight">{acc.name}</p>
                          <p className="text-xs text-slate-500">{acc.email}</p>
                        </div>
                      </div>
                      <span className="text-[10px] font-bold text-brand-500 bg-brand-50 px-2.5 py-0.5 rounded-full">Google Account</span>
                    </button>
                  ))}
                </div>

                {/* Custom Account Fallback Option */}
                <div className="border-t border-slate-150 pt-5">
                  <p className="text-xs font-bold text-slate-500 mb-3 px-1">Or input different Google credentials</p>
                  <form onSubmit={handleCustomSubmit} className="space-y-3">
                    <div className="relative">
                      <FiUser className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 h-4 w-4" />
                      <input
                        type="text"
                        value={customName}
                        onChange={(e) => setCustomName(e.target.value)}
                        placeholder="Google Display Name"
                        className="w-full pl-9 pr-4 py-2 rounded-lg border border-slate-300 focus:border-brand-500 focus:outline-none text-xs text-slate-800"
                        required
                      />
                    </div>
                    <div className="relative">
                      <FiMail className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 h-4 w-4" />
                      <input
                        type="email"
                        value={customEmail}
                        onChange={(e) => setCustomEmail(e.target.value)}
                        placeholder="Google Email address"
                        className="w-full pl-9 pr-4 py-2 rounded-lg border border-slate-300 focus:border-brand-500 focus:outline-none text-xs text-slate-800"
                        required
                      />
                    </div>
                    <button
                      type="submit"
                      disabled={submitting}
                      className="w-full py-2 bg-[#4285f4] hover:bg-[#357ae8] text-white text-xs font-bold rounded-lg transition-all"
                    >
                      {submitting ? 'Authenticating...' : 'Authorize and Sign In'}
                    </button>
                  </form>
                </div>

              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  );
};

export default GoogleSignInButton;
export { GoogleSignInButton };
