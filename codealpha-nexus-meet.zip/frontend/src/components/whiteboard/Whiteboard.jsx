import React, { useRef, useState, useEffect } from 'react';
import { useSocket } from '../../contexts/SocketContext';
import { 
  FiEdit2, 
  FiMinus, 
  FiSquare, 
  FiCircle, 
  FiRotateCcw, 
  FiRotateCw, 
  FiTrash2, 
  FiDownload,
  FiSlash
} from 'react-icons/fi';

const Whiteboard = ({ roomId }) => {
  const socket = useSocket();
  const canvasRef = useRef(null);
  const contextRef = useRef(null);
  
  const [isDrawing, setIsDrawing] = useState(false);
  const [tool, setTool] = useState('pencil'); // pencil, line, rect, circle, eraser
  const [color, setColor] = useState('#2546ff'); // stroke color
  const [brushSize, setBrushSize] = useState(3);
  
  // Starting point for shape drawings
  const [startPos, setStartPos] = useState({ x: 0, y: 0 });
  const [canvasSnapshot, setCanvasSnapshot] = useState(null); // to restore drawing state when dragging shapes
  
  // Undo/Redo stacks
  const [historyStack, setHistoryStack] = useState([]);
  const [redoStack, setRedoStack] = useState([]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    // Set canvas dimensions to fit container
    const rect = canvas.parentElement.getBoundingClientRect();
    canvas.width = rect.width * 2; // double size for HD screens
    canvas.height = rect.height * 2;
    canvas.style.width = `${rect.width}px`;
    canvas.style.height = `${rect.height}px`;

    const context = canvas.getContext('2d');
    context.scale(2, 2);
    context.lineCap = 'round';
    context.lineJoin = 'round';
    contextRef.current = context;

    // Draw background color (white to allow exporting properly)
    context.fillStyle = '#ffffff';
    context.fillRect(0, 0, canvas.width, canvas.height);
  }, []);

  // Listen to remote drawing instructions
  useEffect(() => {
    if (!socket) return;

    const handleRemoteDraw = (drawData) => {
      const canvas = canvasRef.current;
      const context = contextRef.current;
      if (!canvas || !context) return;

      const { 
        type, 
        startX, startY, 
        endX, endY, 
        strokeColor, strokeWidth, 
        isCleanRequest 
      } = drawData;

      if (isCleanRequest) {
        context.fillStyle = '#ffffff';
        context.fillRect(0, 0, canvas.width, canvas.height);
        return;
      }

      // Configure temporary stroke properties
      const prevColor = context.strokeStyle;
      const prevWidth = context.lineWidth;
      const prevComposite = context.globalCompositeOperation;

      context.strokeStyle = strokeColor;
      context.lineWidth = strokeWidth;

      if (type === 'eraser') {
        context.strokeStyle = '#ffffff'; // draw white over everything
      }

      if (type === 'pencil' || type === 'eraser') {
        context.beginPath();
        context.moveTo(startX, startY);
        context.lineTo(endX, endY);
        context.stroke();
      } else if (type === 'line') {
        context.beginPath();
        context.moveTo(startX, startY);
        context.lineTo(endX, endY);
        context.stroke();
      } else if (type === 'rect') {
        context.strokeRect(startX, startY, endX - startX, endY - startY);
      } else if (type === 'circle') {
        const radius = Math.sqrt(Math.pow(endX - startX, 2) + Math.pow(endY - startY, 2));
        context.beginPath();
        context.arc(startX, startY, radius, 0, 2 * Math.PI);
        context.stroke();
      }

      // Restore stroke configs
      context.strokeStyle = prevColor;
      context.lineWidth = prevWidth;
      context.globalCompositeOperation = prevComposite;
    };

    const handleRemoteClear = () => {
      const canvas = canvasRef.current;
      const context = contextRef.current;
      if (canvas && context) {
        context.fillStyle = '#ffffff';
        context.fillRect(0, 0, canvas.width, canvas.height);
      }
    };

    const handleHistorySync = (history) => {
      // Re-draw past operations
      history.forEach((data) => handleRemoteDraw(data));
    };

    socket.on('whiteboard-draw', handleRemoteDraw);
    socket.on('whiteboard-clear', handleRemoteClear);
    socket.on('whiteboard-history', handleHistorySync);

    return () => {
      socket.off('whiteboard-draw', handleRemoteDraw);
      socket.off('whiteboard-clear', handleRemoteClear);
      socket.off('whiteboard-history', handleHistorySync);
    };
  }, [socket]);

  const saveState = () => {
    const canvas = canvasRef.current;
    if (canvas) {
      const state = canvas.toDataURL();
      setHistoryStack((prev) => [...prev, state]);
      setRedoStack([]); // clear redo stack on new operation
    }
  };

  const getCoordinates = (e) => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();
    
    // Support mouse and touch events
    const clientX = e.touches ? e.touches[0].clientX : e.clientX;
    const clientY = e.touches ? e.touches[0].clientY : e.clientY;

    return {
      x: clientX - rect.left,
      y: clientY - rect.top,
    };
  };

  const handleStartDraw = (e) => {
    e.preventDefault();
    saveState();
    
    const { x, y } = getCoordinates(e);
    setStartPos({ x, y });
    setIsDrawing(true);

    const context = contextRef.current;
    if (context) {
      context.beginPath();
      context.moveTo(x, y);
    }

    // Save snapshot of canvas before dragging shapes
    if (tool !== 'pencil' && tool !== 'eraser') {
      const canvas = canvasRef.current;
      if (canvas) {
        setCanvasSnapshot(canvas.toDataURL());
      }
    }
  };

  const handleDraw = (e) => {
    if (!isDrawing) return;
    e.preventDefault();

    const canvas = canvasRef.current;
    const context = contextRef.current;
    const { x, y } = getCoordinates(e);

    context.lineWidth = brushSize;
    context.strokeStyle = color;

    if (tool === 'pencil') {
      context.lineTo(x, y);
      context.stroke();

      // Emit coordinates instantly
      if (socket) {
        socket.emit('whiteboard-draw', {
          roomId,
          drawData: {
            type: 'pencil',
            startX: startPos.x,
            startY: startPos.y,
            endX: x,
            endY: y,
            strokeColor: color,
            strokeWidth: brushSize,
          },
        });
      }
      setStartPos({ x, y }); // updates to drag coordinate
    } else if (tool === 'eraser') {
      context.strokeStyle = '#ffffff';
      context.lineTo(x, y);
      context.stroke();

      if (socket) {
        socket.emit('whiteboard-draw', {
          roomId,
          drawData: {
            type: 'eraser',
            startX: startPos.x,
            startY: startPos.y,
            endX: x,
            endY: y,
            strokeColor: '#ffffff',
            strokeWidth: brushSize,
          },
        });
      }
      setStartPos({ x, y });
    } else if (canvasSnapshot) {
      // Shape Dragging preview (Restores pre-drawing state first)
      const img = new Image();
      img.src = canvasSnapshot;
      img.onload = () => {
        // Clear and draw snapshot
        context.clearRect(0, 0, canvas.width, canvas.height);
        
        // Disable temporary scaling during drawImage to prevent doubling size
        context.save();
        context.setTransform(1, 0, 0, 1, 0, 0);
        context.drawImage(img, 0, 0);
        context.restore();

        // Draw the shape preview
        context.beginPath();
        if (tool === 'line') {
          context.moveTo(startPos.x, startPos.y);
          context.lineTo(x, y);
          context.stroke();
        } else if (tool === 'rect') {
          context.strokeRect(startPos.x, startPos.y, x - startPos.x, y - startPos.y);
        } else if (tool === 'circle') {
          const radius = Math.sqrt(Math.pow(x - startPos.x, 2) + Math.pow(y - startPos.y, 2));
          context.arc(startPos.x, startPos.y, radius, 0, 2 * Math.PI);
          context.stroke();
        }
      };
    }
  };

  const handleStopDraw = (e) => {
    if (!isDrawing) return;
    setIsDrawing(false);

    const { x, y } = getCoordinates(e);

    // Emit final shape coordinates
    if (socket && tool !== 'pencil' && tool !== 'eraser') {
      socket.emit('whiteboard-draw', {
        roomId,
        drawData: {
          type: tool,
          startX: startPos.x,
          startY: startPos.y,
          endX: x,
          endY: y,
          strokeColor: color,
          strokeWidth: brushSize,
        },
      });
    }

    setCanvasSnapshot(null);
  };

  // Undo draw
  const handleUndo = () => {
    if (historyStack.length === 0) return;
    
    const canvas = canvasRef.current;
    const context = contextRef.current;
    
    // Save current state to redo stack
    setRedoStack((prev) => [...prev, canvas.toDataURL()]);

    const previousState = historyStack[historyStack.length - 1];
    setHistoryStack((prev) => prev.slice(0, -1));

    const img = new Image();
    img.src = previousState;
    img.onload = () => {
      context.clearRect(0, 0, canvas.width, canvas.height);
      context.save();
      context.setTransform(1, 0, 0, 1, 0, 0);
      context.drawImage(img, 0, 0);
      context.restore();
    };
  };

  // Redo draw
  const handleRedo = () => {
    if (redoStack.length === 0) return;

    const canvas = canvasRef.current;
    const context = contextRef.current;

    // Save current state to history stack
    setHistoryStack((prev) => [...prev, canvas.toDataURL()]);

    const nextState = redoStack[redoStack.length - 1];
    setRedoStack((prev) => prev.slice(0, -1));

    const img = new Image();
    img.src = nextState;
    img.onload = () => {
      context.clearRect(0, 0, canvas.width, canvas.height);
      context.save();
      context.setTransform(1, 0, 0, 1, 0, 0);
      context.drawImage(img, 0, 0);
      context.restore();
    };
  };

  // Clear Whiteboard
  const handleClear = () => {
    const canvas = canvasRef.current;
    const context = contextRef.current;
    if (!canvas || !context) return;

    saveState();

    context.fillStyle = '#ffffff';
    context.fillRect(0, 0, canvas.width, canvas.height);

    if (socket) {
      socket.emit('whiteboard-clear', { roomId });
    }
  };

  // Export Drawing as PNG
  const handleExportPNG = () => {
    const canvas = canvasRef.current;
    if (canvas) {
      const link = document.createElement('a');
      link.download = `nexusmeet-whiteboard-${roomId}.png`;
      link.href = canvas.toDataURL('image/png');
      link.click();
    }
  };

  // Export Drawing as PDF
  const handleExportPDF = () => {
    const canvas = canvasRef.current;
    if (canvas) {
      const dataUrl = canvas.toDataURL('image/png');
      
      // Open clean printable HTML page in new window to compile layout print PDF
      const printWindow = window.open('', '_blank');
      printWindow.document.write(`
        <html>
          <head>
            <title>NexusMeet Whiteboard PDF Export</title>
            <style>
              body { margin: 0; display: flex; justify-content: center; align-items: center; height: 100vh; background-color: #f3f4f6; }
              img { max-width: 100%; max-height: 100%; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1); border-radius: 8px; }
              @media print {
                body { background-color: #ffffff; }
                img { box-shadow: none; border-radius: 0; }
                .no-print { display: none; }
              }
            </style>
          </head>
          <body>
            <img src="${dataUrl}" />
            <script>
              window.onload = function() {
                window.print();
                setTimeout(function() { window.close(); }, 500);
              };
            </script>
          </body>
        </html>
      `);
      printWindow.document.close();
    };
  };

  return (
    <div className="h-full w-full flex flex-col bg-white rounded-2xl overflow-hidden shadow-2xl relative select-none">
      
      {/* Toolbar Options */}
      <div className="flex flex-wrap items-center justify-between px-4 py-3 bg-slate-100 border-b border-slate-200 gap-3">
        
        {/* Draw Tools */}
        <div className="flex items-center space-x-1 bg-slate-200/60 p-1 rounded-xl">
          <button
            onClick={() => setTool('pencil')}
            className={`p-2 rounded-lg text-slate-700 hover:bg-slate-200 transition-all ${tool === 'pencil' ? 'whiteboard-btn-active' : ''}`}
            title="Pencil / Free Draw"
          >
            <FiEdit2 className="h-4.5 w-4.5" />
          </button>
          
          <button
            onClick={() => setTool('line')}
            className={`p-2 rounded-lg text-slate-700 hover:bg-slate-200 transition-all ${tool === 'line' ? 'whiteboard-btn-active' : ''}`}
            title="Draw Line"
          >
            <FiMinus className="h-4.5 w-4.5" />
          </button>

          <button
            onClick={() => setTool('rect')}
            className={`p-2 rounded-lg text-slate-700 hover:bg-slate-200 transition-all ${tool === 'rect' ? 'whiteboard-btn-active' : ''}`}
            title="Draw Rectangle"
          >
            <FiSquare className="h-4.5 w-4.5" />
          </button>

          <button
            onClick={() => setTool('circle')}
            className={`p-2 rounded-lg text-slate-700 hover:bg-slate-200 transition-all ${tool === 'circle' ? 'whiteboard-btn-active' : ''}`}
            title="Draw Circle"
          >
            <FiCircle className="h-4.5 w-4.5" />
          </button>

          <button
            onClick={() => setTool('eraser')}
            className={`p-2 rounded-lg text-slate-700 hover:bg-slate-200 transition-all ${tool === 'eraser' ? 'whiteboard-btn-active' : ''}`}
            title="Eraser tool"
          >
            <FiSlash className="h-4.5 w-4.5" />
          </button>
        </div>

        {/* Colors Selection */}
        <div className="flex items-center space-x-2">
          {['#2546ff', '#e11d48', '#16a34a', '#d97706', '#0f172a'].map((c) => (
            <button
              key={c}
              onClick={() => {
                setColor(c);
                if (tool === 'eraser') setTool('pencil');
              }}
              style={{ backgroundColor: c }}
              className={`w-6 h-6 rounded-full border-2 transition-all ${color === c && tool !== 'eraser' ? 'border-slate-800 scale-110 shadow' : 'border-transparent'}`}
            />
          ))}
        </div>

        {/* Brush Size Slider */}
        <div className="flex items-center space-x-2">
          <span className="text-xs text-slate-500 font-medium">Brush Size:</span>
          <input
            type="range"
            min="1"
            max="25"
            value={brushSize}
            onChange={(e) => setBrushSize(parseInt(e.target.value))}
            className="w-20 accent-brand-500 cursor-pointer"
          />
        </div>

        {/* Undo/Redo & Save controls */}
        <div className="flex items-center space-x-1.5">
          <button
            onClick={handleUndo}
            disabled={historyStack.length === 0}
            className="p-2 rounded-lg bg-slate-200/50 hover:bg-slate-200 disabled:opacity-40 text-slate-600 transition-all"
            title="Undo"
          >
            <FiRotateCcw className="h-4 w-4" />
          </button>
          
          <button
            onClick={handleRedo}
            disabled={redoStack.length === 0}
            className="p-2 rounded-lg bg-slate-200/50 hover:bg-slate-200 disabled:opacity-40 text-slate-600 transition-all"
            title="Redo"
          >
            <FiRotateCw className="h-4 w-4" />
          </button>

          <button
            onClick={handleClear}
            className="p-2 rounded-lg bg-red-100 hover:bg-red-200 text-red-600 transition-all"
            title="Clear Board"
          >
            <FiTrash2 className="h-4 w-4" />
          </button>

          <div className="h-6 w-px bg-slate-200 mx-1"></div>

          <button
            onClick={handleExportPNG}
            className="px-3 py-1.5 rounded-lg bg-brand-50 hover:bg-brand-100 text-brand-600 font-semibold text-xs transition-all flex items-center space-x-1"
            title="Export PNG"
          >
            <FiDownload className="h-3 w-3" />
            <span>PNG</span>
          </button>

          <button
            onClick={handleExportPDF}
            className="px-3 py-1.5 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-600 font-semibold text-xs transition-all flex items-center space-x-1"
            title="Export PDF"
          >
            <FiDownload className="h-3 w-3" />
            <span>PDF</span>
          </button>
        </div>

      </div>

      {/* Canvas Drawing Surface */}
      <div className="flex-grow w-full bg-white relative cursor-crosshair overflow-hidden">
        <canvas
          ref={canvasRef}
          onMouseDown={handleStartDraw}
          onMouseMove={handleDraw}
          onMouseUp={handleStopDraw}
          onMouseLeave={handleStopDraw}
          onTouchStart={handleStartDraw}
          onTouchMove={handleDraw}
          onTouchEnd={handleStopDraw}
          className="absolute inset-0 bg-white"
        />
      </div>

    </div>
  );
};

export default Whiteboard;
