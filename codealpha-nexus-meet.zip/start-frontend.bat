@echo off
echo =======================================================
echo   NexusMeet - Start Local Frontend Client
echo =======================================================
echo.
echo Starting the Vite client on port 5173...
echo Keep this command window open while using the application.
echo.
cd /d "%~dp0\frontend"
npm run dev
echo.
pause
