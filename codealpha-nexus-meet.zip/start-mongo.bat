@echo off
echo =======================================================
echo   NexusMeet - Start MongoDB Helper (Default Path)
echo =======================================================
echo.
echo Requesting administrator permissions to launch mongod.exe...
echo Please click "Yes" on the Windows UAC confirmation dialog.
echo.
echo It will use the default path C:\data\db (pre-created).
echo Keep the new MongoDB log window open while testing.
echo.
powershell -Command "Start-Process 'C:\Program Files\MongoDB\Server\8.3\bin\mongod.exe' -Verb RunAs"
echo.
echo MongoDB launch command dispatched successfully!
echo.
pause
