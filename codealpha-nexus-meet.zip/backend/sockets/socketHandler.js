import Message from '../models/Message.js';
import Meeting from '../models/Meeting.js';
import File from '../models/File.js';
import { useFallback, messagesTable, filesTable, generateId } from '../config/memoryDb.js';

// Global memory stores to track active rooms and users in real-time
// Format: roomUsers[roomId] = [ { socketId, userId, name, avatar, isMicActive, isCamActive, isScreenSharing, isHandRaised } ]
const roomUsers = {};

// Keep track of host socket mapping: hostSockets[roomId] = hostSocketId
const hostSockets = {};

// Keep track of whiteboards history per room (to allow new joiners to catch up instantly)
// Format: whiteboardHistory[roomId] = [ drawings... ]
const whiteboardHistory = {};

export default function registerSocketHandlers(io) {
  io.on('connection', (socket) => {
    console.log(`Socket connected: ${socket.id}`);

    // Join Room Event
    socket.on('join-room', async ({ roomId, userId, name, avatar, isHost }) => {
      socket.join(roomId);
      socket.roomId = roomId;
      socket.userId = userId;

      const newUser = {
        socketId: socket.id,
        userId,
        name,
        avatar: avatar || '',
        isMicActive: true,
        isCamActive: true,
        isScreenSharing: false,
        isHandRaised: false,
        isHost: !!isHost,
      };

      if (!roomUsers[roomId]) {
        roomUsers[roomId] = [];
      }

      // Check if user is already in the room tracking to prevent duplicates
      const existingUserIdx = roomUsers[roomId].findIndex(u => u.userId === userId);
      if (existingUserIdx !== -1) {
        roomUsers[roomId][existingUserIdx] = newUser;
      } else {
        roomUsers[roomId].push(newUser);
      }

      if (isHost) {
        hostSockets[roomId] = socket.id;
      }

      console.log(`User ${name} (${userId}) joined room ${roomId}`);

      // 1. Send currently connected users list back to the newly joined client
      const otherUsers = roomUsers[roomId].filter((u) => u.socketId !== socket.id);
      socket.emit('current-room-users', otherUsers);

      // 2. Send whiteboard drawing history to the new joiner so their whiteboard matches
      if (whiteboardHistory[roomId]) {
        socket.emit('whiteboard-history', whiteboardHistory[roomId]);
      }

      // 3. Broadcast to other users in the room that a new user has joined (include metadata)
      socket.to(roomId).emit('user-joined', newUser);

      // 4. Update MongoDB meeting participants
      try {
        const meeting = await Meeting.findOne({ meetingId: roomId });
        if (meeting) {
          const participantExists = meeting.participants.some(p => p.user.toString() === userId.toString());
          if (!participantExists) {
            meeting.participants.push({ user: userId, joinedAt: new Date() });
            await meeting.save();
          }
        }
      } catch (err) {
        console.error('Error updating meeting participants on socket join:', err);
      }
    });

    // WebRTC Mesh Signaling Events (Relaying between two specific sockets)
    socket.on('webrtc-offer', ({ targetSocketId, offer }) => {
      io.to(targetSocketId).emit('webrtc-offer', {
        senderSocketId: socket.id,
        offer,
      });
    });

    socket.on('webrtc-answer', ({ targetSocketId, answer }) => {
      io.to(targetSocketId).emit('webrtc-answer', {
        senderSocketId: socket.id,
        answer,
      });
    });

    socket.on('webrtc-ice-candidate', ({ targetSocketId, candidate }) => {
      io.to(targetSocketId).emit('webrtc-ice-candidate', {
        senderSocketId: socket.id,
        candidate,
      });
    });

    // Media Controls Synchronization
    socket.on('toggle-audio', ({ roomId, isActive }) => {
      if (roomUsers[roomId]) {
        const user = roomUsers[roomId].find((u) => u.socketId === socket.id);
        if (user) {
          user.isMicActive = isActive;
          socket.to(roomId).emit('peer-toggle-audio', { socketId: socket.id, isActive });
        }
      }
    });

    socket.on('toggle-video', ({ roomId, isActive }) => {
      if (roomUsers[roomId]) {
        const user = roomUsers[roomId].find((u) => u.socketId === socket.id);
        if (user) {
          user.isCamActive = isActive;
          socket.to(roomId).emit('peer-toggle-video', { socketId: socket.id, isActive });
        }
      }
    });

    socket.on('toggle-screen-share', ({ roomId, isSharing }) => {
      if (roomUsers[roomId]) {
        const user = roomUsers[roomId].find((u) => u.socketId === socket.id);
        if (user) {
          user.isScreenSharing = isSharing;
          socket.to(roomId).emit('peer-toggle-screen-share', { 
            socketId: socket.id, 
            isSharing,
            name: user.name
          });
        }
      }
    });

    socket.on('raise-hand', ({ roomId, isRaised }) => {
      if (roomUsers[roomId]) {
        const user = roomUsers[roomId].find((u) => u.socketId === socket.id);
        if (user) {
          user.isHandRaised = isRaised;
          io.to(roomId).emit('peer-raise-hand', { socketId: socket.id, isRaised, name: user.name });
        }
      }
    });

    // Chat Message Events
    socket.on('send-chat-message', async ({ roomId, senderId, message, fileId, replyToId }) => {
      try {
        if (useFallback()) {
          const senderInfo = roomUsers[roomId]?.find(u => u.userId === senderId) || { name: 'User', avatar: '' };
          
          let fileObj = null;
          if (fileId) {
            fileObj = filesTable.find(f => f._id === fileId);
          }

          let replyObj = null;
          if (replyToId) {
            const replyMsg = messagesTable.find(m => m._id === replyToId);
            if (replyMsg) {
              replyObj = {
                _id: replyMsg._id,
                message: replyMsg.message,
                sender: { name: replyMsg.sender?.name }
              };
            }
          }

          const mockMsg = {
            _id: generateId(),
            sender: {
              _id: senderId,
              name: senderInfo.name,
              avatar: senderInfo.avatar
            },
            meetingId: roomId,
            message: message || '',
            file: fileObj,
            replyTo: replyObj,
            timestamp: new Date()
          };
          
          messagesTable.push(mockMsg);
          io.to(roomId).emit('new-chat-message', mockMsg);
          return;
        }

        // Save message to MongoDB
        const msgData = {
          sender: senderId,
          meetingId: roomId,
          message: message || '',
        };

        if (fileId) msgData.file = fileId;
        if (replyToId) msgData.replyTo = replyToId;

        const savedMsg = await Message.create(msgData);
        
        let populatedMsg = await Message.findById(savedMsg._id)
          .populate('sender', 'name email avatar')
          .populate({
            path: 'file',
            model: 'File',
          })
          .populate({
            path: 'replyTo',
            populate: {
              path: 'sender',
              select: 'name'
            }
          });

        // Broadcast the populated message to everyone in the room (including the sender)
        io.to(roomId).emit('new-chat-message', populatedMsg);
      } catch (error) {
        console.error('Error saving or broadcasting socket chat message:', error);
      }
    });

    // Typing Indicators
    socket.on('typing-state', ({ roomId, name, isTyping }) => {
      socket.to(roomId).emit('peer-typing-state', { socketId: socket.id, name, isTyping });
    });

    // Delete Chat Message
    socket.on('delete-chat-message', async ({ roomId, messageId }) => {
      try {
        if (useFallback()) {
          const msgIdx = messagesTable.findIndex(m => m._id === messageId);
          if (msgIdx !== -1) {
            messagesTable[msgIdx].isDeleted = true;
          }
          io.to(roomId).emit('chat-message-deleted', { messageId });
          return;
        }

        await Message.findByIdAndUpdate(messageId, { isDeleted: true });
        io.to(roomId).emit('chat-message-deleted', { messageId });
      } catch (err) {
        console.error('Error deleting message via sockets:', err);
      }
    });

    // Collaborative Whiteboard Real-Time Sync
    socket.on('whiteboard-draw', ({ roomId, drawData }) => {
      // Accumulate whiteboard history to catch up newly joined participants
      if (!whiteboardHistory[roomId]) {
        whiteboardHistory[roomId] = [];
      }
      whiteboardHistory[roomId].push(drawData);

      // Broadcast drawing instructions to other clients in the room
      socket.to(roomId).emit('whiteboard-draw', drawData);
    });

    socket.on('whiteboard-clear', ({ roomId }) => {
      whiteboardHistory[roomId] = [];
      socket.to(roomId).emit('whiteboard-clear');
    });

    // Host Controls: Mute All
    socket.on('host-mute-all', ({ roomId }) => {
      // Broadcast mute command to all users except the host
      socket.to(roomId).emit('force-mute');
    });

    // Host Controls: End Meeting for All
    socket.on('host-end-meeting', ({ roomId }) => {
      // Update meeting end time in database
      Meeting.findOneAndUpdate({ meetingId: roomId }, { endTime: new Date() }).catch(console.error);
      
      // Clean up server side storage
      delete whiteboardHistory[roomId];
      delete roomUsers[roomId];
      delete hostSockets[roomId];

      // Broadcast meeting end to all clients in the room
      io.to(roomId).emit('meeting-ended');
    });

    // Leaving Room/Disconnection cleanup
    const handleLeaveRoom = () => {
      const { roomId } = socket;
      if (roomId && roomUsers[roomId]) {
        // Filter out this user
        roomUsers[roomId] = roomUsers[roomId].filter((u) => u.socketId !== socket.id);
        
        console.log(`User socket ${socket.id} left room ${roomId}`);

        // Broadcast to other users in the room
        socket.to(roomId).emit('user-left', { socketId: socket.id });

        // If no more users in the room, cleanup room memory
        if (roomUsers[roomId].length === 0) {
          delete roomUsers[roomId];
          delete whiteboardHistory[roomId];
          delete hostSockets[roomId];
        }
      }
    };

    socket.on('leave-room', handleLeaveRoom);
    socket.on('disconnecting', handleLeaveRoom);
    socket.on('disconnect', () => {
      console.log(`Socket disconnected: ${socket.id}`);
    });
  });
}
