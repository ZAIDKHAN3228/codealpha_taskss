import Meeting from '../models/Meeting.js';
import User from '../models/User.js';
import Message from '../models/Message.js';
import { useFallback, meetingsTable, messagesTable, generateId } from '../config/memoryDb.js';

// Helper: Generate structured meeting ID (abc-defg-hij)
const generateMeetingId = () => {
  const chars = 'abcdefghijklmnopqrstuvwxyz';
  const part1 = Array.from({ length: 3 }, () => chars[Math.floor(Math.random() * chars.length)]).join('');
  const part2 = Array.from({ length: 4 }, () => chars[Math.floor(Math.random() * chars.length)]).join('');
  const part3 = Array.from({ length: 3 }, () => chars[Math.floor(Math.random() * chars.length)]).join('');
  return `${part1}-${part2}-${part3}`;
};

// @desc    Create a new meeting room
// @route   POST /api/meetings/create
// @access  Private
export const createMeeting = async (req, res) => {
  try {
    const { meetingName, password } = req.body;

    if (useFallback()) {
      if (!meetingName) {
        return res.status(400).json({ success: false, message: 'Meeting name is required' });
      }
      const meetingId = generateMeetingId();
      const meeting = {
        _id: generateId(),
        meetingId,
        meetingName,
        host: {
          _id: req.user.id,
          name: req.user.name,
          avatar: req.user.avatar,
        },
        password: password || '',
        participants: [
          {
            user: {
              _id: req.user.id,
              name: req.user.name,
              avatar: req.user.avatar,
            },
            joinedAt: new Date(),
          },
        ],
        startTime: new Date(),
      };
      meetingsTable.push(meeting);
      return res.status(201).json({
        success: true,
        message: 'Meeting scheduled successfully (In-Memory)',
        meeting,
      });
    }

    if (!meetingName) {
      return res.status(400).json({ success: false, message: 'Meeting name is required' });
    }

    const meetingId = generateMeetingId();

    const meeting = await Meeting.create({
      meetingId,
      meetingName,
      host: req.user.id,
      password: password || '',
      participants: [{ user: req.user.id, joinedAt: new Date() }],
    });

    res.status(201).json({
      success: true,
      message: 'Meeting scheduled successfully',
      meeting: {
        id: meeting._id,
        meetingId: meeting.meetingId,
        meetingName: meeting.meetingName,
        host: meeting.host,
        password: meeting.password,
        startTime: meeting.startTime,
      },
    });
  } catch (error) {
    console.error('Create meeting error:', error);
    res.status(500).json({ success: false, message: 'Server Error' });
  }
};

// @desc    Get details of a specific meeting
// @route   GET /api/meetings/:meetingId
// @access  Private
export const getMeetingDetails = async (req, res) => {
  try {
    const { meetingId } = req.params;

    if (useFallback()) {
      const meeting = meetingsTable.find(m => m.meetingId === meetingId);
      if (!meeting) {
        return res.status(404).json({ success: false, message: 'Meeting room not found' });
      }
      return res.json({ success: true, meeting });
    }

    // Search by clean room ID
    const meeting = await Meeting.findOne({ meetingId })
      .populate('host', 'name email avatar')
      .populate('participants.user', 'name email avatar');

    if (!meeting) {
      return res.status(404).json({ success: false, message: 'Meeting room not found' });
    }

    res.json({
      success: true,
      meeting,
    });
  } catch (error) {
    console.error('Get meeting details error:', error);
    res.status(500).json({ success: false, message: 'Server Error' });
  }
};

// @desc    Get user's past meetings list
// @route   GET /api/meetings/history
// @access  Private
export const getMeetingHistory = async (req, res) => {
  try {
    if (useFallback()) {
      const history = meetingsTable.filter(
        m => m.host._id === req.user.id || m.participants.some(p => p.user._id === req.user.id)
      );
      return res.json({ success: true, meetings: history });
    }
    // Find meetings where user is host OR in participants array
    const meetings = await Meeting.find({
      $or: [
        { host: req.user.id },
        { 'participants.user': req.user.id }
      ]
    })
      .populate('host', 'name email avatar')
      .sort({ startTime: -1 })
      .limit(20);

    res.json({
      success: true,
      meetings,
    });
  } catch (error) {
    console.error('Get meeting history error:', error);
    res.status(500).json({ success: false, message: 'Server Error' });
  }
};

// @desc    Join meeting (records participant connection in DB)
// @route   POST /api/meetings/join
// @access  Private
export const joinMeeting = async (req, res) => {
  try {
    const { meetingId, password } = req.body;

    if (useFallback()) {
      const meetingIdx = meetingsTable.findIndex(m => m.meetingId === meetingId);
      if (meetingIdx === -1) {
        return res.status(404).json({ success: false, message: 'Meeting room does not exist' });
      }
      const meeting = meetingsTable[meetingIdx];
      if (meeting.password && meeting.password !== password) {
        return res.status(401).json({ success: false, message: 'Incorrect meeting password' });
      }
      const participantExists = meeting.participants.some(p => p.user._id === req.user.id);
      if (!participantExists) {
        meeting.participants.push({
          user: {
            _id: req.user.id,
            name: req.user.name,
            avatar: req.user.avatar,
          },
          joinedAt: new Date(),
        });
        meetingsTable[meetingIdx] = meeting;
      }
      return res.json({
        success: true,
        message: 'Joined meeting successfully (In-Memory)',
        meetingId: meeting.meetingId,
        meetingName: meeting.meetingName,
      });
    }

    const meeting = await Meeting.findOne({ meetingId });
    if (!meeting) {
      return res.status(404).json({ success: false, message: 'Meeting room does not exist' });
    }

    if (meeting.isRoomLocked) {
      return res.status(403).json({ success: false, message: 'The host has locked this meeting room.' });
    }

    // Verify password if set
    if (meeting.password && meeting.password !== password) {
      return res.status(401).json({ success: false, message: 'Incorrect meeting password' });
    }

    // Add user to participants list if not already there
    const userAlreadyJoined = meeting.participants.some(
      (p) => p.user.toString() === req.user.id.toString()
    );

    if (!userAlreadyJoined) {
      meeting.participants.push({ user: req.user.id, joinedAt: new Date() });
      await meeting.save();
    }

    res.json({
      success: true,
      message: 'Joined meeting successfully',
      meetingId: meeting.meetingId,
      meetingName: meeting.meetingName
    });
  } catch (error) {
    console.error('Join meeting error:', error);
    res.status(500).json({ success: false, message: 'Server Error' });
  }
};

// @desc    Get all chat messages inside a specific meeting
// @route   GET /api/meetings/:meetingId/messages
// @access  Private
export const getMeetingMessages = async (req, res) => {
  try {
    const { meetingId } = req.params;

    if (useFallback()) {
      const list = messagesTable.filter(m => m.meetingId === meetingId);
      return res.json({ success: true, messages: list });
    }

    const messages = await Message.find({ meetingId })
      .populate('sender', 'name email avatar')
      .populate({
        path: 'file',
        model: 'File'
      })
      .populate({
        path: 'replyTo',
        populate: {
          path: 'sender',
          select: 'name'
        }
      })
      .sort({ timestamp: 1 });

    res.json({
      success: true,
      messages,
    });
  } catch (error) {
    console.error('Get meeting messages error:', error);
    res.status(500).json({ success: false, message: 'Server Error' });
  }
};
