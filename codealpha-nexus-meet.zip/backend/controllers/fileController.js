import File from '../models/File.js';
import { processUpload } from '../middleware/fileUpload.js';
import { useFallback, filesTable, generateId } from '../config/memoryDb.js';

// @desc    Upload file inside a meeting
// @route   POST /api/files/upload
// @access  Private
export const uploadFile = async (req, res) => {
  try {
    const { meetingId } = req.body;

    if (!meetingId) {
      return res.status(400).json({ success: false, message: 'Meeting ID is required' });
    }

    if (!req.file) {
      return res.status(400).json({ success: false, message: 'No file uploaded' });
    }

    // Process file upload (Cloudinary or local backup storage)
    const uploadResult = await processUpload(req.file, `nexus-meet-shared/${meetingId}`);
    if (!uploadResult) {
      return res.status(500).json({ success: false, message: 'File processing failed' });
    }

    // Adjust relative path URL for local uploads to include the correct domain context
    let fileUrl = uploadResult.url;
    if (!uploadResult.isCloudinary) {
      // Local fallback file path logic
      const hostUrl = req.protocol + '://' + req.get('host');
      fileUrl = `${hostUrl}${uploadResult.url}`;
    }

    if (useFallback()) {
      const file = {
        _id: generateId(),
        fileName: req.file.originalname,
        url: fileUrl,
        uploadedBy: {
          _id: req.user.id,
          name: req.user.name,
          avatar: req.user.avatar,
        },
        meetingId,
        mimeType: req.file.mimetype,
        size: req.file.size,
        createdAt: new Date(),
      };
      filesTable.push(file);
      return res.status(201).json({
        success: true,
        message: 'File shared successfully (In-Memory)',
        file,
      });
    }

    // Create file record in db
    const newFile = await File.create({
      fileName: req.file.originalname,
      url: fileUrl,
      uploadedBy: req.user.id,
      meetingId,
      mimeType: req.file.mimetype,
      size: req.file.size,
    });

    const populatedFile = await File.findById(newFile._id).populate('uploadedBy', 'name email avatar');

    res.status(201).json({
      success: true,
      message: 'File shared successfully',
      file: populatedFile,
    });
  } catch (error) {
    console.error('File upload error:', error);
    res.status(500).json({ success: false, message: error.message || 'Server Error' });
  }
};

// @desc    Get all shared files in a specific meeting
// @route   GET /api/files/meeting/:meetingId
// @access  Private
export const getMeetingFiles = async (req, res) => {
  try {
    const { meetingId } = req.params;

    if (useFallback()) {
      const list = filesTable.filter(f => f.meetingId === meetingId);
      return res.json({ success: true, files: list });
    }

    const files = await File.find({ meetingId })
      .populate('uploadedBy', 'name email avatar')
      .sort({ createdAt: -1 });

    res.json({
      success: true,
      files,
    });
  } catch (error) {
    console.error('Get meeting files error:', error);
    res.status(500).json({ success: false, message: 'Server Error' });
  }
};
