import User from '../models/User.js';
import { processUpload } from '../middleware/fileUpload.js';
import { useFallback, usersTable } from '../config/memoryDb.js';

// @desc    Get current user profile
// @route   GET /api/users/profile
// @access  Private
export const getProfile = async (req, res) => {
  try {
    if (useFallback()) {
      const user = usersTable.find(u => u._id === req.user.id);
      if (!user) {
        return res.status(404).json({ success: false, message: 'User not found' });
      }
      return res.json({
        success: true,
        user: {
          id: user._id,
          name: user.name,
          email: user.email,
          avatar: user.avatar,
          isVerified: user.isVerified,
          createdAt: user.createdAt,
        },
      });
    }

    const user = await User.findById(req.user.id);
    if (!user) {
      return res.status(404).json({ success: false, message: 'User not found' });
    }
    res.json({
      success: true,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        avatar: user.avatar,
        isVerified: user.isVerified,
        createdAt: user.createdAt,
      },
    });
  } catch (error) {
    console.error('Get profile error:', error);
    res.status(500).json({ success: false, message: 'Server Error' });
  }
};

// @desc    Update user profile (Name, Avatar)
// @route   PUT /api/users/profile
// @access  Private
export const updateProfile = async (req, res) => {
  try {
    if (useFallback()) {
      const userIdx = usersTable.findIndex(u => u._id === req.user.id);
      if (userIdx === -1) {
        return res.status(404).json({ success: false, message: 'User not found' });
      }

      const user = usersTable[userIdx];
      if (req.body.name) {
        user.name = req.body.name;
      }
      if (req.body.password) {
        if (req.body.password.length < 6) {
          return res.status(400).json({ success: false, message: 'Password must be at least 6 characters' });
        }
        user.password = req.body.password;
      }
      if (req.file) {
        const uploadResult = await processUpload(req.file, 'nexus-meet-avatars');
        if (uploadResult) {
          user.avatar = uploadResult.url;
        }
      }

      usersTable[userIdx] = user;
      return res.json({
        success: true,
        message: 'Profile updated successfully! (In-Memory)',
        user: {
          id: user._id,
          name: user.name,
          email: user.email,
          avatar: user.avatar,
          isVerified: user.isVerified,
        },
      });
    }

    const user = await User.findById(req.user.id);
    if (!user) {
      return res.status(404).json({ success: false, message: 'User not found' });
    }

    // Update text fields
    if (req.body.name) {
      user.name = req.body.name;
    }

    // Check if password update is requested
    if (req.body.password) {
      if (req.body.password.length < 6) {
        return res.status(400).json({ success: false, message: 'Password must be at least 6 characters' });
      }
      user.password = req.body.password; // pre-save hook will hash it
    }

    // Handle avatar upload if file exists
    if (req.file) {
      const uploadResult = await processUpload(req.file, 'nexus-meet-avatars');
      if (uploadResult) {
        // If local upload, build the full URL (if required, or just relative path)
        user.avatar = uploadResult.url;
      }
    }

    await user.save();

    res.json({
      success: true,
      message: 'Profile updated successfully!',
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        avatar: user.avatar,
        isVerified: user.isVerified,
      },
    });
  } catch (error) {
    console.error('Update profile error:', error);
    res.status(500).json({ success: false, message: error.message || 'Server Error' });
  }
};
