import crypto from 'crypto';
import jwt from 'jsonwebtoken';
import User from '../models/User.js';
import { useFallback, usersTable, generateId } from '../config/memoryDb.js';

// Helper: Generate JWT Token
const generateToken = (id) => {
  return jwt.sign({ id }, process.env.JWT_SECRET || 'super_secret_session_key_for_nexus_meet_12345!', {
    expiresIn: process.env.JWT_EXPIRES_IN || '7d',
  });
};

// @desc    Register new user
// @route   POST /api/auth/register
// @access  Public
export const register = async (req, res) => {
  try {
    const { name, email, password } = req.body;

    if (useFallback()) {
      const exists = usersTable.find(u => u.email === email.toLowerCase());
      if (exists) {
        return res.status(400).json({ success: false, message: 'User already exists with this email' });
      }
      const user = {
        _id: generateId(),
        name,
        email: email.toLowerCase(),
        password, // in memory store plain password
        avatar: '',
        isVerified: true,
        createdAt: new Date(),
      };
      usersTable.push(user);
      return res.status(201).json({
        success: true,
        message: 'Registration successful! (In-Memory Database Mode)',
        token: generateToken(user._id),
        user: {
          id: user._id,
          name: user.name,
          email: user.email,
          avatar: user.avatar,
          isVerified: user.isVerified,
        },
      });
    }

    // Check if user already exists
    const userExists = await User.findOne({ email });
    if (userExists) {
      return res.status(400).json({ success: false, message: 'User already exists with this email' });
    }

    // Generate email verification token
    const verificationToken = crypto.randomBytes(32).toString('hex');

    // Create user (password is hashed in pre-save hook)
    const user = await User.create({
      name,
      email,
      password,
      verificationToken,
      isVerified: false, // verification required
    });

    // Mock send verification email
    const verificationUrl = `${process.env.CLIENT_URL || 'http://localhost:5173'}/verify-email?token=${verificationToken}`;
    console.log('\n===== EMAIL VERIFICATION SYSTEM =====');
    console.log(`To: ${email}`);
    console.log(`Verification Link: ${verificationUrl}`);
    console.log('=====================================\n');

    res.status(201).json({
      success: true,
      message: 'Registration successful! Please check your email (or server log) to verify your account.',
      token: generateToken(user._id),
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        avatar: user.avatar,
        isVerified: user.isVerified,
      },
    });
  } catch (error) {
    console.error('Registration error:', error);
    res.status(500).json({ success: false, message: error.message || 'Server Error' });
  }
};

// @desc    Verify email address
// @route   POST /api/auth/verify-email
// @access  Public
export const verifyEmail = async (req, res) => {
  try {
    const { token } = req.body;

    if (useFallback()) {
      return res.status(200).json({
        success: true,
        message: 'Email address verified successfully! (In-Memory Mode)',
      });
    }

    if (!token) {
      return res.status(400).json({ success: false, message: 'Verification token is required' });
    }

    const user = await User.findOne({ verificationToken: token });

    if (!user) {
      return res.status(404).json({ success: false, message: 'Invalid or expired email verification token' });
    }

    user.isVerified = true;
    user.verificationToken = undefined;
    await user.save();

    res.status(200).json({
      success: true,
      message: 'Email address verified successfully!',
    });
  } catch (error) {
    console.error('Email verification error:', error);
    res.status(500).json({ success: false, message: 'Server Error' });
  }
};

// @desc    Authenticate user & get token
// @route   POST /api/auth/login
// @access  Public
export const login = async (req, res) => {
  try {
    const { email, password } = req.body;

    if (useFallback()) {
      const user = usersTable.find(u => u.email === email.toLowerCase());
      if (!user || user.password !== password) {
        return res.status(401).json({ success: false, message: 'Invalid email or password' });
      }
      return res.json({
        success: true,
        token: generateToken(user._id),
        user: {
          id: user._id,
          name: user.name,
          email: user.email,
          avatar: user.avatar,
          isVerified: user.isVerified,
        },
      });
    }

    // Check for user
    const user = await User.findOne({ email }).select('+password');
    if (!user) {
      return res.status(401).json({ success: false, message: 'Invalid email or password' });
    }

    // Check password
    const isMatch = await user.matchPassword(password);
    if (!isMatch) {
      return res.status(401).json({ success: false, message: 'Invalid email or password' });
    }

    res.json({
      success: true,
      token: generateToken(user._id),
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        avatar: user.avatar,
        isVerified: user.isVerified,
      },
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ success: false, message: 'Server Error' });
  }
};

// @desc    Request password reset link
// @route   POST /api/auth/forgot-password
// @access  Public
export const forgotPassword = async (req, res) => {
  try {
    const { email } = req.body;
    const user = await User.findOne({ email });

    if (!user) {
      return res.status(404).json({ success: false, message: 'No account found with this email' });
    }

    // Generate reset token
    const resetToken = crypto.randomBytes(32).toString('hex');
    user.resetPasswordToken = crypto.createHash('sha256').update(resetToken).digest('hex');
    user.resetPasswordExpire = Date.now() + 10 * 60 * 1000; // 10 minutes expiry

    await user.save();

    // Mock send password reset email
    const resetUrl = `${process.env.CLIENT_URL || 'http://localhost:5173'}/reset-password?token=${resetToken}`;
    console.log('\n===== PASSWORD RESET SYSTEM =====');
    console.log(`To: ${email}`);
    console.log(`Reset Password Link: ${resetUrl}`);
    console.log('==================================\n');

    res.status(200).json({
      success: true,
      message: 'Password reset link generated! Check your email (or server log) for instructions.',
    });
  } catch (error) {
    console.error('Forgot password error:', error);
    res.status(500).json({ success: false, message: 'Server Error' });
  }
};

// @desc    Reset password
// @route   POST /api/auth/reset-password
// @access  Public
export const resetPassword = async (req, res) => {
  try {
    const { token, password } = req.body;

    if (!token || !password) {
      return res.status(400).json({ success: false, message: 'Token and new password are required' });
    }

    // Hash token to compare with database
    const resetPasswordToken = crypto.createHash('sha256').update(token).digest('hex');

    const user = await User.findOne({
      resetPasswordToken,
      resetPasswordExpire: { $gt: Date.now() },
    });

    if (!user) {
      return res.status(400).json({ success: false, message: 'Invalid or expired reset token' });
    }

    // Update password
    user.password = password; // pre-save hashes it
    user.resetPasswordToken = undefined;
    user.resetPasswordExpire = undefined;
    await user.save();

    res.status(200).json({
      success: true,
      message: 'Password reset successfully! You can now log in with your new password.',
    });
  } catch (error) {
    console.error('Reset password error:', error);
    res.status(500).json({ success: false, message: 'Server Error' });
  }
};

// @desc    Google OAuth authenticate
// @route   POST /api/auth/google
// @access  Public
export const googleLogin = async (req, res) => {
  try {
    const { name, email, avatar, googleId, credential } = req.body;

    let verifiedEmail = email;
    let verifiedName = name;
    let verifiedAvatar = avatar;

    // Verify token directly if a real Google OAuth token is supplied
    if (credential) {
      try {
        const response = await fetch(`https://oauth2.googleapis.com/tokeninfo?id_token=${credential}`);
        const data = await response.json();
        
        if (data.error_description) {
          return res.status(401).json({ success: false, message: 'Google Authentication token is invalid.' });
        }

        verifiedEmail = data.email;
        verifiedName = data.name;
        verifiedAvatar = data.picture;
      } catch (err) {
        console.error('Real Google token fetch failed:', err);
        return res.status(500).json({ success: false, message: 'Failed to verify token with Google API' });
      }
    }

    if (!verifiedEmail || !verifiedName) {
      return res.status(400).json({ success: false, message: 'Google email and name are required' });
    }

    if (useFallback()) {
      let user = usersTable.find(u => u.email === verifiedEmail.toLowerCase());
      if (!user) {
        user = {
          _id: generateId(),
          name: verifiedName,
          email: verifiedEmail.toLowerCase(),
          password: 'google_oauth_mock_pass',
          avatar: verifiedAvatar || '',
          isVerified: true,
          createdAt: new Date(),
        };
        usersTable.push(user);
      }
      return res.status(200).json({
        success: true,
        token: generateToken(user._id),
        user: {
          id: user._id,
          name: user.name,
          email: user.email,
          avatar: user.avatar,
          isVerified: user.isVerified,
        },
      });
    }

    // Find or create user in MongoDB
    let user = await User.findOne({ email: verifiedEmail.toLowerCase() });

    if (!user) {
      // Create new user for this Google account
      user = await User.create({
        name: verifiedName,
        email: verifiedEmail.toLowerCase(),
        password: crypto.randomBytes(16).toString('hex'), // random password for security
        avatar: verifiedAvatar || '',
        isVerified: true, // Google accounts are pre-verified
      });
    }

    res.status(200).json({
      success: true,
      token: generateToken(user._id),
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        avatar: user.avatar,
        isVerified: user.isVerified,
      },
    });
  } catch (error) {
    console.error('Google OAuth error:', error);
    res.status(500).json({ success: false, message: error.message || 'Google authentication failed' });
  }
};
