import mongoose from 'mongoose';

const meetingSchema = new mongoose.Schema({
  meetingId: {
    type: String,
    required: [true, 'Please provide a meeting ID'],
    unique: true,
    trim: true,
  },
  meetingName: {
    type: String,
    required: [true, 'Please provide a meeting name'],
    trim: true,
  },
  host: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  password: {
    type: String,
    default: '',
  },
  participants: [
    {
      user: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
      },
      joinedAt: {
        type: Date,
        default: Date.now,
      },
    },
  ],
  startTime: {
    type: Date,
    default: Date.now,
  },
  endTime: {
    type: Date,
  },
  isRoomLocked: {
    type: Boolean,
    default: false,
  },
});

const Meeting = mongoose.model('Meeting', meetingSchema);
export default Meeting;
