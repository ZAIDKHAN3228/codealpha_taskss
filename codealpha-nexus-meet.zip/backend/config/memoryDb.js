import crypto from 'crypto';

// In-Memory tables to serve as a complete zero-dependency database fallback
export const usersTable = [];
export const meetingsTable = [];
export const messagesTable = [];
export const filesTable = [];

// Helper to simulate MongoDB ObjectIds
export const generateId = () => crypto.randomBytes(12).toString('hex');

export const dbState = {
  isConnected: false,
};

// Check if MongoDB is connected, if not use fallback
export const useFallback = () => {
  return !dbState.isConnected;
};
