import mongoose from 'mongoose';
import { dbState } from './memoryDb.js';

const connectDB = async () => {
  try {
    // Disable command buffering globally so queries fail immediately if connection is down
    mongoose.set('bufferCommands', false);
    
    const conn = await mongoose.connect(process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/nexusmeet');
    dbState.isConnected = true;
    console.log(`MongoDB Connected: ${conn.connection.host}`);
  } catch (error) {
    dbState.isConnected = false;
    console.error(`MongoDB Connection Error: ${error.message}`);
    // Do not crash the server in local development if mongo is not running
    if (process.env.NODE_ENV === 'production') {
      process.exit(1);
    } else {
      console.warn('WARNING: Running backend in In-Memory Database Fallback mode. Registrations, logins, and call rooms will run database-free in local RAM.');
    }
  }
};

export default connectDB;
