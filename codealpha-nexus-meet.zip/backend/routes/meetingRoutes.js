import express from 'express';
import {
  createMeeting,
  getMeetingDetails,
  getMeetingHistory,
  joinMeeting,
  getMeetingMessages,
} from '../controllers/meetingController.js';
import { protect } from '../middleware/auth.js';

const router = express.Router();

router.use(protect); // protect all meeting routes

router.post('/create', createMeeting);
router.post('/join', joinMeeting);
router.get('/history', getMeetingHistory);
router.get('/:meetingId', getMeetingDetails);
router.get('/:meetingId/messages', getMeetingMessages);

export default router;
