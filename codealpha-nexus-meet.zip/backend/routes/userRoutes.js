import express from 'express';
import { getProfile, updateProfile } from '../controllers/userController.js';
import { protect } from '../middleware/auth.js';
import { upload } from '../middleware/fileUpload.js';

const router = express.Router();

router.route('/profile')
  .get(protect, getProfile)
  .put(protect, upload.single('avatar'), updateProfile);

export default router;
