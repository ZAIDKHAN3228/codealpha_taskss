import express from 'express';
import { uploadFile, getMeetingFiles } from '../controllers/fileController.js';
import { protect } from '../middleware/auth.js';
import { upload } from '../middleware/fileUpload.js';

const router = express.Router();

router.use(protect); // protect all file routes

router.post('/upload', upload.single('file'), uploadFile);
router.get('/meeting/:meetingId', getMeetingFiles);

export default router;
export { router as fileRoutes };
