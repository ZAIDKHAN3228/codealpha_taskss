import express from 'express';
import http from 'http';
import { Server } from 'socket.io';
import cors from 'cors';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';

import connectDB from './config/db.js';
import registerSocketHandlers from './sockets/socketHandler.js';

// Route Imports
import authRoutes from './routes/authRoutes.js';
import userRoutes from './routes/userRoutes.js';
import meetingRoutes from './routes/meetingRoutes.js';
import fileRoutes from './routes/fileRoutes.js';

// Initialize Environment Variables
dotenv.config();

// Resolve paths for ES Modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Initialize Express App & HTTP Server
const app = express();
const server = http.createServer(app);

const allowedOrigins = [
  'http://localhost:5173',
  'http://localhost:5175',
  'https://frontend-puce-tau-61.vercel.app'
];

if (process.env.CLIENT_URL) {
  allowedOrigins.push(process.env.CLIENT_URL);
}

const checkOrigin = (origin, callback) => {
  if (!origin || allowedOrigins.indexOf(origin) !== -1 || origin.endsWith('.vercel.app')) {
    callback(null, true);
  } else {
    callback(new Error('Not allowed by CORS'));
  }
};

// Setup Socket.io Server
const io = new Server(server, {
  cors: {
    origin: checkOrigin,
    methods: ['GET', 'POST', 'PUT', 'DELETE'],
    credentials: true,
  },
});

// Configure Security Middleware
// Modify Helmet CSP to allow dynamic WebRTC/Socket connections & image sources
app.use(
  helmet({
    crossOriginResourcePolicy: false, // Allows cross-origin image retrieval
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        connectSrc: ["'self'", "ws:", "wss:", "http:", "https:"],
        imgSrc: ["'self'", "data:", "blob:", "https://res.cloudinary.com"],
        mediaSrc: ["'self'", "data:", "blob:", "https://res.cloudinary.com"],
      },
    },
  })
);

// CORS config
app.use(
  cors({
    origin: checkOrigin,
    methods: ['GET', 'POST', 'PUT', 'DELETE'],
    credentials: true,
  })
);

// JSON and URL-encoded body parsers
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve Local Uploads Statically
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Rate Limiter to protect endpoints
const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 200, // limit each IP to 200 requests per windowMs
  standardHeaders: true,
  legacyHeaders: false,
  message: 'Too many requests from this IP, please try again after 15 minutes',
});
app.use('/api/', apiLimiter);

// Connect to MongoDB
connectDB();

// Register Socket.io Event Handlers
registerSocketHandlers(io);

// API Routes Mapping
app.use('/api/auth', authRoutes);
app.use('/api/users', userRoutes);
app.use('/api/meetings', meetingRoutes);
app.use('/api/files', fileRoutes);

// Health Check Endpoint
app.get('/health', (req, res) => {
  res.status(200).json({ status: 'OK', message: 'NexusMeet server is running healthy' });
});

// Global Fallback Error Handler
app.use((err, req, res, next) => {
  console.error('Unhandled Error Caught:', err.message || err);
  const statusCode = res.statusCode === 200 ? 500 : res.statusCode;
  res.status(statusCode).json({
    success: false,
    message: err.message || 'An unexpected error occurred on the server',
    stack: process.env.NODE_ENV === 'production' ? null : err.stack,
  });
});

// Start Server Listeners
const PORT = process.env.PORT || 5000;
server.listen(PORT, () => {
  console.log(`\n======================================================`);
  console.log(`  NexusMeet Server Running in ${process.env.NODE_ENV || 'development'} mode`);
  console.log(`  Local REST API: http://localhost:${PORT}`);
  console.log(`  WebSocket URL:  ws://localhost:${PORT}`);
  console.log(`======================================================\n`);
});
