import multer from 'multer';
import path from 'path';
import fs from 'fs';
import { isCloudinaryConfigured, cloudinary } from '../config/cloudinary.js';

// Ensure local uploads directory exists
const uploadDir = './uploads';
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

// Multer disk storage config (used for local uploads & temporary files before Cloudinary upload)
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
    cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
  },
});

// File filter to restrict uploads to allowed formats only
const fileFilter = (req, file, cb) => {
  const allowedTypes = [
    // Images
    'image/png', 'image/jpeg', 'image/gif', 'image/webp',
    // PDF
    'application/pdf',
    // Word / DOCX
    'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    // PPT
    'application/vnd.ms-powerpoint', 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    // ZIP
    'application/zip', 'application/x-zip-compressed',
    // Videos
    'video/mp4', 'video/webm', 'video/ogg', 'video/quicktime'
  ];

  if (allowedTypes.includes(file.mimetype)) {
    cb(null, true);
  } else {
    cb(new Error('Invalid file type. Supported formats are Images, PDF, DOCX, PPT, ZIP, and Videos.'), false);
  }
};

// Multer upload config
export const upload = multer({
  storage,
  fileFilter,
  limits: {
    fileSize: 50 * 1024 * 1024, // 50MB max file size
  },
});

// Upload helper function that uploads to Cloudinary (if configured) or returns local server URL
export const processUpload = async (file, folder = 'nexus-meet') => {
  if (!file) return null;

  if (isCloudinaryConfigured) {
    try {
      let resourceType = 'auto';
      
      // Map specific types for Cloudinary
      if (file.mimetype.startsWith('video/')) {
        resourceType = 'video';
      } else if (!file.mimetype.startsWith('image/')) {
        // Raw files like ZIP, PDF, DOCX
        resourceType = 'raw';
      }

      const result = await cloudinary.uploader.upload(file.path, {
        folder,
        resource_type: resourceType,
      });

      // Cleanup local temp file
      if (fs.existsSync(file.path)) {
        fs.unlinkSync(file.path);
      }

      return {
        url: result.secure_url,
        publicId: result.public_id,
        isCloudinary: true
      };
    } catch (error) {
      console.error('Cloudinary upload failure, using local fallback:', error);
      // Fallback to local url if upload fails
    }
  }

  // Local storage URL format (will be mapped with base URL in controller)
  const relativePath = file.path.replace(/\\/g, '/'); // normalize windows paths
  return {
    url: `/${relativePath}`, // returns "/uploads/file-xyz.pdf"
    isCloudinary: false
  };
};
