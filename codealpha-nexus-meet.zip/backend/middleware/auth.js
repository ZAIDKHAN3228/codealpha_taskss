import jwt from 'jsonwebtoken';
import User from '../models/User.js';
import { useFallback, usersTable } from '../config/memoryDb.js';

export const protect = async (req, res, next) => {
  let token;

  if (
    req.headers.authorization &&
    req.headers.authorization.startsWith('Bearer')
  ) {
    try {
      // Get token from header
      token = req.headers.authorization.split(' ')[1];

      // Verify token
      const decoded = jwt.verify(token, process.env.JWT_SECRET || 'super_secret_session_key_for_nexus_meet_12345!');

      if (useFallback()) {
        const memUser = usersTable.find(u => u._id === decoded.id);
        if (!memUser) {
          return res.status(401).json({ success: false, message: 'Not authorized, user not found' });
        }
        // Mock request object shape
        req.user = {
          id: memUser._id,
          _id: memUser._id,
          name: memUser.name,
          email: memUser.email,
          avatar: memUser.avatar,
          isVerified: memUser.isVerified,
          createdAt: memUser.createdAt,
        };
        return next();
      }

      // Get user from the token (exclude password)
      req.user = await User.findById(decoded.id).select('-password');
      if (!req.user) {
        return res.status(401).json({ success: false, message: 'Not authorized, user not found' });
      }

      next();
    } catch (error) {
      console.error('JWT authorization error:', error);
      return res.status(401).json({ success: false, message: 'Not authorized, token failed' });
    }
  }

  if (!token) {
    return res.status(401).json({ success: false, message: 'Not authorized, no token provided' });
  }
};
