@echo off
echo =======================================================
echo   NexusMeet - Production Deployment Wizard Launcher
echo =======================================================
echo.
echo Launching deploy.ps1 with execution policy bypass...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0deploy.ps1"
echo.
pause
