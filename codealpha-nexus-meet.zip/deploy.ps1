# =======================================================
#   NexusMeet - Direct CLI Deployment Helper Wizard
# =======================================================

Clear-Host
Write-Host "=======================================================" -ForegroundColor Cyan
Write-Host "         NexusMeet Cloud Deploy Wizard                 " -ForegroundColor Cyan
Write-Host "=======================================================" -ForegroundColor Cyan
Write-Host " This script installs the required CLIs and deploys your"
Write-Host " application directly to Vercel (Frontend) and Railway"
Write-Host " (Backend + MongoDB Cluster) from your command line."
Write-Host "=======================================================" -ForegroundColor Cyan
Write-Host ""

# Ask to proceed
$confirm = Read-Host "Proceed with deployment setup? (Y/N)"
if ($confirm -ne "Y" -and $confirm -ne "y") {
    Write-Host "Deployment cancelled." -ForegroundColor Yellow
    exit
}

# --- STEP 1: INSTALL CLI UTILITIES ---
Write-Host "`n[1/5] Installing Vercel & Railway CLIs..." -ForegroundColor Green
npm install -g vercel @railway/cli

# --- STEP 2: LOG IN TO SERVICES ---
Write-Host "`n[2/5] Log in to Vercel..." -ForegroundColor Green
Write-Host "A browser window will open. Authorize Vercel to continue."
vercel login

Write-Host "`nLog in to Railway..." -ForegroundColor Green
Write-Host "A browser window will open. Authorize Railway to continue."
railway login

# --- STEP 3: INITIALIZE BACKEND DATABASE & SERVER ---
Write-Host "`n[3/5] Setting up Backend on Railway..." -ForegroundColor Green
Set-Location -Path "$PSScriptRoot\backend"

Write-Host "Creating Railway project..." -ForegroundColor Cyan
railway init

Write-Host "Provisioning MongoDB Database in your Railway project..." -ForegroundColor Cyan
railway add --service mongodb

Write-Host "Deploying Backend server code..." -ForegroundColor Cyan
railway up

# Retrieve railway backend domain
Write-Host "`n=======================================================" -ForegroundColor Yellow
Write-Host "Action Required: Please copy your Deployed Backend URL"
Write-Host "from the Railway deployment logs above (e.g. https://xxxx.up.railway.app)."
Write-Host "=======================================================" -ForegroundColor Yellow
$backendUrl = Read-Host "Paste Deployed Backend URL"

if (-not $backendUrl.StartsWith("http")) {
    Write-Host "Invalid URL format. Please run deploy again and paste a valid HTTP URL." -ForegroundColor Red
    exit
}

# --- STEP 4: CONFIGURE FRONTEND ENVIRONMENT VARIABLES ---
Write-Host "`n[4/5] Updating Frontend Environment Variables..." -ForegroundColor Green
$frontendEnvPath = "$PSScriptRoot\frontend\.env"
$cleanBackendUrl = $backendUrl.TrimEnd('/')

$envContent = @"
VITE_API_URL=$cleanBackendUrl/api
VITE_SOCKET_URL=$cleanBackendUrl
"@

Set-Content -Path $frontendEnvPath -Value $envContent
Write-Host "Updated frontend/.env with production URL: $cleanBackendUrl" -ForegroundColor Cyan

# --- STEP 5: DEPLOY FRONTEND ---
Write-Host "`n[5/5] Deploying Frontend to Vercel..." -ForegroundColor Green
Set-Location -Path "$PSScriptRoot\frontend"

# Configure Vercel Project
Write-Host "Running Vercel deployment..." -ForegroundColor Cyan
vercel --prod --confirm

Write-Host "`n=======================================================" -ForegroundColor Green
Write-Host " 🎉 NEXUSMEET IS LIVE ON THE WEB!" -ForegroundColor Green
Write-Host "=======================================================" -ForegroundColor Green
Write-Host "Check your Vercel deployment URL above to start using the app."
Write-Host ""
Pause
