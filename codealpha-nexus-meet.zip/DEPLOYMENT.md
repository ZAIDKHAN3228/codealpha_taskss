# Deploying NexusMeet for Personal Meetings

This guide walks you through configuring, securing, and deploying **NexusMeet** for your actual personal or team meetings on the live internet. 

---

## 🛠️ Step 1: Set Up a Cloud Database (MongoDB Atlas)

For actual personal meetings, you need a persistent database so your accounts, profiles, files, and chat logs are saved permanently (and don't get lost when the server restarts).

1. Go to [MongoDB Atlas](https://www.mongodb.com/cloud/atlas) and sign up for a free account.
2. Click **Create a Database** and select the **M0 Free Shared Tier**.
3. Under **Security Quickstart**:
   - Create a database user (write down the username and password).
   - Under **IP Access List**, select **Allow Access from Anywhere** (`0.0.0.0/0`) since cloud hosts like Render rotate outbound IPs.
4. Go to the Database Deployment Dashboard, click **Connect** -> **Drivers**, and copy the connection string. It will look like this:
   ```env
   mongodb+srv://<username>:<password>@cluster0.abcde.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0
   ```
5. Replace `<username>` and `<password>` with your created database credentials.
6. Open your **`backend/.env`** file and update the `MONGO_URI` value:
   ```env
   MONGO_URI=mongodb+srv://your_username:your_password@cluster0.mongodb.net/nexusmeet?retryWrites=true&w=majority
   ```

---

## 🔑 Step 2: Set Up Real Google Authentication (Google Cloud Console)

To authorize users using their actual Google accounts:

1. Visit the [Google Cloud Console](https://console.cloud.google.com/).
2. Create a new project called **NexusMeet**.
3. In the sidebar, navigate to **APIs & Services** -> **OAuth Consent Screen**:
   - Set User Type to **External**.
   - Add your app info (App Name: `NexusMeet`, Email).
   - Under **Scopes**, click **Add Scopes** and select:
     - `.../auth/userinfo.profile` (Profile Information)
     - `.../auth/userinfo.email` (Primary Email Address)
   - Save and continue.
4. Go to the **Credentials** tab:
   - Click **Create Credentials** -> **OAuth Client ID**.
   - Select **Web Application** as the application type.
   - **Authorized JavaScript Origins**:
     - Local testing: `http://localhost:5173`
     - Production: `https://your-frontend-domain.vercel.app`
   - **Authorized Redirect URIs**:
     - Local testing: `http://localhost:5173`
     - Production: `https://your-frontend-domain.vercel.app`
   - Click **Create** and copy your **Client ID** and **Client Secret**.
5. Save these keys in your environment configuration.

---

## 🌐 Step 3: Configure WebRTC TURN Servers for Internet Calling

WebRTC connections between peers on different home networks (behind strict routers and symmetric NAT firewalls) will fail unless you configure a **TURN Server** to relay media streams.

1. Sign up for a free network traversal tier on a provider like:
   - [Metered.ca](https://www.metered.ca/) (Free monthly TURN/STUN allowance)
   - [Twilio Network Traversal](https://www.twilio.com/docs/stun-turn)
   - [Xirsys](https://xirsys.com/)
2. Copy the credentials (the username, credential password, and `turn:` URLs).
3. Open [WebRTCContext.jsx](file:///C:/Users/DELL/.gemini/antigravity/scratch/nexus-meet/frontend/src/contexts/WebRTCContext.jsx#L20-L32) and update the `iceServers` array with your credentials:
   ```javascript
   const iceServers = [
     { urls: 'stun:stun.l.google.com:19302' },
     {
       urls: 'turn:your-turn-domain.com:3478',
       username: 'your_turn_username',
       credential: 'your_turn_password'
     }
   ];
   ```

---

## 🚀 Step 4: Live Deployment

### A. Deploy the Backend (Express & Socket.io) on Render
[Render](https://render.com/) is a great cloud platform for hosting Node/Websocket applications.

1. Create a free account on Render.
2. Click **New** -> **Web Service** and connect your GitHub repository.
3. Configure the build settings:
   - **Root Directory**: `backend`
   - **Build Command**: `npm install`
   - **Start Command**: `npm start`
4. Add the following **Environment Variables** in Render's dashboard:
   - `PORT`: `5000` (Render will override this, but standardizes configurations)
   - `NODE_ENV`: `production`
   - `MONGO_URI`: `your_mongodb_atlas_connection_string`
   - `JWT_SECRET`: `a_strong_random_string_of_characters`
   - `CLIENT_URL`: `https://your-frontend-domain.vercel.app` (your frontend site URL)
5. Click **Deploy**. Write down the deployed Render URL (e.g., `https://nexus-meet-api.onrender.com`).

### B. Deploy the Frontend (React Vite App) on Vercel
[Vercel](https://vercel.com/) is optimized for bundling and serving Vite frontend sites.

1. Create a free account on Vercel.
2. Select **New Project** and connect your GitHub repository.
3. Configure the project settings:
   - **Root Directory**: `frontend`
   - **Framework Preset**: **Vite**
   - **Build Command**: `npm run build`
   - **Output Directory**: `dist`
4. Under **Environment Variables**, add:
   - `VITE_API_URL`: `https://nexus-meet-api.onrender.com/api` (your backend Render URL + `/api`)
   - `VITE_SOCKET_URL`: `https://nexus-meet-api.onrender.com` (your backend Render URL)
5. Click **Deploy**. Vercel will build your static files and assign you a secure, free SSL production URL (e.g., `https://nexus-meet.vercel.app`).

---

## ⚙️ Step 5: Production Checklist & Security Controls

Before inviting guest participants to call, double-check these configs:

* **Disable Mock fallbacks**: Once your MongoDB Atlas is online, the app automatically switches off the volatile memory mode, storing all files, users, and rooms securely.
* **Enforce HTTPS**: Both backend CORS policies and WebRTC media stream permissions (accessing camera/mic) **require** secure HTTPS domains in order to work on modern mobile browsers.
* **Change JWT Secrets**: Ensure the `JWT_SECRET` in production is set to a long, cryptographic string to secure user sessions.
